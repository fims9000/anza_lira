#!/usr/bin/env python3
"""Audit selected CT28 JUNCTION identity and test independent jitter averaging."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import run_ct28_graph_lira as graph
from ct28_perturbations import perturb_scene_endpoints
from diagnose_ct28_selected_type import perturb as evaluation_perturb


ROOT = graph.REPO_ROOT
SCENES = graph.DEFAULT_SCENE_DIR
SELECTED = ROOT / "varvara/anza_lira_local_results/ct28_copy_count_ablations/joint_check/fusion_10_relation_15"
SAVED = ROOT / "varvara/anza_lira_local_results/ct28_copy_count_ablations/selected_type_diagnostics"
OUTPUT = ROOT / "varvara/anza_lira_local_results/ct28_junction_score_averaging_v1"
FEATURES = list(graph.relation_training.JUNCTION_GEOMETRY_FEATURES)
EVALUATION_MODES = ("joint", "position_only")
INNER_SEED = 20261029
INNER_COPIES = 5
INNER_POSITION_SIGMA_MM = 0.25


def geometry_rows(candidates: pd.DataFrame, endpoints: pd.DataFrame) -> list[dict]:
    lookup = endpoints.set_index("endpoint_id")
    rows = []
    for candidate in candidates.itertuples(index=False):
        items = [graph.endpoint_item(lookup.loc[endpoint_id])
                 for endpoint_id in candidate.endpoint_ids.split("|")]
        values = graph.scene_builder.oriented_junction_geometry(items)
        rows.append({"scene_id": candidate.scene_id, "candidate_id": candidate.candidate_id,
                     **dict(zip(FEATURES, values))})
    return rows


def rank_frame(scores: pd.DataFrame, candidates: pd.DataFrame,
               plans: pd.DataFrame, groups: pd.DataFrame) -> pd.DataFrame:
    merged = scores.merge(candidates[["scene_id", "candidate_id", "y"]],
                          on=["scene_id", "candidate_id"], validate="many_to_one")
    rows = []
    for (scene_id, mode, repetition), part in merged.groupby(
        ["scene_id", "mode", "repetition"], sort=False
    ):
        true = part[part.y.eq(1)]
        false = part[part.y.eq(0)]
        if len(true) != 1:
            raise ValueError(f"expected one true JUNCTION candidate in {scene_id}")
        true = true.iloc[0]
        best_false = (false.sort_values(["geometry_score", "candidate_id"],
                                       ascending=[False, True]).iloc[0]
                      if len(false) else None)
        rows.append({
            "scene_id": scene_id, "mode": mode, "repetition": int(repetition),
            "scene_competitive": bool(len(false)),
            "true_candidate_id": true.candidate_id,
            "best_false_candidate_id": best_false.candidate_id if best_false is not None else "",
            "true_score": float(true.geometry_score),
            "best_false_score": float(best_false.geometry_score) if best_false is not None else np.nan,
            "margin": (float(true.geometry_score - best_false.geometry_score)
                       if best_false is not None else np.nan),
            "top1_correct": int(part.loc[part.geometry_score.idxmax(), "y"] == 1),
        })
    result = pd.DataFrame(rows).merge(
        plans[["scene_id", "scan_id", "scene_family", "junction_source_id"]],
        on="scene_id", validate="many_to_one"
    ).merge(groups, on="junction_source_id", validate="many_to_one")
    return result


def summary(frame: pd.DataFrame) -> list[dict]:
    rows = []
    for (method, mode, family, group), part in frame.groupby(
        ["method", "mode", "scene_family", "junction_benchmark_group"]
    ):
        rows.append({
            "method": method, "mode": mode, "scene_family": family,
            "junction_benchmark_group": group,
            "junctions": int(part.junction_source_id.nunique()),
            "scene_repeats": int(len(part)),
            "scene_competitive_repeats": int(part.scene_competitive.sum()),
            "top1_correct": int(part.top1_correct.sum()),
            "top1_rate": float(part.top1_correct.mean()),
            "median_true_score": float(part.true_score.median()),
            "median_best_false_score": float(part.best_false_score.median()),
            "median_margin": float(part.margin.median()),
            "negative_margin_repeats": int((part.margin < 0).sum()),
        })
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", type=Path, default=OUTPUT)
    args = parser.parse_args()

    plans = pd.read_csv(SCENES / "scene_plan_train_val.csv")
    if set(plans.scan_id) & {954, 958, 972, 973, 980, 984}:
        raise ValueError("held-out test scene is present")
    plans = plans[plans.split.eq("val") & plans.scene_family.isin(
        ("junction_only", "mixed"))].copy()
    if len(plans) != 72 or set(plans.scan_id) != graph.EXPECTED_VALIDATION_PATIENTS:
        raise ValueError("unexpected validation junction scenes")
    if plans[plans.scene_family.eq("junction_only")].junction_source_id.nunique() != 36:
        raise ValueError("unexpected source junction count")

    candidates = pd.read_csv(SCENES / "scene_candidates_train_val.csv")
    candidates = candidates[candidates.scene_id.isin(plans.scene_id)
                            & candidates.candidate_type.eq("JUNCTION")].copy()
    endpoints = pd.read_csv(SCENES / "scene_endpoints_train_val.csv")
    endpoints = endpoints[endpoints.scene_id.isin(plans.scene_id)]
    source_groups = pd.read_csv(SELECTED / "clean_eval/graph_lira_predictions_val.csv")
    source_groups = source_groups[source_groups.model.eq("ct_conditioned")
                                  & source_groups.scene_family.eq("junction_only")][
        ["junction_source_id", "junction_benchmark_group"]].drop_duplicates()
    if source_groups.junction_benchmark_group.value_counts().to_dict() != {
        "competitive": 28, "isolated": 8
    }:
        raise ValueError("source-level competitive/isolated groups changed")

    selected_protocol = json.loads((SELECTED / "relation_model_protocol.json").read_text())
    for key, filename in (("scene_plan", "scene_plan_train_val.csv"),
                          ("scene_candidates", "scene_candidates_train_val.csv"),
                          ("scene_candidate_features", "scene_candidate_features_train_val.csv")):
        if graph.sha256(SCENES / filename) != selected_protocol["source_sha256"][key]:
            raise ValueError(f"selected model source mismatch: {key}")
    model_pack = joblib.load(SELECTED / "relation_models.joblib")
    if model_pack.get("local_model_family") != "hgb":
        raise ValueError("selected local model family changed")
    model = model_pack["local_models"]["JUNCTION"]["geometry"]
    if list(model.feature_names_in_) != FEATURES:
        raise ValueError("JUNCTION geometry feature order changed")

    clean = pd.read_csv(SELECTED / "relation_local_scores_train_val.csv")
    clean = clean[clean.scene_id.isin(plans.scene_id)
                  & clean.candidate_type.eq("JUNCTION")][
        ["scene_id", "candidate_id", "geometry_score"]].copy()
    clean["mode"], clean["repetition"] = "clean", -1
    saved = pd.read_csv(SAVED / "local_scores_val.csv.gz")
    saved = saved[saved.scene_id.isin(plans.scene_id)
                  & saved.candidate_type.eq("JUNCTION")
                  & saved["mode"].isin(EVALUATION_MODES)][
        ["scene_id", "candidate_id", "mode", "repetition", "geometry_score"]].copy()
    saved_protocol = json.loads((SAVED / "protocol.json").read_text())
    if (graph.sha256(SELECTED / "relation_models.joblib")
            != saved_protocol["source_sha256"]["models"]):
        raise ValueError("saved noisy scores came from a different model pack")
    expected_noisy = len(candidates) * 15 * len(EVALUATION_MODES)
    if len(saved) != expected_noisy:
        raise ValueError(f"missing noisy scores: {len(saved)} != {expected_noisy}")

    observed = pd.concat([clean, saved], ignore_index=True)
    baseline = rank_frame(observed, candidates, plans, source_groups)
    baseline["method"] = "original"
    if len(baseline) != 72 * 31:
        raise ValueError("missing ranking observations")

    candidate_groups = dict(tuple(candidates.groupby("scene_id", sort=False)))
    endpoint_groups = dict(tuple(endpoints.groupby("scene_id", sort=False)))
    original_index = observed.set_index(["scene_id", "candidate_id", "mode", "repetition"])
    smoothed_rows = []
    max_recomputed_score_error = 0.0
    for scan_id, patient_plans in plans.groupby("scan_id", sort=True):
        scene_ids = sorted(patient_plans.scene_id)
        for mode in ("clean", *EVALUATION_MODES):
            repetitions = (-1,) if mode == "clean" else range(15)
            for repetition in repetitions:
                feature_rows = []
                for scene_id in scene_ids:
                    source = endpoint_groups[scene_id]
                    current = (source if mode == "clean" else
                               evaluation_perturb(source, repetition, mode))
                    for copy_index in range(INNER_COPIES + 1):
                        if copy_index == 0:
                            variant = current
                        else:
                            inner_repetition = (
                                (0 if mode == "clean" else 1000 if mode == "joint" else 2000)
                                + (repetition + 1) * INNER_COPIES + copy_index
                            )
                            variant = perturb_scene_endpoints(
                                current, seed=INNER_SEED, repetition=inner_repetition,
                                position_noise_mm=INNER_POSITION_SIGMA_MM,
                                tangent_noise_deg=0.0,
                            )
                        for row in geometry_rows(candidate_groups[scene_id], variant):
                            row["copy_index"] = copy_index
                            feature_rows.append(row)
                feature_frame = pd.DataFrame(feature_rows)
                feature_frame["geometry_score"] = model.predict_proba(
                    feature_frame[FEATURES]
                )[:, 1]
                base_rows = feature_frame[feature_frame.copy_index.eq(0)].set_index(
                    ["scene_id", "candidate_id"]
                )
                keys = pd.MultiIndex.from_arrays(
                    [base_rows.index.get_level_values(0),
                     base_rows.index.get_level_values(1),
                     np.full(len(base_rows), mode),
                     np.full(len(base_rows), repetition)],
                    names=["scene_id", "candidate_id", "mode", "repetition"]
                )
                error = np.abs(base_rows.geometry_score.to_numpy()
                               - original_index.loc[keys, "geometry_score"].to_numpy())
                max_recomputed_score_error = max(max_recomputed_score_error, float(error.max()))
                if max_recomputed_score_error > 1e-9:
                    raise ValueError(f"recomputed baseline score mismatch: {max_recomputed_score_error}")
                averaged = feature_frame.groupby(["scene_id", "candidate_id"],
                                                 sort=False).geometry_score.mean()
                for (scene_id, candidate_id), score in averaged.items():
                    smoothed_rows.append({"scene_id": scene_id,
                                          "candidate_id": candidate_id,
                                          "mode": mode, "repetition": repetition,
                                          "geometry_score": float(score),
                                          "method": "mean_original_plus_5"})
            print(f"patient {scan_id}: {mode} completed", flush=True)

    smoothed = rank_frame(pd.DataFrame(smoothed_rows), candidates, plans, source_groups)
    smoothed["method"] = "mean_original_plus_5"
    result = pd.concat([baseline, smoothed], ignore_index=True)
    if result.groupby(["method", "mode"]).size().to_dict() != {
        (method, mode): 72 * (1 if mode == "clean" else 15)
        for method in ("original", "mean_original_plus_5")
        for mode in ("clean", *EVALUATION_MODES)
    }:
        raise ValueError("incomplete original or averaged ranking summary")
    if set(result.scan_id) != graph.EXPECTED_VALIDATION_PATIENTS:
        raise ValueError("unexpected patient in result")
    args.out_dir.mkdir(parents=True, exist_ok=True)
    result.to_csv(args.out_dir / "ranking_val.csv", index=False)
    metrics = summary(result)
    (args.out_dir / "summary.json").write_text(json.dumps({
        "status": "validation_ablation_only",
        "held_out_test_accessed": False,
        "training_performed": False,
        "identity_score": "JUNCTION geometry_score",
        "selected_local_model_pack_sha256": graph.sha256(SELECTED / "relation_models.joblib"),
        "saved_noisy_scores_sha256": graph.sha256(SAVED / "local_scores_val.csv.gz"),
        "evaluation_seed": 20260920,
        "evaluation_repetitions": 15,
        "inner_seed": INNER_SEED,
        "inner_copies": INNER_COPIES,
        "inner_position_sigma_mm_per_axis": INNER_POSITION_SIGMA_MM,
        "inner_tangent_sigma_degrees": 0.0,
        "max_recomputed_baseline_score_error": max_recomputed_score_error,
        "group_note": "competitive/isolated labels describe the source JUNCTION plan; scene_competitive describes actual false JUNCTION candidates in a scene.",
        "metrics": metrics,
    }, indent=2) + "\n")
    print(pd.DataFrame(metrics).to_string(index=False), flush=True)


if __name__ == "__main__":
    main()
