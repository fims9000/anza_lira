#!/usr/bin/env python3
"""Evaluate separate PAIR/JUNCTION geometry copy counts on frozen CT28 validation."""
from __future__ import annotations

import copy
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import run_ct28_graph_lira as graph
import train_ct28_perturbation_augmented_relation_head as augmentation
import train_ct28_relation_head as training


ROOT = training.REPO_ROOT
SCENES = graph.DEFAULT_SCENE_DIR
SAVED = ROOT / "varvara/anza_lira_local_results/ct28_copy_count_ablations"
GEOMETRY = SAVED / "geometry"
SELECTED = SAVED / "joint_check/fusion_10_relation_15"
OUT = ROOT / "varvara/anza_lira_local_results/ct28_independent_geometry_copy_sweep"
VARIANTS = ((5, 5), (5, 0), (5, 3), (5, 10), (0, 5), (3, 5), (10, 5), (10, 10))
TEST_IDS = {954, 958, 972, 973, 980, 984}
META = ("scene_id", "scan_id", "split", "scene_family", "relation_class", "augmentation_index")


def same_rows(first: pd.DataFrame, second: pd.DataFrame, columns: tuple[str, ...]) -> None:
    if not first[list(columns)].equals(second[list(columns)]):
        raise ValueError(f"saved scene rows differ: {columns}")


def mixed_noisy_features(pair: pd.DataFrame, junction: pd.DataFrame) -> pd.DataFrame:
    same_rows(pair, junction, META)
    result = pair.copy()
    columns = [name for name in result if name.startswith("geometry_score_junction_")]
    result[columns] = junction[columns]
    result["geometry_score_top_difference"] = (
        result.geometry_score_pair_top1 - result.geometry_score_junction_top1
    )
    result["geometry_score_top_sum"] = (
        result.geometry_score_pair_top1 + result.geometry_score_junction_top1
    )
    for kind in ("PAIR", "JUNCTION"):
        name = kind.lower()
        result[f"geometry_score_{name}_gap12_repeat"] = result[f"geometry_score_{name}_gap12"]
        result[f"geometry_score_{name}_count_repeat"] = result[f"geometry_score_{name}_candidate_count"]
    return result


def mixed_scores(pair: pd.DataFrame, junction: pd.DataFrame, selected: pd.DataFrame) -> pd.DataFrame:
    keys = ("scene_id", "candidate_id", "candidate_type", "scan_id", "split", "local_oof_fold")
    same_rows(pair, junction, keys)
    same_rows(pair, selected, keys)
    result = selected.copy()
    pair_mask = result.candidate_type.eq("PAIR")
    junction_mask = result.candidate_type.eq("JUNCTION")
    result.loc[pair_mask, "geometry_score"] = pair.loc[pair_mask, "geometry_score"].to_numpy()
    result.loc[junction_mask, "geometry_score"] = junction.loc[junction_mask, "geometry_score"].to_numpy()
    return result


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    plans = pd.read_csv(SCENES / "scene_plan_train_val.csv")
    candidates = pd.read_csv(SCENES / "scene_candidates_train_val.csv")
    training.validate_scene_inputs(plans, candidates)
    if set(plans.scan_id.astype(int)) & TEST_IDS or set(plans.split) != {"train", "val"}:
        raise ValueError("held-out test or unexpected split in scene pack")
    source = json.loads((SELECTED / "relation_model_protocol.json").read_text())["source_sha256"]
    actual = {key: training.sha256(SCENES / name) for key, name in (
        ("scene_plan", "scene_plan_train_val.csv"),
        ("scene_candidates", "scene_candidates_train_val.csv"),
        ("scene_candidate_features", "scene_candidate_features_train_val.csv"),
    )}
    if source != actual:
        raise ValueError("frozen scene SHA changed")
    baseline = joblib.load(SELECTED / "relation_models.joblib")
    selected_scores = pd.read_csv(SELECTED / "relation_local_scores_train_val.csv", float_precision="round_trip")
    selected_predictions = pd.read_csv(SELECTED / "relation_predictions_val.csv")
    selected_predictions = selected_predictions[selected_predictions.model.eq("ct_conditioned")]
    counts = sorted({count for pair, junction in VARIANTS for count in (pair, junction)})
    packs = {count: joblib.load(GEOMETRY / f"k{count:02d}" / "relation_models.joblib") for count in counts}
    score_tables = {count: pd.read_csv(GEOMETRY / f"k{count:02d}" / "relation_local_scores_train_val.csv",
                                      float_precision="round_trip") for count in counts}
    noisy_tables = {count: pd.read_csv(GEOMETRY / f"relation_train_copies_k{count:02d}.csv",
                                      float_precision="round_trip") for count in counts}
    for count in counts:
        if set(noisy_tables[count].split) != {"train"} or set(noisy_tables[count].scan_id.astype(int)) != training.EXPECTED_PATIENT_IDS["train"]:
            raise ValueError(f"K={count} noisy relation rows include non-train patients")
        if not np.array_equal(noisy_tables[count].augmentation_index.unique(), np.arange(1, 16)):
            raise ValueError(f"K={count} noisy relation repetitions changed")
        if not np.array_equal(score_tables[count].ct_score.to_numpy(), selected_scores.ct_score.to_numpy()):
            raise ValueError(f"K={count} clean CT evidence changed")
        ct_columns = [name for name in noisy_tables[5] if name.startswith("ct_score_")]
        if not np.array_equal(noisy_tables[count][ct_columns].to_numpy(),
                              noisy_tables[5][ct_columns].to_numpy()):
            raise ValueError(f"K={count} perturbed CT evidence changed")

    for pair_k, junction_k in VARIANTS:
        name = f"pair{pair_k:02d}_junction{junction_k:02d}"
        out = OUT / name
        out.mkdir(exist_ok=True)
        scores = mixed_scores(score_tables[pair_k], score_tables[junction_k], selected_scores)
        relation_rows, columns = graph.relation_feature_rows(
            plans, candidates, scores, ("geometry_score", "ct_score"))
        if columns != baseline["ct_conditioned_relation_features"] or len(columns) != 84:
            raise ValueError("84 relation feature order changed")
        noisy = mixed_noisy_features(noisy_tables[pair_k], noisy_tables[junction_k])
        if set(columns) - set(noisy.columns):
            raise ValueError("saved noisy relation feature columns changed")
        train = [dict(row, augmentation_index=0, sample_weight=0.5)
                 for row in relation_rows if row["split"] == "train"]
        validation = [row for row in relation_rows if row["split"] == "val"]
        noisy_rows = [dict(row, sample_weight=0.5/15) for row in noisy.to_dict("records")]
        augmented = train + noisy_rows
        augmentation.validate_augmentation_weights(augmented, 15)
        head, metrics, predictions = augmentation.fit_augmented_head(
            augmented, validation, columns, 0.85)
        geometry_rows, geometry_columns = graph.relation_feature_rows(
            plans, candidates, scores, ("geometry_score",))
        _, geometry_predictions, geometry_head = training.fit_relation_head(
            geometry_rows, geometry_columns, 0.85, "geometry_only")
        if pair_k == junction_k == 5:
            observed = pd.DataFrame(predictions)
            for field in ("probability_none", "probability_pair", "probability_junction", "probability_both"):
                error = float(np.max(np.abs(observed[field].to_numpy() - selected_predictions[field].to_numpy())))
                if error > 1e-10:
                    raise ValueError(f"selected 52/0 control failed relation reproduction: {field} {error}")
            if not np.array_equal(scores.geometry_score.to_numpy(), selected_scores.geometry_score.to_numpy()):
                raise ValueError("selected geometry scores changed")
        pack = copy.deepcopy(baseline)
        pack["local_models"]["PAIR"]["geometry"] = packs[pair_k]["local_models"]["PAIR"]["geometry"]
        pack["local_models"]["JUNCTION"]["geometry"] = packs[junction_k]["local_models"]["JUNCTION"]["geometry"]
        pack["relation_heads"]["ct_conditioned"] = head
        pack["relation_heads"]["geometry_only"] = geometry_head
        pack["geometry_relation_features"] = geometry_columns
        joblib.dump(pack, out / "relation_models.joblib")
        scores.to_csv(out / "relation_local_scores_train_val.csv", index=False)
        pd.DataFrame(geometry_predictions + predictions).to_csv(out / "relation_predictions_val.csv", index=False)
        (out / "relation_metrics_val.json").write_text(json.dumps(metrics, indent=2) + "\n")
        (out / "relation_model_protocol.json").write_text(json.dumps({
            "status": "validation_ablation_not_frozen", "held_out_test_accessed": False,
            "source_sha256": source,
            "pair_geometry_train_copy_count": pair_k,
            "junction_geometry_train_copy_count": junction_k,
            "geometry_noise": "position_only_0.8mm",
            "pair_geometry_clean_weight": 1.0 if pair_k == 0 else 0.5,
            "junction_geometry_clean_weight": 1.0 if junction_k == 0 else 0.5,
            "geometry_noisy_total_weight_if_augmented": 0.5,
            "pair_fusion_train_copy_count": 10,
            "relation_train_copy_count": 15,
            "relation_noise": "joint_0.8mm_20deg",
            "relation_clean_weight": 0.5,
            "pair_identity": "geometry_plus_ct_score",
            "junction_identity": "geometry_score",
            "tau": 0.85, "consistency": 0.60, "evaluation_perturbations": 15,
        }, indent=2) + "\n")
        print(f"{name}: relation model fitted", flush=True)


if __name__ == "__main__":
    main()
