#!/usr/bin/env python3
"""Replace only selected JUNCTION geometry local evidence with train-joint-noise HGB."""
from __future__ import annotations

import copy
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import run_ct28_graph_lira as graph
import train_ct28_perturbation_augmented_relation_head as augmentation
import train_ct28_relation_head as training


ROOT = training.REPO_ROOT
SCENES = graph.DEFAULT_SCENE_DIR
SWEEP = ROOT / "varvara/anza_lira_local_results/ct28_copy_count_ablations"
SELECTED = SWEEP / "joint_check/fusion_10_relation_15"
COPIES = SWEEP / "relation/joint_train_relation_copies.csv"
ROBUST = ROOT / "varvara/anza_lira_local_results/ct28_geometry_augmentation_matrix/joint/junction"
OUTPUT = SWEEP / "joint_junction_geometry_selected"
TEST_IDS = {954, 958, 972, 973, 980, 984}


def splice_junction_geometry(selected: pd.DataFrame, robust: pd.DataFrame) -> pd.DataFrame:
    keys = ["scene_id", "augmentation_index"]
    if not selected[keys].equals(robust[keys]):
        raise ValueError("train scene/repetition order changed")
    for field in ("scan_id", "relation_class", "split"):
        if not selected[field].equals(robust[field]):
            raise ValueError(f"train copy metadata changed: {field}")
    junction = [column for column in selected
                if column.startswith("geometry_score_junction_") and not column.endswith("_repeat")]
    if len(junction) != 18 or not np.isfinite(robust[junction].to_numpy(dtype=float)).all():
        raise ValueError("JUNCTION geometry train evidence is incomplete")
    result = selected.copy()
    result.loc[:, junction] = robust[junction].to_numpy()
    result["geometry_score_top_difference"] = (
        result.geometry_score_pair_top1 - result.geometry_score_junction_top1
    )
    result["geometry_score_top_sum"] = (
        result.geometry_score_pair_top1 + result.geometry_score_junction_top1
    )
    result["geometry_score_junction_gap12_repeat"] = result.geometry_score_junction_gap12
    result["geometry_score_junction_count_repeat"] = result.geometry_score_junction_candidate_count
    return result


def main() -> None:
    plans = pd.read_csv(SCENES / "scene_plan_train_val.csv")
    candidates = pd.read_csv(SCENES / "scene_candidates_train_val.csv")
    source_scores = pd.read_csv(SELECTED / "relation_local_scores_train_val.csv")
    robust_scores = pd.read_csv(ROBUST / "relation_local_scores_train_val.csv")
    source_predictions = pd.read_csv(SELECTED / "relation_predictions_val.csv")
    source_pack = joblib.load(SELECTED / "relation_models.joblib")
    robust_pack = joblib.load(ROBUST / "relation_models.joblib")
    source_protocol = json.loads((SELECTED / "relation_model_protocol.json").read_text())
    robust_protocol = json.loads((ROBUST / "relation_model_protocol.json").read_text())
    copies = pd.read_csv(COPIES, float_precision="round_trip")
    robust_copies = pd.read_csv(ROBUST / "augmented_relation_rows_train.csv", float_precision="round_trip")

    training.validate_scene_inputs(plans, candidates)
    if (set(plans.scan_id.astype(int)) | set(copies.scan_id.astype(int))
            | set(robust_copies.scan_id.astype(int))) & TEST_IDS:
        raise ValueError("held-out test patient entered ablation")
    if source_protocol["source_sha256"] != robust_protocol["source_sha256"]:
        raise ValueError("frozen scene source differs")
    if source_protocol["pair_fusion_train_copy_count"] != 10 or source_protocol["relation_train_copy_count"] != 15:
        raise ValueError("source is not selected K10/K15")
    if robust_protocol["selected_geometry_local_models"] != [["JUNCTION", "joint"]]:
        raise ValueError("source is not joint-noise JUNCTION geometry model")
    if robust_protocol["local_train_copies"] != 5 or robust_protocol["relation_train_copies"] != 15:
        raise ValueError("unexpected robust train-copy protocol")
    if robust_protocol["relation_noise"] != {"position_sigma_mm": 0.8, "tangent_sigma_deg": 20.0}:
        raise ValueError("robust relation perturbation settings differ")
    for key, filename in (
        ("scene_plan", "scene_plan_train_val.csv"),
        ("scene_candidates", "scene_candidates_train_val.csv"),
        ("scene_candidate_features", "scene_candidate_features_train_val.csv"),
    ):
        if training.sha256(SCENES / filename) != source_protocol["source_sha256"][key]:
            raise ValueError(f"scene source changed: {key}")
    keys = ["scene_id", "candidate_id", "candidate_type", "scan_id", "split", "local_oof_fold", "y"]
    if not source_scores[keys].equals(robust_scores[keys]):
        raise ValueError("candidate/OOF mapping differs")
    for field in ("ct_score",):
        if not np.allclose(source_scores[field], robust_scores[field], rtol=0, atol=1e-12):
            raise ValueError(f"frozen CT evidence changed: {field}")
    scores = source_scores.copy()
    mask = scores.candidate_type.eq("JUNCTION")
    scores.loc[mask, "geometry_score"] = robust_scores.loc[mask, "geometry_score"].to_numpy()
    OUTPUT.mkdir(parents=True, exist_ok=True)
    scores.to_csv(OUTPUT / "relation_local_scores_train_val.csv", index=False)
    scores = pd.read_csv(OUTPUT / "relation_local_scores_train_val.csv")
    clean_rows, columns = graph.relation_feature_rows(plans, candidates, scores,
                                                       ("geometry_score", "ct_score"))
    if len(columns) != 84:
        raise ValueError("relation input is not 84 features")
    clean_train = [dict(row, augmentation_index=0, sample_weight=0.5)
                   for row in clean_rows if row["split"] == "train"]
    validation = [row for row in clean_rows if row["split"] == "val"]
    if len(clean_train) != 1036 or len(validation) != 368 or len(copies) != 15 * 1036:
        raise ValueError("train/validation scene count changed")
    if set(copies.augmentation_index.astype(int)) != set(range(1, 16)):
        raise ValueError("train relation copies incomplete")
    ct_columns = [column for column in copies if column.startswith("ct_score_")]
    if not np.allclose(copies[ct_columns], robust_copies[ct_columns], rtol=0, atol=1e-12):
        raise ValueError("frozen CT train-copy evidence changed")
    combined = splice_junction_geometry(copies, robust_copies)
    noisy = combined.to_dict("records")
    for row in noisy:
        row["sample_weight"] = 0.5 / 15
    train = clean_train + noisy
    augmentation.validate_augmentation_weights(train, 15)
    head, metrics, predictions = augmentation.fit_augmented_head(train, validation, columns, 0.85)
    pack = copy.deepcopy(source_pack)
    pack["local_models"]["JUNCTION"]["geometry"] = robust_pack["local_models"]["JUNCTION"]["geometry"]
    pack["relation_heads"]["ct_conditioned"] = head
    pack["ct_conditioned_relation_features"] = columns
    val_plans = plans[plans.split.eq("val")]
    val_candidates = candidates[candidates.scene_id.isin(val_plans.scene_id)]
    val_scores = scores[scores.scene_id.isin(val_plans.scene_id)]
    geometry_predictions = graph.predict_relations(
        val_plans, val_candidates, val_scores, pack, 0.85
    )["geometry_only"]
    geometry_rows = source_predictions[source_predictions.model.eq("geometry_only")].copy()
    for index, row in geometry_rows.iterrows():
        decision = geometry_predictions[row.scene_id]
        geometry_rows.loc[index, "raw_prediction"] = decision["raw_relation"]
        geometry_rows.loc[index, "tau_prediction"] = decision["relation"]
        geometry_rows.loc[index, "confidence"] = decision["confidence"]
        for probability_index, name in enumerate(training.RELATION_CLASSES):
            geometry_rows.loc[index, f"probability_{name.lower()}"] = decision["probabilities"][probability_index]
    joblib.dump(pack, OUTPUT / "relation_models.joblib")
    pd.concat([geometry_rows, pd.DataFrame(predictions)], ignore_index=True).to_csv(
        OUTPUT / "relation_predictions_val.csv", index=False)
    (OUTPUT / "relation_metrics_val.json").write_text(json.dumps(metrics, indent=2) + "\n")
    (OUTPUT / "relation_model_protocol.json").write_text(json.dumps({
        "status": "validation_ablation_not_frozen", "held_out_test_accessed": False,
        "source_sha256": source_protocol["source_sha256"],
        "selected_source": str(SELECTED), "robust_junction_source": str(ROBUST),
        "train_copies_sha256": training.sha256(COPIES),
        "robust_train_copies_sha256": training.sha256(ROBUST / "augmented_relation_rows_train.csv"),
        "changed_local_stream": "JUNCTION geometry; five joint-noise train copies, patient-level OOF",
        "unchanged_local_streams": ["PAIR geometry", "PAIR CT", "JUNCTION CT", "PAIR fusion", "JUNCTION fusion"],
        "geometry_only_output_note": "unchanged geometry-only head rescored with new JUNCTION geometry evidence for the pipeline consistency check; do not interpret as a refitted geometry-only comparator",
        "relation_head": "HGB refit on clean + 15 joint-noise train copies, total weights 0.5/0.5",
        "pair_identity": "geometry_plus_ct_score", "junction_identity": "geometry_score",
        "tau": 0.85, "consistency": 0.60, "evaluation_perturbations": 15,
    }, indent=2) + "\n")
    print(f"JUNCTION joint-noise local evidence ready; raw relation accuracy {metrics['raw']['accuracy']:.4f}")


if __name__ == "__main__":
    main()
