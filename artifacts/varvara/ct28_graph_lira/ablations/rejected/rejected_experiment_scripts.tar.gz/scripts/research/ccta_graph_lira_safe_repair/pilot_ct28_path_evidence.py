#!/usr/bin/env python3
"""Train-only matched true/false CT path evidence; no masks, VTK or model fitting."""
from pathlib import Path
import argparse
from dataclasses import asdict
import hashlib
import inspect
import json
import time

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score
from scipy.stats import spearmanr

import ct28_path_stage as path
import run_ct28_graph_lira as graph
from run_ct28_path_stage import validate_route_geometry
from ct28_perturbations import perturb_scene_endpoints

ROOT=graph.REPO_ROOT
OUT=ROOT/'varvara/anza_lira_local_results/ct28_path_evidence_pilot_v1'
SCORES=ROOT/'varvara/anza_lira_local_results/ct28_copy_count_ablations/joint_check/fusion_10_relation_15/relation_local_scores_train_val.csv'
PATH_PROTOCOL=graph.DEFAULT_SCENE_DIR/'path/selected_path_protocol.json'
TRAIN_IDS=graph.relation_training.EXPECTED_PATIENT_IDS['train']
REPETITIONS=5
PRIMARY='path_bottleneck'
SECONDARY='worst_arm_edge_q10'
XYZ=['x_lps','y_lps','z_lps']
TANGENT=['tangent_x','tangent_y','tangent_z']


def select_plan(plans,candidates,scores):
    plans=plans[plans.split.eq('train')]
    if set(plans.scan_id.astype(int))!=TRAIN_IDS:
        raise ValueError('frozen 17-patient train cohort changed')
    records=[]
    for kind,family in [('PAIR','pair_only'),('JUNCTION','junction_only')]:
        rows=candidates[candidates.candidate_type.eq(kind)].merge(
            plans[plans.scene_family.eq(family)][['scene_id','scan_id','split','scene_family']],
            on='scene_id',validate='many_to_one')
        eligible=rows.groupby('scene_id').y.agg(['min','max'])
        ids=set(eligible.index[(eligible['min']==0)&(eligible['max']==1)])
        choices=rows[rows.scene_id.isin(ids)][['scan_id','scene_id']].drop_duplicates().sort_values('scene_id').groupby('scan_id').head(1)
        if set(choices.scan_id.astype(int))!=TRAIN_IDS:
            raise ValueError(f'not all train patients have a competitive {kind} scene')
        for scene in choices.itertuples(index=False):
            pool=rows[rows.scene_id.eq(scene.scene_id)].merge(
                scores[['scene_id','candidate_id','geometry_score','ct_score']],
                on=['scene_id','candidate_id'],validate='one_to_one')
            positive=pool[pool.y.eq(1)]
            if len(positive)!=1:raise ValueError('scene has multiple true relations')
            negative=pool[pool.y.eq(0)].sort_values(['geometry_score','candidate_id'],ascending=[False,True]).head(1)
            for row in pd.concat([positive,negative]).itertuples(index=False):
                records.append(dict(scan_id=int(row.scan_id),split='train',scene_id=row.scene_id,
                    scene_family=family,candidate_id=row.candidate_id,candidate_type=kind,
                    endpoint_ids=row.endpoint_ids,y=int(row.y),
                    clean_geometry_oof_score=float(row.geometry_score),clean_ct_oof_score=float(row.ct_score)))
    frame=pd.DataFrame(records).sort_values(['scan_id','candidate_type','scene_id','y'],ascending=[True,True,True,False]).reset_index(drop=True)
    if len(frame)!=68 or frame.scene_id.nunique()!=34:raise ValueError('pilot selection changed')
    return frame


def path_evidence(ct,affine,positions,tangents,config):
    """Only observed candidate geometry and verified CT enter this function."""
    defaults=dict(path_valid=0,path_bottleneck=0.,worst_arm_edge_q10=0.,worst_arm_mean_support=0.,
                  total_length_mm=np.nan,length_over_straight=np.nan,worst_arm_stretch=np.nan,
                  center_refinement_mm=np.nan,vessel_hu=np.nan,background_hu=np.nan,contrast_hu=np.nan,
                  arm_bottlenecks='[]',arm_lengths_mm='[]')
    try:
        result=path.solve_path_with_bottleneck_slack(ct,affine,positions,tangents,config,.05)
    except ValueError as error:
        expected=('outside CT','exits CT','exceeds 300000','map to one CT voxel','center coincides')
        if not any(message in str(error) for message in expected):raise
        return dict(status='invalid_observed_geometry',error=str(error),**defaults)
    defaults.update(vessel_hu=result.vessel_hu,background_hu=result.background_hu,contrast_hu=result.contrast_hu)
    if result.status!='ok':return dict(status=result.status,error='',**defaults)
    validate_route_geometry(result,positions,affine)
    junction=len(positions)==3
    center=np.asarray(result.center_lps) if junction else positions.mean(axis=0)
    edges=[];q10=[];mean_support=[];lengths=[];straight=[]
    for index,route in enumerate(result.paths_voxel):
        vox=np.asarray(route,dtype=int)
        hu=np.asarray(ct[tuple(vox.T)],dtype=np.float32)
        support=path.voxel_support(hu,result.vessel_hu,result.background_hu,config)
        edge=np.minimum(support[:-1],support[1:])*np.exp(-np.abs(np.diff(hu.astype(float)))/config.hu_difference_scale)
        edges.append(float(edge.min()));q10.append(float(np.quantile(edge,.1)));mean_support.append(float(support.mean()))
        lengths.append(float(np.linalg.norm(np.diff(vox,axis=0) @ affine[:3,:3].T,axis=1).sum()))
        straight.append(float(np.linalg.norm(positions[index]-center) if junction else np.linalg.norm(positions[0]-positions[1])))
    if not np.isclose(min(edges),result.bottleneck,atol=1e-10,rtol=1e-9):raise ValueError('path bottleneck recomputation differs')
    if not np.isclose(sum(lengths),result.length_mm,atol=1e-7,rtol=1e-9):raise ValueError('path length recomputation differs')
    initial_center=path.estimate_junction_center(positions,tangents) if junction else center
    return dict(status='ok',error='',path_valid=1,path_bottleneck=min(edges),worst_arm_edge_q10=min(q10),
        worst_arm_mean_support=min(mean_support),total_length_mm=sum(lengths),
        length_over_straight=sum(lengths)/max(sum(straight),1e-8),
        worst_arm_stretch=max(a/max(b,1e-8) for a,b in zip(lengths,straight)),
        center_refinement_mm=float(np.linalg.norm(center-initial_center)) if junction else np.nan,
        vessel_hu=result.vessel_hu,background_hu=result.background_hu,contrast_hu=result.contrast_hu,
        arm_bottlenecks=json.dumps(edges),arm_lengths_mm=json.dumps(lengths))


def check_synthetic(config):
    ct=np.zeros((25,25,25),dtype=np.float32)
    yy,zz=np.indices((25,25));ct[:,(yy-12)**2+(zz-12)**2<=2.25]=350.
    affine=np.diag([.5,.5,.5,1.]);positions=path.voxel_to_lps(np.array([[5,12,12],[19,12,12]]),affine)
    tangents=np.array([[-1.,0.,0.],[1.,0.,0.]])
    intact=path_evidence(ct,affine,positions,tangents,config)
    ct[12,:,:]=0.
    gap=path_evidence(ct,affine,positions,tangents,config)
    if not intact['path_valid'] or not gap['path_valid'] or intact[PRIMARY]<=gap[PRIMARY]:
        raise ValueError('synthetic bright-tube / gap evidence check failed')
    return dict(intact_bottleneck=intact[PRIMARY],gap_bottleneck=gap[PRIMARY])



def audit_endpoint_support(out,archive_dir,config):
    plan=pd.read_csv(out/'pilot_plan_train.csv')
    features=pd.read_csv(out/'path_features_train.csv').set_index(['scene_id','candidate_id','repetition'])
    if set(plan.scan_id.astype(int))!=TRAIN_IDS or len(features)!=408:
        raise ValueError('endpoint audit requires the complete train-only pilot')
    endpoints=pd.read_csv(graph.DEFAULT_SCENE_DIR/'scene_endpoints_train_val.csv')
    geometry=pd.read_csv(graph.ct_features.EXPECTED_GEOMETRY).set_index('scan_id')
    alignment=pd.read_csv(graph.ct_features.EXPECTED_ALIGNMENT).set_index('scan_id')
    records=[]
    for patient in sorted(TRAIN_IDS):
        ct,inverse=graph.load_verified_ct(patient,archive_dir,geometry,alignment)
        for scene,group in plan[plan.scan_id.eq(patient)].groupby('scene_id'):
            clean=endpoints[endpoints.scene_id.eq(scene)]
            for rep in range(-1,REPETITIONS):
                observed=clean if rep==-1 else perturb_scene_endpoints(clean,seed=20260920,
                    repetition=rep,position_noise_mm=.8,tangent_noise_deg=0.)
                lookup=observed.set_index('endpoint_id')
                for candidate in group.itertuples():
                    source=features.loc[(scene,candidate.candidate_id,rep)]
                    vox=np.rint(path.lps_to_voxel(lookup.loc[candidate.endpoint_ids.split('|'),XYZ].to_numpy(),inverse)).astype(int)
                    inside=bool(np.all(vox>=0) and np.all(vox<np.asarray(ct.shape)))
                    hu=np.asarray(ct[tuple(vox.T)],dtype=np.float32) if inside else np.array([np.nan])
                    ceiling=(float(path.voxel_support(hu,source.vessel_hu,source.background_hu,config).min())
                             if inside and np.isfinite(source.vessel_hu) and np.isfinite(source.background_hu) else np.nan)
                    records.append(dict(scan_id=patient,scene_id=scene,candidate_id=candidate.candidate_id,
                        candidate_type=candidate.candidate_type,y=candidate.y,repetition=rep,
                        mode='clean' if rep==-1 else 'position_only',endpoint_inside_ct=int(inside),
                        endpoint_hu_min=float(hu.min()),endpoint_hu_median=float(np.median(hu)),
                        endpoint_support_ceiling=ceiling,path_valid=int(source.path_valid),
                        path_bottleneck=float(source.path_bottleneck),
                        bottleneck_to_endpoint_ceiling=float(source.path_bottleneck/max(ceiling,1e-300))
                        if source.path_valid and np.isfinite(ceiling) else np.nan))
        print(f'endpoint support audit: train patient {patient} done',flush=True)
        del ct
    pd.DataFrame(records).to_csv(out/'endpoint_audit_train.csv',index=False)


def summarize(out):
    protocol=json.loads((out/'protocol.json').read_text())
    plan=pd.read_csv(out/'pilot_plan_train.csv')
    features=pd.read_csv(out/'path_features_train.csv',float_precision='round_trip')
    if len(features)!=408 or features[['scene_id','candidate_id','repetition']].duplicated().any():
        raise ValueError('expected all 408 candidate/views including failures')
    if set(features.scan_id.astype(int))!=TRAIN_IDS:raise ValueError('non-train patient entered pilot')
    if not features.groupby(['scene_id','repetition']).y.agg(['sum','size']).eq([1,2]).all().all():
        raise ValueError('matched true/false comparison is incomplete')
    paired=[]
    for (scene,rep),group in features.groupby(['scene_id','repetition'],sort=True):
        true=group[group.y.eq(1)].iloc[0];false=group[group.y.eq(0)].iloc[0]
        row=dict(scene_id=scene,scan_id=int(true.scan_id),candidate_type=true.candidate_type,
                 repetition=int(rep),mode='clean' if rep==-1 else 'position_only',
                 true_path_valid=int(true.path_valid),false_path_valid=int(false.path_valid))
        for score in (PRIMARY,SECONDARY):
            margin=float(true[score]-false[score])
            row[score+'_margin']=margin;row[score+'_win']=1. if margin>0 else (0. if margin<0 else .5)
            row[score+'_tie']=int(margin==0.)
        paired.append(row)
    paired=pd.DataFrame(paired);paired.to_csv(out/'paired_comparisons_train.csv',index=False)
    per_patient=paired.groupby(['candidate_type','mode','scan_id']).agg(
        comparisons=('scene_id','size'),bottleneck_win=(PRIMARY+'_win','mean'),
        bottleneck_margin=(PRIMARY+'_margin','mean'),worst_q10_win=(SECONDARY+'_win','mean'),
        true_path_valid=('true_path_valid','mean'),false_path_valid=('false_path_valid','mean')).reset_index()
    per_patient.to_csv(out/'per_patient_train.csv',index=False)
    clean_lookup=features[features.repetition.eq(-1)].set_index(['scene_id','candidate_id'])
    noisy=features[features.repetition.ge(0)].copy()
    baseline=clean_lookup.loc[pd.MultiIndex.from_frame(noisy[['scene_id','candidate_id']]),PRIMARY].to_numpy()
    noisy['bottleneck_change']=noisy[PRIMARY].to_numpy()-baseline
    stats={}
    for kind in ('PAIR','JUNCTION'):
        stats[kind]={}
        for mode,mask in [('clean',features.repetition.eq(-1)),('position_only',features.repetition.ge(0))]:
            group=features[features.candidate_type.eq(kind)&mask]
            matched=paired[paired.candidate_type.eq(kind)&paired['mode'].eq(mode)]
            patient=per_patient[per_patient.candidate_type.eq(kind)&per_patient['mode'].eq(mode)]
            rng=np.random.default_rng(20260920)
            values=patient.bottleneck_win.to_numpy()
            bootstrap=rng.choice(values,size=(1000,len(values)),replace=True).mean(axis=1)
            valid_group=group[group.path_valid.eq(1)]
            both_valid=matched[matched.true_path_valid.eq(1)&matched.false_path_valid.eq(1)]
            valid_auc=(float(roc_auc_score(valid_group.y,valid_group[PRIMARY]))
                       if valid_group.y.nunique()==2 else None)
            stats[kind][mode]=dict(candidates=len(group),matched_pairs=len(matched),patients=len(patient),
                path_availability_auroc=float(roc_auc_score(group.y,group.path_valid)),
                bottleneck_auroc_conditional_valid=valid_auc,
                both_paths_valid_pairs=len(both_valid),
                bottleneck_win_conditional_both_valid=float(both_valid[PRIMARY+'_win'].mean()) if len(both_valid) else None,
                bottleneck_auroc=float(roc_auc_score(group.y,group[PRIMARY])),
                bottleneck_paired_win=float(matched[PRIMARY+'_win'].mean()),
                bottleneck_strict_wins=int((matched[PRIMARY+'_win']==1).sum()),ties=int(matched[PRIMARY+'_tie'].sum()),
                bottleneck_win_patient_bootstrap95=np.quantile(bootstrap,[.025,.975]).tolist(),
                worst_q10_auroc=float(roc_auc_score(group.y,group[SECONDARY])),
                worst_q10_paired_win=float(matched[SECONDARY+'_win'].mean()),
                true_path_success=float(group.loc[group.y.eq(1),'path_valid'].mean()),
                false_path_success=float(group.loc[group.y.eq(0),'path_valid'].mean()))
            for metric in ('length_over_straight','worst_arm_stretch'):
                paired_length=valid_group.pivot(index=['scene_id','repetition'],columns='y',values=metric).dropna()
                stats[kind][mode][metric+'_auroc_conditional_valid']=(
                    float(roc_auc_score(valid_group.y,-valid_group[metric])) if valid_group.y.nunique()==2 else None)
                stats[kind][mode][metric+'_paired_win_conditional_valid']=(
                    float(((paired_length[1]<paired_length[0]).astype(float)+.5*(paired_length[1]==paired_length[0])).mean())
                    if len(paired_length) else None)
        for y,label in [(1,'true'),(0,'hard_negative')]:
            g=noisy[noisy.candidate_type.eq(kind)&noisy.y.eq(y)]
            source=clean_lookup.loc[pd.MultiIndex.from_frame(g[['scene_id','candidate_id']]),PRIMARY].to_numpy()
            correlation=spearmanr(source,g[PRIMARY]).statistic if np.std(source)>0 and g[PRIMARY].std()>0 else np.nan
            stats[kind][label+'_stability']=dict(mean_abs_bottleneck_change=float(g.bottleneck_change.abs().mean()),
                median_change=float(g.bottleneck_change.median()),clean_noisy_spearman=float(correlation) if np.isfinite(correlation) else None)
    features.groupby(['candidate_type','repetition','y','status']).size().rename('rows').to_csv(out/'status_counts_train.csv')
    result=dict(status='train_only_feature_pilot_not_graph_lira_evaluation',held_out_test_accessed=False,
        validation_scored=False,validation_volumes_loaded=False,models_trained=False,train_patients=sorted(TRAIN_IDS),
        candidate_rows=len(plan),candidate_views=len(features),matched_pairs=len(paired),
        primary_score=PRIMARY,secondary_score=SECONDARY,statistics=stats,
        interpretation='Matched hard-negative pilot only; pooled AUROC is not population performance; noisy repeats are clustered by patient; failed routes remain as zero evidence; no learned score or threshold selected.',
        protocol_sha256=graph.sha256(out/'protocol.json'),features_sha256=graph.sha256(out/'path_features_train.csv'),
        summarizer_sha256=graph.sha256(Path(__file__)))
    endpoint_file=out/'endpoint_audit_train.csv'
    if endpoint_file.exists():
        endpoint=pd.read_csv(endpoint_file)
        endpoint_rows=[]
        for (kind,y,mode),g in endpoint.groupby(['candidate_type','y','mode']):
            endpoint_rows.append(dict(candidate_type=kind,y=int(y),mode=mode,rows=len(g),
                endpoint_hu_min_median=float(g.endpoint_hu_min.median()),
                endpoint_support_ceiling_median=float(g.endpoint_support_ceiling.median()),
                bottleneck_to_endpoint_ceiling_median=float(g.bottleneck_to_endpoint_ceiling.median())))
        result['posthoc_endpoint_audit']=dict(sha256=graph.sha256(endpoint_file),groups=endpoint_rows,
            interpretation='Endpoint support is an upper bound on any exact-endpoint max-min route; this is localization only, not a corrected inference method.')
    (out/'metrics.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(stats,indent=2),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive-dir',type=Path,default=graph.DEFAULT_ARCHIVE_DIR)
    parser.add_argument('--out-dir',type=Path,default=OUT)
    parser.add_argument('--summarize-only',action='store_true')
    parser.add_argument('--check-only',action='store_true')
    parser.add_argument('--audit-endpoints',action='store_true')
    args=parser.parse_args()
    frozen=json.loads(PATH_PROTOCOL.read_text());config=path.PathConfig(**frozen['config'])
    if args.summarize_only:summarize(args.out_dir);return
    if args.audit_endpoints:
        audit_endpoint_support(args.out_dir,args.archive_dir,config)
        summarize(args.out_dir)
        return
    synthetic=check_synthetic(config);print('synthetic tube/gap check',synthetic,flush=True)
    if args.check_only:return
    args.out_dir.mkdir(parents=True,exist_ok=True)
    sources=dict(plans=graph.DEFAULT_SCENE_DIR/'scene_plan_train_val.csv',
        candidates=graph.DEFAULT_SCENE_DIR/'scene_candidates_train_val.csv',
        endpoints=graph.DEFAULT_SCENE_DIR/'scene_endpoints_train_val.csv',scores=SCORES,
        frozen_path_config=PATH_PROTOCOL,expected_geometry=graph.ct_features.EXPECTED_GEOMETRY,
        expected_alignment=graph.ct_features.EXPECTED_ALIGNMENT,
        path_solver=Path(path.__file__),perturbation=Path(inspect.getfile(perturb_scene_endpoints)))
    plans=pd.read_csv(sources['plans']);candidates=pd.read_csv(sources['candidates']);scores=pd.read_csv(SCORES)
    # Candidate selection and CT extraction use train rows only.
    plan=select_plan(plans,candidates,scores[scores.split.eq('train')])
    endpoints=pd.read_csv(sources['endpoints']);endpoints=endpoints[endpoints.scene_id.isin(plan.scene_id)]
    plan_path=args.out_dir/'pilot_plan_train.csv';plan.to_csv(plan_path,index=False)
    protocol=dict(name='ct28_path_evidence_train_pilot_v1',held_out_test_accessed=False,validation_scored=False,validation_volumes_loaded=False,
        sample='first eligible scene lexicographically per train patient/type; one true and geometry-OOF-highest false; no CT-based selection',
        candidates=68,matched_sources=34,patients=sorted(TRAIN_IDS),path_config=asdict(config),slack_fraction=.05,
        candidate_only_solver=True,unselected_endpoint_mask=False,mask_and_VTK_inputs=False,
        noise=dict(repetitions=5,position_sigma_mm=.8,tangent_sigma_degrees=0.,seed=20260920,
                   shared_scene_jitter=True,candidate_pool_refiltered=False),
        scores=dict(primary=PRIMARY,secondary=SECONDARY,failed_route_evidence=0.,ties_in_paired_win=.5),
        frozen_graph_gates_not_applied_or_changed=dict(tau=.85,consistency=.60),
        synthetic_check=synthetic,plan_sha256=graph.sha256(plan_path),
        extractor_sha256=hashlib.sha256(inspect.getsource(path_evidence).encode()).hexdigest(),
        source_sha256={k:graph.sha256(v) for k,v in sources.items()})
    protocol_path=args.out_dir/'protocol.json'
    if protocol_path.exists() and json.loads(protocol_path.read_text())!=protocol:
        raise ValueError('pilot input/config changed; refusing to reuse extracted features')
    protocol_path.write_text(json.dumps(protocol,indent=2)+'\n')
    output=args.out_dir/'path_features_train.csv'
    done=set()
    if output.exists():
        old=pd.read_csv(output)
        done=set(zip(old.scene_id,old.candidate_id,old.repetition))
    geometry=pd.read_csv(graph.ct_features.EXPECTED_GEOMETRY).set_index('scan_id')
    alignment=pd.read_csv(graph.ct_features.EXPECTED_ALIGNMENT).set_index('scan_id')
    for patient in sorted(TRAIN_IDS):
        patient_plan=plan[plan.scan_id.eq(patient)]
        expected={(r.scene_id,r.candidate_id,rep) for r in patient_plan.itertuples() for rep in range(-1,REPETITIONS)}
        if expected<=done:continue
        ct,inverse=graph.load_verified_ct(patient,args.archive_dir,geometry,alignment);affine=np.linalg.inv(inverse)
        for scene_id,group in patient_plan.groupby('scene_id',sort=True):
            clean_endpoints=endpoints[endpoints.scene_id.eq(scene_id)]
            for rep in range(-1,REPETITIONS):
                observed=clean_endpoints.copy()
                if rep>=0:
                    observed=perturb_scene_endpoints(clean_endpoints,seed=20260920,repetition=rep,
                        position_noise_mm=.8,tangent_noise_deg=0.)
                    observed.loc[:,TANGENT]=clean_endpoints[TANGENT].to_numpy()
                lookup=observed.set_index('endpoint_id')
                for candidate in group.itertuples(index=False):
                    key=(scene_id,candidate.candidate_id,rep)
                    if key in done:continue
                    rows=lookup.loc[candidate.endpoint_ids.split('|')]
                    positions=rows[XYZ].to_numpy(dtype=float);tangents=rows[TANGENT].to_numpy(dtype=float)
                    started=time.monotonic();evidence=path_evidence(ct,affine,positions,tangents,config)
                    span=float(np.max(np.linalg.norm(positions[:,None]-positions[None,:],axis=-1)))
                    record=dict(scan_id=patient,split='train',scene_id=scene_id,candidate_id=candidate.candidate_id,
                        candidate_type=candidate.candidate_type,y=int(candidate.y),repetition=rep,
                        observed_span_mm=span,exceeds_historical_span=int(span>(12 if candidate.candidate_type=='PAIR' else 16)),
                        ct_alignment_verified=1,seconds=time.monotonic()-started,**evidence)
                    pd.DataFrame([record]).to_csv(output,mode='a',index=False,header=not output.exists())
                    done.add(key)
            print(f'patient {patient} {group.iloc[0].candidate_type}: clean+5 shifts, true+false done; {len(done)}/408',flush=True)
        del ct
    summarize(args.out_dir)


if __name__=='__main__':main()
