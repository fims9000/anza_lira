#!/usr/bin/env python3
"""Fixed CE versus CE+JS relation MLP ablation on frozen K10/15 representations."""
from pathlib import Path
import argparse
import json

import joblib
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import logsumexp
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

import evaluate_ct28_recovery as recovery
import run_ct28_graph_lira as graph
import train_ct28_relation_head as training
from train_ct28_confidence_ensemble import confidence_diagnostics, validate_probabilities

OUT = graph.REPO_ROOT / 'varvara/anza_lira_local_results/ct28_probability_consistency_v1'
HIDDEN = 64
L2 = 0.001
ITERATIONS = 1000


def unpack(theta, inputs, hidden):
    first = inputs * hidden
    second = first + hidden
    third = second + hidden * 4
    return (theta[:first].reshape(inputs, hidden), theta[first:second],
            theta[second:third].reshape(hidden, 4), theta[third:])


def initialize(inputs, hidden, seed=0):
    rng = np.random.default_rng(seed)
    return np.concatenate([
        rng.normal(0, np.sqrt(2/(inputs+hidden)), (inputs,hidden)).ravel(), np.zeros(hidden),
        rng.normal(0, np.sqrt(2/(hidden+4)), (hidden,4)).ravel(), np.zeros(4)])


def objective(theta, views, labels, class_weights, coefficient, hidden=HIDDEN, l2=L2,
              js_class_multipliers=None):
    scenes, versions, inputs = views.shape
    x = views.reshape(-1, inputs)
    w1, b1, w2, b2 = unpack(theta, inputs, hidden)
    activation = np.tanh(x @ w1 + b1)
    logits = (activation @ w2 + b2).reshape(scenes,versions,4)
    logp = logits-logsumexp(logits,axis=2,keepdims=True)
    probability = np.exp(logp)
    view_weights = np.full(versions, .5/(versions-1)); view_weights[0] = .5
    scene_weights = class_weights[labels]
    js_scene_weights = scene_weights
    if js_class_multipliers is not None:
        multipliers = np.asarray(js_class_multipliers, dtype=float)
        if multipliers.shape != (4,) or not np.isfinite(multipliers).all() or (multipliers < 0).any():
            raise ValueError('JS class multipliers must be four finite nonnegative values')
        js_scene_weights = scene_weights * multipliers[labels]
    ce = -np.sum(scene_weights[:,None]*view_weights[None,:]*
                 logp[np.arange(scenes)[:,None],np.arange(versions)[None,:],labels[:,None]])/scenes
    onehot = np.eye(4)[labels][:,None,:]
    gradient = (probability-onehot)*scene_weights[:,None,None]*view_weights[None,:,None]/scenes
    # Jensen-Shannon divergence between each noisy prediction and its clean prediction.
    # Both sides receive gradients; clean CE anchors the shared prediction to truth.
    clean = probability[:,0:1,:]
    noisy = probability[:,1:,:]
    clean_log = logp[:,0:1,:]
    noisy_log = logp[:,1:,:]
    mixture_log = np.logaddexp(clean_log,noisy_log)-np.log(2.)
    js_pairs = .5*np.sum(clean*(clean_log-mixture_log)+noisy*(noisy_log-mixture_log),axis=2)
    js = np.sum(js_pairs*js_scene_weights[:,None])/(scenes*(versions-1))
    if coefficient:
        factor = coefficient*js_scene_weights[:,None,None]/(scenes*(versions-1))
        g_probability = np.zeros_like(probability)
        g_probability[:,0,:] = (.5*(clean_log-mixture_log)*factor).sum(axis=1)
        g_probability[:,1:,:] = .5*(noisy_log-mixture_log)*factor
        gradient += probability*(g_probability-(g_probability*probability).sum(axis=2,keepdims=True))
    delta = gradient.reshape(-1,4)
    gw2 = activation.T @ delta + l2*w2
    gb2 = delta.sum(axis=0)
    hidden_delta = (delta @ w2.T)*(1-activation*activation)
    gw1 = x.T @ hidden_delta + l2*w1
    gb1 = hidden_delta.sum(axis=0)
    regularization = .5*l2*(np.sum(w1*w1)+np.sum(w2*w2))
    loss = ce+coefficient*js+regularization
    grad = np.concatenate([gw1.ravel(),gb1,gw2.ravel(),gb2])
    return float(loss),grad


def predict(theta, values, hidden=HIDDEN):
    w1,b1,w2,b2 = unpack(theta, values.shape[1], hidden)
    logits = np.tanh(values @ w1+b1) @ w2+b2
    return np.exp(logits-logsumexp(logits,axis=1,keepdims=True))


def gradient_check():
    rng = np.random.default_rng(19)
    views = rng.normal(size=(5,3,3))
    labels = np.array([0,1,2,3,1])
    weights = np.array([1.,.8,1.3,.9])
    theta = initialize(3,4)
    maximum = 0.
    for coefficient, multipliers in ((0.,None),(1.,None),(1.,np.array([1.,3.,1.,1.]))):
        _,analytical = objective(theta,views,labels,weights,coefficient,hidden=4,
                                js_class_multipliers=multipliers)
        numerical = np.zeros_like(theta)
        for index in range(len(theta)):
            delta = np.zeros_like(theta);delta[index] = 1e-5
            numerical[index] = (objective(theta+delta,views,labels,weights,coefficient,hidden=4,
                                          js_class_multipliers=multipliers)[0]-
                                objective(theta-delta,views,labels,weights,coefficient,hidden=4,
                                          js_class_multipliers=multipliers)[0])/2e-5
        error = float(np.max(np.abs(numerical-analytical)))
        if error>1e-6:
            raise ValueError(f'gradient check failed for coefficient={coefficient}: {error}')
        maximum = max(maximum,error)
    original = objective(theta,views,labels,weights,1.,hidden=4)
    all_ones = objective(theta,views,labels,weights,1.,hidden=4,js_class_multipliers=np.ones(4))
    if original[0] != all_ones[0] or not np.array_equal(original[1],all_ones[1]):
        raise ValueError('all-ones JS multipliers changed the original objective')
    same = np.repeat(views[:,0:1,:],3,axis=1)
    a = objective(theta,same,labels,weights,0.,hidden=4)
    b = objective(theta,same,labels,weights,1.,hidden=4)
    if not np.allclose(a[0],b[0],atol=1e-12) or not np.allclose(a[1],b[1],atol=1e-12):
        raise ValueError('JS penalty is not zero for identical views')
    return maximum


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only',action='store_true')
    args = parser.parse_args()
    error = gradient_check()
    print(f'CE+JS finite-difference gradient check max error {error:.3g}',flush=True)
    if args.check_only:
        return
    OUT.mkdir(parents=True,exist_ok=True)
    scene = graph.DEFAULT_SCENE_DIR
    paths = dict(plans=scene/'scene_plan_train_val.csv',candidates=scene/'scene_candidates_train_val.csv',
                 scores=recovery.SELECTED/'relation_local_scores_train_val.csv',
                 models=recovery.SELECTED/'relation_models.joblib',
                 copies=recovery.RUNS/'relation/joint_train_relation_copies.csv',
                 noisy_features=recovery.TRACE/'relation_features_val.csv.gz',
                 noisy_scores=recovery.TRACE/'local_scores_val.csv.gz',
                 baseline=recovery.SELECTED/'clean_eval/graph_lira_predictions_val.csv')
    plans = pd.read_csv(paths['plans']);candidates = pd.read_csv(paths['candidates'])
    training.validate_scene_inputs(plans,candidates)
    scores = pd.read_csv(paths['scores']);pack = joblib.load(paths['models'])
    baseline = pd.read_csv(paths['baseline']).query("model == 'ct_conditioned'")
    rows,columns = graph.relation_feature_rows(plans,candidates,scores,['geometry_score','ct_score'])
    if columns!=pack['ct_conditioned_relation_features']:
        raise ValueError('feature order changed')
    clean = pd.DataFrame(rows)
    train = clean[clean.split.eq('train')].copy();val = clean[clean.split.eq('val')].copy()
    copies = pd.read_csv(paths['copies'],float_precision='round_trip')
    if set(train.scan_id.astype(int))!=training.EXPECTED_PATIENT_IDS['train'] or set(copies.scan_id.astype(int))!=set(train.scan_id.astype(int)):
        raise ValueError('unexpected train patients')
    if set(copies.split)!={'train'} or len(copies)!=len(train)*15:
        raise ValueError('train-only copy coverage changed')
    lookup = copies.set_index(['augmentation_index','scene_id'])
    arrays = [train[columns].to_numpy()]
    for rep in range(1,16):
        part = lookup.loc[rep].loc[train.scene_id]
        if not np.array_equal(part.relation_class.to_numpy(),train.relation_class.to_numpy()):
            raise ValueError('perturbation changed ground-truth class')
        arrays.append(part[columns].to_numpy())
    scaler = StandardScaler().fit(arrays[0])
    views = np.stack([scaler.transform(a) for a in arrays],axis=1)
    if not np.isfinite(views).all():
        raise ValueError('non-finite training features')
    labels = train.relation_class.map({v:i for i,v in enumerate(graph.RELATION_CLASSES)}).to_numpy()
    class_weights = len(labels)/(4*np.bincount(labels,minlength=4))
    initial = initialize(len(columns),HIDDEN)
    trained = {};optimization = {}
    for coefficient,name in ((0.,'MLP_CE'),(1.,'MLP_CE_JS')):
        iteration = [0]
        def callback(theta):
            iteration[0]+=1
            if iteration[0]%25==0:
                loss,_ = objective(theta,views,labels,class_weights,coefficient)
                print(f'{name} iteration {iteration[0]} train loss {loss:.6f}',flush=True)
        result = minimize(objective,initial.copy(),args=(views,labels,class_weights,coefficient),
                          method='L-BFGS-B',jac=True,callback=callback,
                          options=dict(maxiter=ITERATIONS,ftol=1e-9,gtol=1e-5,maxls=30))
        if not np.isfinite(result.fun) or not np.isfinite(result.x).all():
            raise ValueError('non-finite optimization result')
        trained[name] = result.x
        optimization[name] = dict(iterations=int(result.nit),success=bool(result.success),
                                  message=str(result.message),train_loss=float(result.fun),
                                  gradient_max=float(np.max(np.abs(result.jac))))
        print(name,optimization[name],flush=True)
    train_diagnostics = {}
    for name,theta in trained.items():
        ce_l2 = objective(theta,views,labels,class_weights,0.)[0]
        ce_js_l2 = objective(theta,views,labels,class_weights,1.)[0]
        train_diagnostics[name] = dict(ce_plus_l2=ce_l2,mean_class_weighted_js=ce_js_l2-ce_l2)
    joblib.dump(dict(parameters=trained,scaler=scaler,features=columns,hidden=HIDDEN),OUT/'relation_models.joblib')
    noisy = pd.read_csv(paths['noisy_features']);noisy = noisy[noisy['mode'].eq('joint')]
    noisy_scores = pd.read_csv(paths['noisy_scores']);noisy_scores = noisy_scores[noisy_scores['mode'].eq('joint')]
    if len(noisy)!=5520 or set(noisy.scan_id.astype(int))!=graph.EXPECTED_VALIDATION_PATIENTS:
        raise ValueError('validation repeat cohort changed')
    xv = val[columns].to_numpy();xn = noisy[columns].to_numpy()
    probabilities = {'K10_15':(pack['relation_heads']['ct_conditioned'].predict_proba(xv),
                               pack['relation_heads']['ct_conditioned'].predict_proba(xn))}
    for name,theta in trained.items():
        probabilities[name] = (predict(theta,scaler.transform(xv)),predict(theta,scaler.transform(xn)))
    metrics = {};frames = [];confidence_rows = []
    for name,(base_prob,noisy_prob) in probabilities.items():
        validate_probabilities(base_prob);validate_probabilities(noisy_prob)
        frame,_ = recovery.evaluate(name,plans[plans.split.eq('val')],candidates,scores[scores.split.eq('val')],
            noisy_scores,dict(zip(val.scene_id,base_prob)),dict(zip(zip(noisy.repetition,noisy.scene_id),noisy_prob)))
        if name=='K10_15':
            observed=frame.set_index('scene_id');expected=baseline.set_index('scene_id').loc[observed.index]
            for actual,saved in [('accepted','accepted'),('pre_exact','pre_consistency_exact'),
                                  ('pre_false','pre_consistency_false'),('consistency','combined_consistency')]:
                if not np.allclose(observed[actual],expected[saved],atol=1e-12,rtol=0):
                    raise ValueError('baseline decision replay differs')
        probability_frame = pd.DataFrame(base_prob,columns=[f'p_{v.lower()}' for v in graph.RELATION_CLASSES])
        probability_frame['scene_id']=val.scene_id.to_numpy()
        frame=frame.merge(probability_frame,on='scene_id',validate='one_to_one')
        frames.append(frame);metrics[name]=recovery.summary(frame)
        diagnostic = confidence_diagnostics(name,val,noisy,base_prob,noisy_prob,baseline)
        base_lookup = dict(zip(val.scene_id,base_prob))
        q = np.stack([base_lookup[sid] for sid in noisy.scene_id])
        mixture = .5*(q+noisy_prob)
        diagnostic['probability_js_from_clean'] = .5*np.sum(
            q*(np.log(np.maximum(q,1e-300))-np.log(np.maximum(mixture,1e-300))) +
            noisy_prob*(np.log(np.maximum(noisy_prob,1e-300))-np.log(np.maximum(mixture,1e-300))),axis=1)
        confidence_rows.append(diagnostic)
        print(name,metrics[name],flush=True)
    frame=pd.concat(frames,ignore_index=True);frame.to_csv(OUT/'predictions_val.csv',index=False)
    confidence=pd.concat(confidence_rows,ignore_index=True)
    confidence.to_csv(OUT/'confidence_repeats_val.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    for blocked,name in ((False,'confidence_all_val'),(True,'confidence_blocked103_val')):
        selected=confidence[confidence.baseline_blocked_exact] if blocked else confidence
        selected.groupby(['variant','scene_family']).agg(repeats=('scene_id','size'),
            raw_correct_fraction=('raw_correct','mean'),tau_correct_fraction=('tau_correct','mean'),
            same_correct_raw_below_tau_fraction=('confidence_below_tau_same_correct_raw','mean'),
            true_probability_mean=('true_probability','mean'),
            probability_js_mean=('probability_js_from_clean','mean')).to_csv(OUT/f'{name}.csv')
    for keys,name in [(['variant','scan_id'],'per_patient'),(['variant','scene_family','pair_count','junction_count'],'count_strata')]:
        summaries=[]
        for key,group in frame.groupby(keys):
            summaries.append(dict(zip(keys,key))|dict(scenes=len(group))|recovery.summary(group))
        pd.DataFrame(summaries).to_csv(OUT/f'{name}_val.csv',index=False)
    base_frame = frame[frame.variant.eq('K10_15')].set_index('scene_id')
    js_frame = frame[frame.variant.eq('MLP_CE_JS')].set_index('scene_id').loc[base_frame.index]
    old_exact = base_frame.accepted.eq(1) & base_frame.exact.eq(1)
    new_exact = js_frame.accepted.eq(1) & js_frame.exact.eq(1)
    transitions = dict(new_exact_scenes=int((new_exact & ~old_exact).sum()),
                       lost_old_exact_scenes=int((old_exact & ~new_exact).sum()))
    result=dict(status='bounded_train_validation_ablation_not_test_frozen',held_out_test_accessed=False,
        baseline='K10/15',architecture='84-64tanh-4 MLP',initialization_seed=0,
        scaler='clean train scenes only',train_patients=sorted(train.scan_id.astype(int).unique().tolist()),
        train_scenes=len(train),views_per_scene=16,train_objective='class-balanced CE clean0.5/noisytotal0.5 + lambda class-balanced mean JS(clean,noisy)',
        consistency_coefficients=[0,1],l2=L2,max_iterations=ITERATIONS,optimizer='L-BFGS-B',
        optimization=optimization,train_diagnostics=train_diagnostics,gradient_check_max_error=error,
        budget_note='200 iterations extended to1000 for both based only on unfinished train optimization before MLP validation metrics were read; final bounded models, not claimed converged optima',
        no_validation_fit_or_checkpoint_selection=True,tau=.85,consistency=.60,validation_repeats=15,
        metrics=metrics,transitions_vs_HGB=transitions,primary_model='K10_15',
        exploratory_junction_candidate='MLP_CE_JS',
        decision='retain HGB control; CE+JS is exploratory and requires review of JUNCTION/mixed and pre-gate tradeoff',
        implementation_sha256=graph.sha256(Path(__file__)),
        source_sha256={k:graph.sha256(v) for k,v in paths.items()})
    (OUT/'metrics.json').write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':
    with threadpool_limits(limits=1):
        main()
