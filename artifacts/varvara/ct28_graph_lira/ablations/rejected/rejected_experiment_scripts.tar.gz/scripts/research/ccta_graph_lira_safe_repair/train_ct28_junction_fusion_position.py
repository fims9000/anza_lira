#!/usr/bin/env python3
"""Train-only position augmentation of JUNCTION fusion identity evidence."""
from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import run_ct28_graph_lira as graph
import train_ct28_relation_head as training
from diagnose_ct28_junction_inputs import paired_noise


ROOT = graph.DEFAULT_SCENE_DIR
OUT = ROOT / "ablations/junction_fusion_position_robustness"


def rank_rows(features: pd.DataFrame, candidates: pd.DataFrame,
              models: dict[str, object], repetition: int) -> list[dict[str, object]]:
    columns = list(next(iter(models.values())).feature_names_in_)
    merged = candidates[["scene_id", "candidate_id", "y"]].merge(
        features[["scene_id", "candidate_id", *columns]],
        on=["scene_id", "candidate_id"], validate="one_to_one"
    )
    rows = []
    for name, model in models.items():
        columns = list(model.feature_names_in_)
        scored = merged[["scene_id", "candidate_id", "y"]].copy()
        scored["score"] = model.predict_proba(merged[columns])[:, 1]
        for scene_id, part in scored.groupby("scene_id"):
            if not part.y.eq(1).any():
                continue
            rows.append({"scene_id": scene_id, "repetition": repetition,
                         "model": name, "competitive": int(part.y.eq(0).any()),
                         "true_top1": int(part.loc[part.score.idxmax(), "y"] == 1),
                         "margin": float(part.loc[part.y.eq(1), "score"].max() -
                                         part.loc[part.y.eq(0), "score"].max())
                         if part.y.eq(0).any() else np.nan})
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scene-dir", type=Path, default=ROOT)
    parser.add_argument("--evidence-dir", type=Path,
                        default=ROOT / "ablations/junction_position_robustness")
    parser.add_argument("--archive-dir", type=Path, default=graph.DEFAULT_ARCHIVE_DIR)
    parser.add_argument("--out-dir", type=Path, default=OUT)
    args = parser.parse_args()
    plans = pd.read_csv(args.scene_dir / "scene_plan_train_val.csv")
    candidates = pd.read_csv(args.scene_dir / "scene_candidates_train_val.csv")
    training.validate_scene_inputs(plans, candidates)
    endpoints = pd.read_csv(args.scene_dir / "scene_endpoints_train_val.csv")
    clean = pd.read_csv(args.scene_dir / "scene_candidate_features_train_val.csv",
                        low_memory=False)
    base_scores = pd.read_csv(args.evidence_dir / "relation_local_scores_train_val.csv")
    pack = joblib.load(args.evidence_dir / "relation_models.joblib")
    protocol = json.loads((args.evidence_dir / "relation_model_protocol.json").read_text())
    for key, filename in (("scene_plan", "scene_plan_train_val.csv"),
                          ("scene_candidates", "scene_candidates_train_val.csv"),
                          ("scene_candidate_features", "scene_candidate_features_train_val.csv")):
        if graph.sha256(args.scene_dir / filename) != protocol["source_sha256"][key]:
            raise ValueError(f"frozen input changed: {filename}")
    if pack["local_model_family"] != "hgb":
        raise ValueError("position-robust HGB pack required")
    train_scores = base_scores[base_scores.split.eq("train")]
    if not train_scores.groupby("scan_id").local_oof_fold.nunique().eq(1).all():
        raise ValueError("patient spans multiple OOF folds")
    folds = train_scores.groupby("scan_id").local_oof_fold.first().astype(int).to_dict()
    if (set(folds) != training.EXPECTED_PATIENT_IDS["train"]
            or set(folds.values()) != set(range(5))):
        raise ValueError("patient folds changed")
    if "patient_oof_folds" in protocol and folds != {
        int(patient): int(fold) for patient, fold in protocol["patient_oof_folds"].items()
    }:
        raise ValueError("saved OOF folds disagree with score table")
    junction = candidates[candidates.candidate_type.eq("JUNCTION")].merge(
        plans[["scene_id", "scan_id", "split"]], on="scene_id", validate="many_to_one"
    )
    clean_junction = clean[clean.candidate_type.eq("JUNCTION")].merge(
        junction[["scene_id", "candidate_id", "scan_id", "split", "y"]],
        on=["scene_id", "candidate_id"], validate="one_to_one",
        suffixes=("", "_plan"),
    )
    for field in ("scan_id", "split", "y"):
        if not clean_junction[field].eq(clean_junction[f"{field}_plan"]).all():
            raise ValueError(f"frozen candidate {field} mismatch")
    if set(clean_junction.scan_id.astype(int)) & {954, 958, 972, 973, 980, 984}:
        raise ValueError("held-out test patient entered fusion training")
    train = clean_junction[clean_junction.split.eq("train")].copy()
    validation = clean_junction[clean_junction.split.eq("val")].copy()
    baseline_model = pack["local_models"]["JUNCTION"]["geometry_plus_ct"]
    feature_precision = 6 if "precision" in baseline_model.named_steps else None
    columns = list(baseline_model.feature_names_in_)
    if len(columns) != 161:
        raise ValueError("unexpected fusion feature count")
    expected_geometry = pd.read_csv(graph.ct_features.EXPECTED_GEOMETRY).set_index("scan_id")
    expected_alignment = pd.read_csv(graph.ct_features.EXPECTED_ALIGNMENT).set_index("scan_id")
    arm_names = graph.ct_features.arm_feature_names(graph.ct_features.RADII_MM)
    augmented_parts = []
    extraction_audit = []
    for patient in sorted(folds):
        patient_candidates = junction[junction.scan_id.eq(patient)]
        patient_endpoints = endpoints[endpoints.scene_id.isin(patient_candidates.scene_id)]
        grouped_candidates = dict(tuple(patient_candidates.groupby("scene_id", sort=False)))
        ct, inverse_affine = graph.load_verified_ct(
            patient, args.archive_dir, expected_geometry, expected_alignment
        )
        patient_rows = []
        for repetition in range(5):
            for scene_id, scene_endpoints in patient_endpoints.groupby("scene_id", sort=False):
                perturbed = paired_noise(scene_endpoints, repetition, "position_only")
                lookup = perturbed.set_index("endpoint_id")
                for _, candidate in grouped_candidates[scene_id].iterrows():
                    values = graph.perturbed_candidate_features(
                        candidate, lookup, ct, inverse_affine, arm_names
                    )
                    patient_rows.append({"scene_id": scene_id,
                                         "candidate_id": candidate.candidate_id,
                                         "repetition": repetition, **values})
        part = pd.DataFrame(patient_rows).merge(
            patient_candidates[["scene_id", "candidate_id", "y", "scan_id"]],
            on=["scene_id", "candidate_id"], validate="many_to_one"
        )
        if len(part) != 5 * len(patient_candidates):
            raise ValueError(f"incomplete augmentation for patient {patient}")
        part["sample_weight"] = 0.1
        augmented_parts.append(part[["scene_id", "candidate_id", "scan_id", "y",
                                     "sample_weight", *columns]])
        extraction_audit.append({"scan_id": patient,
                                 "clean_candidates": len(patient_candidates),
                                 "perturbed_candidates": len(part),
                                 "missing_ct_rows": int(part[
                                     [c for c in columns if c not in training.JUNCTION_GEOMETRY_FEATURES]
                                 ].isna().any(axis=1).sum())})
        del ct
        print(f"fusion train CT: patient {patient}, {len(part)} rows", flush=True)
    train_clean = train[["scene_id", "candidate_id", "scan_id", "y", *columns]].copy()
    train_clean["sample_weight"] = 0.5
    fit_data = pd.concat([train_clean, *augmented_parts], ignore_index=True)
    if len(fit_data) != 6 * len(train):
        raise ValueError("incorrect augmented train size")
    if fit_data.groupby(["scene_id", "candidate_id"]).sample_weight.sum().sub(1).abs().max() > 1e-12:
        raise ValueError("candidate augmentation weights do not sum to one")
    scores = base_scores.copy().set_index(["scene_id", "candidate_id"])
    for fold in sorted(set(folds.values())):
        held_patients = {patient for patient, assigned in folds.items() if assigned == fold}
        fit = fit_data[~fit_data.scan_id.isin(held_patients)]
        held = train[train.scan_id.isin(held_patients)]
        model = training.local_model("hgb", feature_precision)
        model.fit(fit[columns], fit.y, hgb__sample_weight=fit.sample_weight)
        scores.loc[pd.MultiIndex.from_frame(held[["scene_id", "candidate_id"]]),
                   "geometry_plus_ct_score"] = model.predict_proba(held[columns])[:, 1]
        print(f"fusion patient-OOF fold {fold} complete", flush=True)
    final = training.local_model("hgb", feature_precision)
    final.fit(fit_data[columns], fit_data.y, hgb__sample_weight=fit_data.sample_weight)
    scores.loc[pd.MultiIndex.from_frame(validation[["scene_id", "candidate_id"]]),
               "geometry_plus_ct_score"] = final.predict_proba(validation[columns])[:, 1]
    scores = scores.reset_index()
    if len(scores) != len(base_scores) or scores[["geometry_score", "ct_score", "geometry_plus_ct_score"]].isna().any().any():
        raise ValueError("incomplete local score table")
    if not np.array_equal(scores["geometry_score"], base_scores["geometry_score"]) or not np.array_equal(scores["ct_score"], base_scores["ct_score"]):
        raise ValueError("relation evidence streams changed")
    pack["local_models"]["JUNCTION"]["geometry_plus_ct"] = final
    args.out_dir.mkdir(parents=True, exist_ok=True)
    scores.to_csv(args.out_dir / "relation_local_scores_train_val.csv", index=False)
    joblib.dump(pack, args.out_dir / "relation_models.joblib")
    shutil.copy2(args.evidence_dir / "relation_predictions_val.csv",
                 args.out_dir / "relation_predictions_val.csv")
    pd.DataFrame(extraction_audit).to_csv(args.out_dir / "train_extraction_audit.csv", index=False)
    ranking_rows = rank_rows(validation, junction[junction.split.eq("val")],
                             {"baseline": baseline_model, "position_robust": final}, -1)
    validation_scenes = set(validation.scene_id)
    validation_candidates = junction[junction.scene_id.isin(validation_scenes)]
    validation_endpoints = endpoints[endpoints.scene_id.isin(validation_scenes)]
    for patient in sorted(training.EXPECTED_PATIENT_IDS["val"]):
        patient_candidates = validation_candidates[validation_candidates.scan_id.eq(patient)]
        patient_endpoints = validation_endpoints[
            validation_endpoints.scene_id.isin(patient_candidates.scene_id)
        ]
        grouped_candidates = dict(tuple(patient_candidates.groupby("scene_id", sort=False)))
        ct, inverse_affine = graph.load_verified_ct(
            patient, args.archive_dir, expected_geometry, expected_alignment
        )
        for repetition in range(15):
            rows = []
            for scene_id, scene_endpoints in patient_endpoints.groupby("scene_id", sort=False):
                lookup = paired_noise(scene_endpoints, repetition, "position_only").set_index("endpoint_id")
                for _, candidate in grouped_candidates[scene_id].iterrows():
                    rows.append(graph.perturbed_candidate_features(
                        candidate, lookup, ct, inverse_affine, arm_names
                    ))
            ranking_rows.extend(rank_rows(pd.DataFrame(rows), patient_candidates,
                                          {"baseline": baseline_model,
                                           "position_robust": final}, repetition))
        del ct
        print(f"fusion validation position noise: patient {patient} complete", flush=True)
    ranking = pd.DataFrame(ranking_rows)
    ranking.to_csv(args.out_dir / "junction_fusion_ranking_val.csv.gz", index=False,
                   compression={"method": "gzip", "mtime": 0})
    summary = ranking.assign(mode=np.where(ranking.repetition.eq(-1), "clean", "position_only"))
    summary = summary.groupby(["model", "mode", "competitive"]).agg(
        scene_repeats=("true_top1", "size"), correct_top1=("true_top1", "sum"),
        top1_rate=("true_top1", "mean"), median_margin=("margin", "median")
    ).reset_index()
    summary.to_csv(args.out_dir / "junction_fusion_ranking_summary_val.csv", index=False)
    result_protocol = {
        "status": "train_val_diagnostic", "held_out_test_accessed": False,
        "local_change": "JUNCTION geometry+CT HGB only; relation heads and all other local models unchanged",
        "train_augmentation": {"clean_weight": 0.5, "repetitions": 5,
                               "weight_per_repeat": 0.1, "position_sigma_mm_per_axis": 0.8,
                               "tangent_noise_deg": 0, "seed": 20260920},
        "validation_position_repetitions": 15,
        "patient_oof_folds": {str(patient): fold for patient, fold in folds.items()},
        "feature_precision": feature_precision,
        "source_sha256": {"scene_plan": graph.sha256(args.scene_dir / "scene_plan_train_val.csv"),
                          "scene_candidates": graph.sha256(args.scene_dir / "scene_candidates_train_val.csv"),
                          "scene_candidate_features": graph.sha256(args.scene_dir / "scene_candidate_features_train_val.csv")},
        "output_sha256": {name: graph.sha256(args.out_dir / name) for name in (
            "relation_local_scores_train_val.csv", "relation_models.joblib",
            "relation_predictions_val.csv", "junction_fusion_ranking_val.csv.gz",
            "junction_fusion_ranking_summary_val.csv")},
    }
    (args.out_dir / "relation_model_protocol.json").write_text(
        json.dumps(result_protocol, indent=2) + "\n"
    )
    print(summary.to_string(index=False), flush=True)


if __name__ == "__main__":
    main()
