#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import extract_ct28_scene_candidate_features as ct_features
import run_ct28_graph_lira as graph_lira
import train_ct28_relation_head as relation_training
from ct28_perturbations import perturb_scene_endpoints


REPO_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_ROOT = REPO_ROOT / "artifacts/varvara/ct28_graph_lira"
DEFAULT_SCENE_DIR = DEFAULT_ROOT / "ablations/stress30_jitter1"
DEFAULT_ARCHIVE_DIR = REPO_ROOT / "varvara/anza_lira_local_data/imagecas_801_1000"
DEFAULT_OUT_DIR = DEFAULT_SCENE_DIR / "local_hgb_robustness"
HELD_OUT_PATIENTS = {954, 958, 972, 973, 980, 984}
SCORE_COLUMNS = tuple(
    f"{stream}_score" for stream in relation_training.EVIDENCE_STREAMS
)


class RobustLocalError(RuntimeError):
    pass


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Train patient-OOF HGB local models on a Stress30 base scene plus "
            "five train-only perturbations, then compare a base-only and a "
            "weighted-augmentation CT-conditioned relation head."
        )
    )
    parser.add_argument("--scene-dir", type=Path, default=DEFAULT_SCENE_DIR)
    parser.add_argument("--archive-dir", type=Path, default=DEFAULT_ARCHIVE_DIR)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT_DIR)
    parser.add_argument("--train-perturbations", type=int, default=5)
    parser.add_argument("--position-noise-mm", type=float, default=0.8)
    parser.add_argument("--tangent-noise-deg", type=float, default=20.0)
    parser.add_argument("--clean-weight", type=float, default=0.5)
    parser.add_argument("--seed", type=int, default=20260920)
    parser.add_argument("--tau", type=float, default=0.85)
    return parser.parse_args()


def validate_args(args: argparse.Namespace) -> None:
    if args.train_perturbations != 5:
        raise RobustLocalError("frozen ablation uses five train perturbations")
    if (args.position_noise_mm, args.tangent_noise_deg) != (0.8, 20.0):
        raise RobustLocalError("frozen ablation uses 0.8 mm and 20 degree noise")
    if args.clean_weight != 0.5:
        raise RobustLocalError("frozen ablation uses clean weight 0.5")
    if args.tau != 0.85:
        raise RobustLocalError("frozen relation threshold must remain 0.85")


def load_inputs(args: argparse.Namespace) -> dict[str, pd.DataFrame]:
    paths = {
        "plans": args.scene_dir / "scene_plan_train_val.csv",
        "endpoints": args.scene_dir / "scene_endpoints_train_val.csv",
        "candidates": args.scene_dir / "scene_candidates_train_val.csv",
        "features": args.scene_dir / "scene_candidate_features_train_val.csv",
    }
    missing = [str(path) for path in paths.values() if not path.exists()]
    if missing:
        raise RobustLocalError(f"missing frozen inputs: {missing}")
    frames = {
        "plans": pd.read_csv(paths["plans"]),
        "endpoints": pd.read_csv(paths["endpoints"]),
        "candidates": pd.read_csv(paths["candidates"]),
        "features": pd.read_csv(
            paths["features"],
            dtype={"ct_sampling_error": "string"},
            low_memory=False,
        ),
    }
    relation_training.validate_scene_inputs(frames["plans"], frames["candidates"])
    relation_training.validate_scene_inputs(frames["plans"], frames["features"])
    patients = set(frames["plans"]["scan_id"].astype(int))
    if patients & HELD_OUT_PATIENTS:
        raise RobustLocalError("held-out test entered the experiment")
    candidate_keys = set(
        map(tuple, frames["candidates"][["scene_id", "candidate_id"]].to_numpy())
    )
    feature_keys = set(
        map(tuple, frames["features"][["scene_id", "candidate_id"]].to_numpy())
    )
    if candidate_keys != feature_keys:
        raise RobustLocalError("candidate feature table does not match scene plan")
    frames["paths"] = paths  # type: ignore[assignment]
    return frames


def variant_weights(args: argparse.Namespace) -> tuple[float, float]:
    return args.clean_weight, (1.0 - args.clean_weight) / args.train_perturbations


def generate_perturbed_train_features(
    args: argparse.Namespace,
    frames: dict[str, pd.DataFrame],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    plans = frames["plans"]
    endpoints = frames["endpoints"]
    candidates = frames["candidates"]
    base_features = frames["features"]
    train_plans = plans[plans["split"].eq("train")]
    train_scene_ids = set(train_plans["scene_id"])
    train_endpoints = endpoints[endpoints["scene_id"].isin(train_scene_ids)]
    train_candidates = candidates[candidates["scene_id"].isin(train_scene_ids)]
    metadata_columns = [
        column
        for column in base_features.columns
        if column
        not in set(relation_training.PAIR_GEOMETRY_FEATURES)
        | set(relation_training.JUNCTION_GEOMETRY_FEATURES)
        and not column.startswith("pair_ct")
        and not column.startswith("junction_")
    ]
    metadata = base_features[metadata_columns].set_index(
        ["scene_id", "candidate_id", "candidate_type"]
    )
    expected_geometry = pd.read_csv(ct_features.EXPECTED_GEOMETRY).set_index("scan_id")
    expected_alignment = pd.read_csv(ct_features.EXPECTED_ALIGNMENT).set_index("scan_id")
    junction_arm_names = ct_features.arm_feature_names(ct_features.RADII_MM)
    rows: list[dict[str, object]] = []
    audit_rows: list[dict[str, object]] = []
    _, perturbed_weight = variant_weights(args)
    for scan_id in sorted(relation_training.EXPECTED_PATIENT_IDS["train"]):
        patient_plans = train_plans[train_plans["scan_id"].astype(int).eq(scan_id)]
        patient_scene_ids = set(patient_plans["scene_id"])
        patient_endpoints = train_endpoints[
            train_endpoints["scene_id"].isin(patient_scene_ids)
        ]
        patient_candidates = train_candidates[
            train_candidates["scene_id"].isin(patient_scene_ids)
        ]
        ct, inverse_affine = graph_lira.load_verified_ct(
            scan_id, args.archive_dir, expected_geometry, expected_alignment
        )
        for repetition in range(args.train_perturbations):
            missing_ct = 0
            for scene_id, endpoint_rows in patient_endpoints.groupby(
                "scene_id", sort=False
            ):
                perturbed = perturb_scene_endpoints(
                    endpoint_rows,
                    seed=args.seed,
                    repetition=repetition,
                    position_noise_mm=args.position_noise_mm,
                    tangent_noise_deg=args.tangent_noise_deg,
                )
                endpoint_lookup = perturbed.set_index("endpoint_id")
                scene_candidates = patient_candidates[
                    patient_candidates["scene_id"].eq(scene_id)
                ]
                for _, candidate in scene_candidates.iterrows():
                    row = graph_lira.perturbed_candidate_features(
                        candidate,
                        endpoint_lookup,
                        ct,
                        inverse_affine,
                        junction_arm_names,
                    )
                    key = (
                        str(row["scene_id"]),
                        str(row["candidate_id"]),
                        str(row["candidate_type"]),
                    )
                    row.update(metadata.loc[key].to_dict())
                    row["augmentation_index"] = repetition + 1
                    row["sample_weight"] = perturbed_weight
                    feature_columns = (
                        [column for column in row if column.startswith("pair_ct")]
                        if row["candidate_type"] == "PAIR"
                        else [
                            column
                            for column in row
                            if column.startswith("junction_")
                            and column
                            not in relation_training.JUNCTION_GEOMETRY_FEATURES
                        ]
                    )
                    missing_ct += int(any(pd.isna(row[column]) for column in feature_columns))
                    rows.append(row)
            audit_rows.append(
                {
                    "scan_id": scan_id,
                    "augmentation_index": repetition + 1,
                    "scenes": len(patient_plans),
                    "candidates": len(patient_candidates),
                    "missing_ct_candidates": missing_ct,
                }
            )
        del ct
        print(
            f"local augmentation: patient {scan_id} complete "
            f"({len(patient_candidates)} candidates x {args.train_perturbations})",
            flush=True,
        )
    return pd.DataFrame(rows), pd.DataFrame(audit_rows)


def fit_robust_local_models(
    args: argparse.Namespace,
    plans: pd.DataFrame,
    base_features: pd.DataFrame,
    perturbed_features: pd.DataFrame,
) -> tuple[pd.DataFrame, dict[str, object], dict[str, object], dict[int, dict[str, dict[str, object]]]]:
    base = base_features.copy()
    base["scan_id"] = base["scan_id"].astype(int)
    base["y"] = base["y"].astype(int)
    clean_weight, _ = variant_weights(args)
    base_train = base[base["split"].eq("train")].copy()
    base_validation = base[base["split"].eq("val")].copy()
    base_train["augmentation_index"] = 0
    base_train["sample_weight"] = clean_weight
    augmented = pd.concat([base_train, perturbed_features], ignore_index=True, sort=False)
    folds = relation_training.patient_folds(base_train, 5)
    base["local_oof_fold"] = base["scan_id"].map(folds).fillna(-1).astype(int)
    for column in SCORE_COLUMNS:
        base[column] = np.nan
    feature_columns = relation_training.feature_sets(base)
    final_models: dict[str, dict[str, object]] = {}
    fold_models: dict[int, dict[str, dict[str, object]]] = {
        fold: {} for fold in sorted(set(folds.values()))
    }
    diagnostics: dict[str, object] = {}
    for candidate_type in ("PAIR", "JUNCTION"):
        final_models[candidate_type] = {}
        diagnostics[candidate_type] = {}
        for fold in fold_models:
            fold_models[fold][candidate_type] = {}
        type_augmented = augmented[augmented["candidate_type"].eq(candidate_type)]
        type_base_train = base_train[base_train["candidate_type"].eq(candidate_type)]
        type_validation = base_validation[
            base_validation["candidate_type"].eq(candidate_type)
        ]
        for stream in relation_training.EVIDENCE_STREAMS:
            columns = list(feature_columns[candidate_type][stream])
            score_column = f"{stream}_score"
            for fold in fold_models:
                held_patients = {
                    patient for patient, assigned in folds.items() if assigned == fold
                }
                fit = type_augmented[
                    ~type_augmented["scan_id"].astype(int).isin(held_patients)
                ]
                held = type_base_train[
                    type_base_train["scan_id"].astype(int).isin(held_patients)
                ]
                model = relation_training.local_model("hgb")
                model.fit(
                    fit[columns],
                    fit["y"].astype(int),
                    hgb__sample_weight=fit["sample_weight"].to_numpy(dtype=float),
                )
                fold_models[fold][candidate_type][stream] = model
                base.loc[held.index, score_column] = model.predict_proba(
                    held[columns]
                )[:, 1]
            final_model = relation_training.local_model("hgb")
            final_model.fit(
                type_augmented[columns],
                type_augmented["y"].astype(int),
                hgb__sample_weight=type_augmented["sample_weight"].to_numpy(
                    dtype=float
                ),
            )
            final_models[candidate_type][stream] = final_model
            base.loc[type_validation.index, score_column] = final_model.predict_proba(
                type_validation[columns]
            )[:, 1]
            diagnostics[candidate_type][stream] = {
                "feature_count": len(columns),
                "base_train_candidates": len(type_base_train),
                "augmented_fit_rows": len(type_augmented),
            }
    if not np.isfinite(base[list(SCORE_COLUMNS)].to_numpy(dtype=float)).all():
        raise RobustLocalError("robust local scores are incomplete")
    scores = base[
        [
            "scene_id",
            "candidate_id",
            "candidate_type",
            "scan_id",
            "split",
            "local_oof_fold",
            "y",
            *SCORE_COLUMNS,
        ]
    ].copy()
    protocol = {
        "training": "patient-level OOF on Stress30 base plus five train perturbations",
        "fold_by_patient": {str(key): value for key, value in sorted(folds.items())},
        "base_weight": clean_weight,
        "perturbation_weight_each": variant_weights(args)[1],
        "weight_sum_per_source_candidate": 1.0,
        "models": diagnostics,
    }
    return scores, protocol, final_models, fold_models


def score_perturbed_oof(
    features: pd.DataFrame,
    fold_models: dict[int, dict[str, dict[str, object]]],
    folds: dict[int, int],
) -> pd.DataFrame:
    parts: list[pd.DataFrame] = []
    for scan_id, patient_rows in features.groupby("scan_id", sort=True):
        scores = graph_lira.score_feature_frame(
            patient_rows, fold_models[folds[int(scan_id)]]
        )
        scores["scan_id"] = int(scan_id)
        scores["augmentation_index"] = patient_rows["augmentation_index"].to_numpy()
        parts.append(scores)
    return pd.concat(parts, ignore_index=True)


def relation_rows_for_variants(
    args: argparse.Namespace,
    plans: pd.DataFrame,
    candidates: pd.DataFrame,
    base_scores: pd.DataFrame,
    perturbed_scores: pd.DataFrame,
) -> tuple[list[dict[str, object]], list[str], list[dict[str, object]]]:
    all_base_rows, columns = graph_lira.relation_feature_rows(
        plans, candidates, base_scores, ("geometry_score", "ct_score")
    )
    clean_weight, perturbed_weight = variant_weights(args)
    train_base_rows = [row for row in all_base_rows if row["split"] == "train"]
    validation_rows = [row for row in all_base_rows if row["split"] == "val"]
    for row in train_base_rows:
        row["augmentation_index"] = 0
        row["sample_weight"] = clean_weight
    augmented = list(train_base_rows)
    train_plans = plans[plans["split"].eq("train")]
    train_scene_ids = set(train_plans["scene_id"])
    train_candidates = candidates[candidates["scene_id"].isin(train_scene_ids)]
    for repetition in range(1, args.train_perturbations + 1):
        scores = perturbed_scores[
            perturbed_scores["augmentation_index"].eq(repetition)
        ]
        rows, variant_columns = graph_lira.relation_feature_rows(
            train_plans,
            train_candidates,
            scores,
            ("geometry_score", "ct_score"),
        )
        if variant_columns != columns:
            raise RobustLocalError("relation feature layout changed")
        for row in rows:
            row["augmentation_index"] = repetition
            row["sample_weight"] = perturbed_weight
        augmented.extend(rows)
    weights = pd.DataFrame(augmented).groupby("scene_id")["sample_weight"].sum()
    if not np.allclose(weights.to_numpy(dtype=float), 1.0, atol=1e-12):
        raise RobustLocalError("relation augmentation weights do not sum to one")
    return augmented, columns, validation_rows


def fit_relation_heads(
    plans: pd.DataFrame,
    candidates: pd.DataFrame,
    scores: pd.DataFrame,
    tau: float,
) -> tuple[dict[str, object], dict[str, object], list[dict[str, object]], dict[str, list[str]]]:
    def csv_records(frame: pd.DataFrame) -> list[dict[str, str]]:
        return [
            {
                column: "" if pd.isna(value) else str(value)
                for column, value in row.items()
            }
            for row in frame.to_dict(orient="records")
        ]

    score_rows = csv_records(scores)
    plan_rows = csv_records(plans)
    candidate_rows = csv_records(candidates)
    configurations = {
        "geometry_only": ["geometry_score"],
        "geometry_plus_ct": ["geometry_plus_ct_score"],
        "ct_conditioned": ["geometry_score", "ct_score"],
    }
    heads: dict[str, object] = {}
    metrics: dict[str, object] = {}
    predictions: list[dict[str, object]] = []
    feature_names: dict[str, list[str]] = {}
    for name, streams in configurations.items():
        rows, columns = relation_training.build_relation_feature_rows(
            plan_rows, candidate_rows, score_rows, streams
        )
        result, predicted, head = relation_training.fit_relation_head(
            rows, columns, tau, name
        )
        heads[name] = head
        metrics[name] = result
        predictions.extend(predicted)
        feature_names[name] = columns
    return heads, metrics, predictions, feature_names


def save_pack(
    out_dir: Path,
    scores: pd.DataFrame,
    local_models: dict[str, object],
    relation_heads: dict[str, object],
    metrics: dict[str, object],
    predictions: list[dict[str, object]],
    feature_names: dict[str, list[str]],
    local_protocol: dict[str, object],
    relation_training_description: dict[str, object],
    source_sha256: dict[str, str],
) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    scores.to_csv(out_dir / "relation_local_scores_train_val.csv", index=False)
    pd.DataFrame(predictions).to_csv(
        out_dir / "relation_predictions_val.csv", index=False
    )
    (out_dir / "relation_metrics_val.json").write_text(
        json.dumps(
            {
                "status": "development_train_val_only",
                "held_out_test_accessed": False,
                "tau": 0.85,
                "models": metrics,
            },
            indent=2,
        )
        + "\n"
    )
    joblib.dump(
        {
            "local_models": local_models,
            "relation_heads": relation_heads,
            "local_model_family": "hgb",
            "relation_classes": relation_training.RELATION_CLASSES,
            "geometry_relation_features": feature_names["geometry_only"],
            "geometry_plus_ct_relation_features": feature_names["geometry_plus_ct"],
            "ct_conditioned_relation_features": feature_names["ct_conditioned"],
        },
        out_dir / "relation_models.joblib",
    )
    (out_dir / "relation_model_protocol.json").write_text(
        json.dumps(
            {
                "protocol_version": "ct28_stress30_robust_local_hgb_v1",
                "held_out_test_accessed": False,
                "local_evidence": local_protocol,
                "relation_head": relation_training_description,
                "source_sha256": source_sha256,
            },
            indent=2,
        )
        + "\n"
    )


def main() -> None:
    args = parse_args()
    validate_args(args)
    frames = load_inputs(args)
    plans = frames["plans"]
    candidates = frames["candidates"]
    base_features = frames["features"]
    args.out_dir.mkdir(parents=True, exist_ok=True)
    feature_cache = args.out_dir / ".train_perturbed_features.pkl"
    audit_cache = args.out_dir / ".train_perturbation_audit.csv"
    if feature_cache.exists() and audit_cache.exists():
        perturbed_features = pd.read_pickle(feature_cache)
        audit = pd.read_csv(audit_cache)
    else:
        perturbed_features, audit = generate_perturbed_train_features(args, frames)
        perturbed_features.to_pickle(feature_cache)
        audit.to_csv(audit_cache, index=False)
    scores, local_protocol, local_models, fold_models = fit_robust_local_models(
        args, plans, base_features, perturbed_features
    )
    folds = {int(key): int(value) for key, value in local_protocol["fold_by_patient"].items()}
    perturbed_scores = score_perturbed_oof(perturbed_features, fold_models, folds)

    base_heads, base_metrics, base_predictions, base_names = fit_relation_heads(
        plans, candidates, scores, args.tau
    )
    source_sha256 = {
        "scene_plan": relation_training.sha256(
            args.scene_dir / "scene_plan_train_val.csv"
        ),
        "scene_candidates": relation_training.sha256(
            args.scene_dir / "scene_candidates_train_val.csv"
        ),
        "scene_candidate_features": relation_training.sha256(
            args.scene_dir / "scene_candidate_features_train_val.csv"
        ),
    }
    base_dir = args.out_dir / "base_relation"
    save_pack(
        base_dir,
        scores,
        local_models,
        base_heads,
        base_metrics,
        base_predictions,
        base_names,
        local_protocol,
        {"training": "Stress30 base scenes only"},
        source_sha256,
    )

    augmented_rows, conditioned_columns, validation_rows = relation_rows_for_variants(
        args, plans, candidates, scores, perturbed_scores
    )
    augmented_head, augmented_metrics, augmented_predictions = (
        __import__("train_ct28_perturbation_augmented_relation_head").fit_augmented_head(
            augmented_rows, validation_rows, conditioned_columns, args.tau
        )
    )
    augmented_heads = copy.deepcopy(base_heads)
    augmented_heads["ct_conditioned"] = augmented_head
    augmented_metric_pack = copy.deepcopy(base_metrics)
    augmented_metric_pack["ct_conditioned"] = augmented_metrics
    augmented_prediction_pack = [
        row for row in base_predictions if row["model"] != "ct_conditioned"
    ] + augmented_predictions
    augmented_names = copy.deepcopy(base_names)
    augmented_names["ct_conditioned"] = conditioned_columns
    augmented_dir = args.out_dir / "weighted_relation"
    save_pack(
        augmented_dir,
        scores,
        local_models,
        augmented_heads,
        augmented_metric_pack,
        augmented_prediction_pack,
        augmented_names,
        local_protocol,
        {
            "training": "Stress30 base plus five train perturbations",
            "base_weight": args.clean_weight,
            "perturbation_weight_each": variant_weights(args)[1],
        },
        source_sha256,
    )
    args.out_dir.mkdir(parents=True, exist_ok=True)
    audit.to_csv(args.out_dir / "train_perturbation_audit.csv", index=False)
    summary = {
        "status": "development_train_val_only",
        "held_out_test_accessed": False,
        "base_scene": "Stress30: 1 mm position and 30 degree tangent noise",
        "train_perturbations": args.train_perturbations,
        "train_perturbation": {
            "position_noise_mm": args.position_noise_mm,
            "tangent_noise_deg": args.tangent_noise_deg,
        },
        "candidate_weights": {
            "base": args.clean_weight,
            "each_perturbation": variant_weights(args)[1],
            "total_per_source_candidate": 1.0,
        },
        "relation_variants": ["base_relation", "weighted_relation"],
        "validation_scenes": int(plans["split"].eq("val").sum()),
    }
    (args.out_dir / "experiment_protocol.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    feature_cache.unlink(missing_ok=True)
    audit_cache.unlink(missing_ok=True)
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
