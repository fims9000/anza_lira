#!/usr/bin/env python3
"""Layer joint geometry-local training onto the 48/0 PAIR-fusion validation pack."""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import run_ct28_graph_lira as graph
import train_ct28_geometry_augmentation_matrix as matrix
import train_ct28_perturbation_augmented_relation_head as relation_aug
import train_ct28_relation_head as training
import train_ct28_selected_relation_augmentation as selected
from ct28_perturbations import perturb_scene_endpoints


REPO = training.REPO_ROOT
SCENES = graph.DEFAULT_SCENE_DIR
ROBUST = SCENES / "ablations/pair_junction_geometry_robust_unrounded"
PAIR_FUSION = REPO / "varvara/anza_lira_local_results/ct28_fusion_identity_augmentation/joint/pair_fusion/clean_evidence"
OUTPUT = REPO / "varvara/anza_lira_local_results/ct28_geometry_pair_fusion_comparison"
SCOPES = {"pair": ("PAIR",), "junction": ("JUNCTION",), "both": ("PAIR", "JUNCTION")}
SEED = 20260920
LOCAL_COPIES = 5
RELATION_COPIES = 15
TAU = 0.85
TEST_PATIENTS = {954, 958, 972, 973, 980, 984}


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scene-dir", type=Path, default=SCENES)
    parser.add_argument("--robust-evidence", type=Path, default=ROBUST)
    parser.add_argument("--pair-fusion-evidence", type=Path, default=PAIR_FUSION)
    parser.add_argument("--archive-dir", type=Path, default=graph.DEFAULT_ARCHIVE_DIR)
    parser.add_argument("--out-dir", type=Path, default=OUTPUT)
    return parser.parse_args()


def train_joint_geometry(
    features: pd.DataFrame,
    candidates: pd.DataFrame,
    endpoints: pd.DataFrame,
    fold_maps: dict[str, dict[int, int]],
) -> tuple[dict[str, dict], dict[str, pd.Series]]:
    models, scores = {}, {}
    for kind in ("PAIR", "JUNCTION"):
        clean = features[(features["candidate_type"] == kind) & (features["split"] == "train")].copy()
        validation = features[(features["candidate_type"] == kind) & (features["split"] == "val")]
        scene_ids = set(clean["scene_id"])
        kind_candidates = candidates[(candidates["candidate_type"] == kind) & candidates["scene_id"].isin(scene_ids)]
        train_endpoints = endpoints[endpoints["scene_id"].isin(scene_ids)]
        weighted_clean = clean.copy()
        weighted_clean["weight"] = 0.5
        copies = [weighted_clean]
        for repetition in range(LOCAL_COPIES):
            part = matrix.geometry_rows(kind_candidates, train_endpoints, kind, "joint", repetition)
            part = part.merge(clean[["scene_id", "candidate_id", "scan_id", "y"]],
                              on=["scene_id", "candidate_id"], validate="one_to_one")
            if len(part) != len(clean):
                raise ValueError(f"incomplete {kind} joint local copy")
            part["weight"] = 0.1
            copies.append(part)
        fit_data = pd.concat(copies, ignore_index=True)
        weight_sums = fit_data.groupby(["scene_id", "candidate_id"])["weight"].sum()
        if not np.allclose(weight_sums.to_numpy(), 1.0):
            raise ValueError(f"{kind} local weights changed")
        columns = matrix.geometry_columns(kind)
        fold_models = {}
        train_scores = pd.Series(index=pd.MultiIndex.from_frame(clean[["scene_id", "candidate_id"]]), dtype=float)
        for fold in range(5):
            held_patients = {patient for patient, assignment in fold_maps[kind].items() if assignment == fold}
            fit = fit_data[~fit_data["scan_id"].isin(held_patients)]
            held = clean[clean["scan_id"].isin(held_patients)]
            model = training.local_model("hgb").fit(fit[columns], fit["y"], hgb__sample_weight=fit["weight"])
            train_scores.loc[pd.MultiIndex.from_frame(held[["scene_id", "candidate_id"]])] = model.predict_proba(held[columns])[:, 1]
            for patient in held_patients:
                fold_models[patient] = model
        final = training.local_model("hgb").fit(fit_data[columns], fit_data["y"], hgb__sample_weight=fit_data["weight"])
        val_scores = pd.Series(final.predict_proba(validation[columns])[:, 1],
                               index=pd.MultiIndex.from_frame(validation[["scene_id", "candidate_id"]]))
        combined = pd.concat([train_scores, val_scores])
        if combined.isna().any():
            raise ValueError(f"incomplete {kind} OOF or validation scores")
        models[kind] = {"fold": fold_models, "final": final}
        scores[kind] = combined
        print(f"joint geometry: {kind} OOF and final complete", flush=True)
    return models, scores


def main() -> None:
    args = arguments()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    loaded = relation_aug.load_inputs(argparse.Namespace(scene_dir=args.scene_dir, clean_evidence_dir=args.robust_evidence))
    plans, candidates, endpoints, features = (loaded[key] for key in ("plans", "candidates", "endpoints", "features"))
    if set(plans["scan_id"].astype(int)) & TEST_PATIENTS:
        raise ValueError("held-out test patient entered scene pack")
    source_hashes = matrix.source_hashes(args.scene_dir)
    fusion_protocol = json.loads((args.pair_fusion_evidence / "relation_model_protocol.json").read_text())
    if source_hashes != loaded["protocol"]["source_sha256"] or source_hashes != fusion_protocol["source_sha256"]:
        raise ValueError("source scene packs differ")
    base_fold_models, oof_error = selected.fold_models_for_patients(loaded)
    base_scores = pd.read_csv(args.pair_fusion_evidence / "relation_local_scores_train_val.csv")
    base_pack = joblib.load(args.pair_fusion_evidence / "relation_models.joblib")
    if not base_scores[["scene_id", "candidate_id"]].equals(loaded["scores"][["scene_id", "candidate_id"]]):
        raise ValueError("PAIR fusion and robust candidate order differ")
    if not np.array_equal(base_scores[["geometry_score", "ct_score"]].to_numpy(),
                          loaded["scores"][["geometry_score", "ct_score"]].to_numpy()):
        raise ValueError("PAIR fusion changed relation evidence")
    fold_maps = {
        kind: {int(patient): int(fold) for patient, fold in loaded["protocol"][f"patient_oof_folds_{kind.lower()}_geometry"].items()}
        for kind in ("PAIR", "JUNCTION")
    }
    local_models, local_scores = train_joint_geometry(features, candidates, endpoints, fold_maps)
    variants = {}
    for name, selected_kinds in SCOPES.items():
        table = base_scores.copy().set_index(["scene_id", "candidate_id"])
        pack = copy.deepcopy(base_pack)
        for kind in selected_kinds:
            keys = table.index[table["candidate_type"].eq(kind)]
            table.loc[keys, "geometry_score"] = local_scores[kind].loc[keys].to_numpy()
            pack["local_models"][kind]["geometry"] = local_models[kind]["final"]
        table = table.reset_index()
        if not np.array_equal(table[["ct_score", "geometry_plus_ct_score"]].to_numpy(),
                              base_scores[["ct_score", "geometry_plus_ct_score"]].to_numpy()):
            raise ValueError("CT or PAIR fusion score changed")
        out = args.out_dir / name
        out.mkdir(exist_ok=True)
        table.to_csv(out / "relation_local_scores_train_val.csv", index=False)
        table = pd.read_csv(out / "relation_local_scores_train_val.csv")
        clean_rows, columns = graph.relation_feature_rows(plans, candidates, table, ("geometry_score", "ct_score"))
        if len(columns) != 84:
            raise ValueError("relation feature dimension changed")
        (out / "augmented_relation_rows_train.csv").unlink(missing_ok=True)
        variants[name] = {"selected": selected_kinds, "scores": table, "pack": pack,
                          "clean_rows": clean_rows, "columns": columns, "out": out}

    train_plans = plans[plans["split"] == "train"]
    train_ids = set(train_plans["scene_id"])
    train_candidates = candidates[candidates["scene_id"].isin(train_ids)]
    train_endpoints = endpoints[endpoints["scene_id"].isin(train_ids)]
    expected_geometry = pd.read_csv(graph.ct_features.EXPECTED_GEOMETRY).set_index("scan_id")
    expected_alignment = pd.read_csv(graph.ct_features.EXPECTED_ALIGNMENT).set_index("scan_id")
    arm_names = graph.ct_features.arm_feature_names(graph.ct_features.RADII_MM)
    first_patient = min(training.EXPECTED_PATIENT_IDS["train"])
    for patient in sorted(training.EXPECTED_PATIENT_IDS["train"]):
        patient_plans = train_plans[train_plans["scan_id"] == patient]
        patient_ids = set(patient_plans["scene_id"])
        patient_candidates = train_candidates[train_candidates["scene_id"].isin(patient_ids)]
        patient_endpoints = train_endpoints[train_endpoints["scene_id"].isin(patient_ids)]
        by_scene = dict(tuple(patient_candidates.groupby("scene_id", sort=False)))
        ct, inverse_affine = graph.load_verified_ct(patient, args.archive_dir, expected_geometry, expected_alignment)
        rows_by_variant = {name: [] for name in variants}
        for repetition in range(RELATION_COPIES):
            feature_rows = []
            for scene_id, scene_endpoints in patient_endpoints.groupby("scene_id", sort=False):
                perturbed = perturb_scene_endpoints(scene_endpoints, seed=SEED, repetition=repetition,
                                                    position_noise_mm=0.8, tangent_noise_deg=20.0).set_index("endpoint_id")
                for candidate in by_scene[scene_id].itertuples(index=False):
                    feature_rows.append(graph.perturbed_candidate_features(
                        pd.Series(candidate._asdict()), perturbed, ct, inverse_affine, arm_names
                    ))
            frame = pd.DataFrame(feature_rows)
            base_noise = matrix.score_geometry_ct(frame, base_fold_models[patient])
            for name, data in variants.items():
                scores = base_noise.copy()
                for kind in data["selected"]:
                    mask = frame["candidate_type"].eq(kind)
                    model = local_models[kind]["fold"][patient]
                    model_columns = list(model.feature_names_in_)
                    scores.loc[mask, "geometry_score"] = model.predict_proba(frame.loc[mask, model_columns])[:, 1]
                relation_rows, relation_columns = graph.relation_feature_rows(
                    patient_plans, patient_candidates, scores, ("geometry_score", "ct_score")
                )
                if relation_columns != data["columns"]:
                    raise ValueError("relation feature order changed")
                for row in relation_rows:
                    row["augmentation_index"] = repetition + 1
                    row["sample_weight"] = 0.5 / RELATION_COPIES
                rows_by_variant[name].extend(relation_rows)
        for name, rows in rows_by_variant.items():
            pd.DataFrame(rows).to_csv(variants[name]["out"] / "augmented_relation_rows_train.csv",
                                      mode="a", header=patient == first_patient, index=False)
        print(f"relation augmentation: patient {patient} complete", flush=True)
        del ct

    for name, data in variants.items():
        out, scores, pack = data["out"], data["scores"], data["pack"]
        clean_train = [dict(row, augmentation_index=0, sample_weight=0.5)
                       for row in data["clean_rows"] if row["split"] == "train"]
        clean_val = [row for row in data["clean_rows"] if row["split"] == "val"]
        noisy = pd.read_csv(out / "augmented_relation_rows_train.csv").to_dict("records")
        training_rows = clean_train + noisy
        relation_aug.validate_augmentation_weights(training_rows, RELATION_COPIES)
        head, metrics, ct_predictions = relation_aug.fit_augmented_head(training_rows, clean_val, data["columns"], TAU)
        geometry_rows, geometry_columns = graph.relation_feature_rows(plans, candidates, scores, ("geometry_score",))
        _, geometry_predictions, geometry_head = training.fit_relation_head(geometry_rows, geometry_columns, TAU, "geometry_only")
        pack["relation_heads"]["ct_conditioned"] = head
        pack["relation_heads"]["geometry_only"] = geometry_head
        pack["ct_conditioned_relation_features"] = data["columns"]
        pack["geometry_relation_features"] = geometry_columns
        joblib.dump(pack, out / "relation_models.joblib")
        pd.DataFrame(geometry_predictions + ct_predictions).to_csv(out / "relation_predictions_val.csv", index=False)
        (out / "relation_metrics_val.json").write_text(json.dumps(metrics, indent=2) + "\n")
        (out / "relation_model_protocol.json").write_text(json.dumps({
            "status": "validation_ablation_not_frozen", "held_out_test_accessed": False,
            "source_sha256": source_hashes, "base_oof_reproduction_max_error": oof_error,
            "base_pair_fusion_evidence": str(args.pair_fusion_evidence),
            "joint_geometry_selected": list(data["selected"]),
            "geometry_oof_folds": fold_maps,
            "local_copies": LOCAL_COPIES, "local_clean_weight": 0.5,
            "relation_copies": RELATION_COPIES, "relation_clean_weight": 0.5,
            "position_sigma_mm": 0.8, "tangent_sigma_deg": 20.0,
            "pair_identity": "geometry_plus_ct_score", "junction_identity": "geometry_score",
            "tau": TAU, "consistency": 0.60,
        }, indent=2) + "\n")
        print(f"{name}: clean evidence complete", flush=True)


if __name__ == "__main__":
    main()
