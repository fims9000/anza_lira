#!/usr/bin/env python3
"""Compare 5 position + 5 tangent + 5 joint relation copies with 15 joint copies."""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import run_ct28_graph_lira as graph
import train_ct28_perturbation_augmented_relation_head as augmentation
import train_ct28_relation_head as training
import train_ct28_selected_relation_augmentation as selected


REPO = training.REPO_ROOT
SCENES = graph.DEFAULT_SCENE_DIR
ROBUST = SCENES / "ablations/pair_junction_geometry_robust_unrounded"
BASE = REPO / "varvara/anza_lira_local_results/ct28_fusion_identity_augmentation/joint/pair_fusion/clean_evidence"
RELATION = REPO / "varvara/anza_lira_local_results/ct28_copy_count_ablations/relation"
OUTPUT = REPO / "varvara/anza_lira_local_results/ct28_copy_count_ablations/noise_mix/mixed_5_5_5"
TEST_IDS = {954, 958, 972, 973, 980, 984}


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scene-dir", type=Path, default=SCENES)
    parser.add_argument("--robust-evidence", type=Path, default=ROBUST)
    parser.add_argument("--base-evidence", type=Path, default=BASE)
    parser.add_argument("--joint-copies", type=Path, default=RELATION / "joint_train_relation_copies.csv")
    parser.add_argument("--archive-dir", type=Path, default=graph.DEFAULT_ARCHIVE_DIR)
    parser.add_argument("--out-dir", type=Path, default=OUTPUT)
    return parser.parse_args()


def main() -> None:
    config = arguments()
    config.out_dir.mkdir(parents=True, exist_ok=True)
    loaded = augmentation.load_inputs(argparse.Namespace(
        scene_dir=config.scene_dir, clean_evidence_dir=config.robust_evidence))
    plans, candidates = loaded["plans"], loaded["candidates"]
    if set(plans.scan_id.astype(int)) & TEST_IDS:
        raise ValueError("held-out test entered scene pack")
    base_protocol = json.loads((config.base_evidence / "relation_model_protocol.json").read_text())
    if base_protocol["source_sha256"] != loaded["protocol"]["source_sha256"]:
        raise ValueError("frozen scene SHA changed")
    actual_hashes = {
        key: training.sha256(config.scene_dir / filename)
        for key, filename in (
            ("scene_plan", "scene_plan_train_val.csv"),
            ("scene_candidates", "scene_candidates_train_val.csv"),
            ("scene_candidate_features", "scene_candidate_features_train_val.csv"),
        )
    }
    if actual_hashes != base_protocol["source_sha256"]:
        raise ValueError("scene files no longer match frozen SHA")
    base_scores = pd.read_csv(config.base_evidence / "relation_local_scores_train_val.csv")
    base_predictions = pd.read_csv(config.base_evidence / "relation_predictions_val.csv")
    pack = joblib.load(config.base_evidence / "relation_models.joblib")
    fold_models, error = selected.fold_models_for_patients(loaded)
    clean_rows, columns = graph.relation_feature_rows(
        plans, candidates, base_scores, ("geometry_score", "ct_score"))
    if len(columns) != 84:
        raise ValueError("relation feature dimension changed")
    noisy_parts = []
    for name, position, tangent in (("position", 0.8, 0.0), ("tangent", 0.0, 20.0)):
        noise_args = argparse.Namespace(
            archive_dir=config.archive_dir, perturbations=5, seed=20260920,
            position_noise_mm=position, tangent_noise_deg=tangent)
        rows, noisy_columns, audit = augmentation.build_augmented_train_rows(
            noise_args, plans, loaded["endpoints"], candidates,
            fold_models, {p: p for p in fold_models})
        if noisy_columns != columns:
            raise ValueError(f"{name} relation feature order changed")
        for row in rows:
            row["noise_mode"] = name
        noisy_parts.extend(rows)
        pd.DataFrame(audit).to_csv(config.out_dir / f"{name}_extraction_audit.csv", index=False)
        print(f"{name}: 5 copies built", flush=True)
    joint = pd.read_csv(config.joint_copies)
    joint = joint[joint.augmentation_index.le(5)].copy()
    if len(joint) != 5*len(plans[plans.split.eq("train")]):
        raise ValueError("joint copy count changed")
    joint["noise_mode"] = "joint"
    noisy_parts.extend(joint.to_dict("records"))
    if len(noisy_parts) != 15*len(plans[plans.split.eq("train")]):
        raise ValueError("mixed-noise scene copy count changed")
    for row in noisy_parts:
        if row["noise_mode"] == "tangent":
            row["augmentation_index"] += 5
        elif row["noise_mode"] == "joint":
            row["augmentation_index"] += 10
        row["sample_weight"] = 0.5/15
    pd.DataFrame(noisy_parts).to_csv(config.out_dir / "mixed_train_relation_copies.csv", index=False)
    train_rows = [dict(row, augmentation_index=0, sample_weight=0.5)
                  for row in clean_rows if row["split"] == "train"]
    train_rows.extend(noisy_parts)
    augmentation.validate_augmentation_weights(train_rows, 15)
    validation = [row for row in clean_rows if row["split"] == "val"]
    head, metrics, predictions = augmentation.fit_augmented_head(
        train_rows, validation, columns, 0.85)
    output_pack = copy.deepcopy(pack)
    output_pack["relation_heads"]["ct_conditioned"] = head
    joblib.dump(output_pack, config.out_dir / "relation_models.joblib")
    base_scores.to_csv(config.out_dir / "relation_local_scores_train_val.csv", index=False)
    geometry_predictions = base_predictions[base_predictions.model.eq("geometry_only")]
    pd.concat([geometry_predictions, pd.DataFrame(predictions)], ignore_index=True).to_csv(
        config.out_dir / "relation_predictions_val.csv", index=False)
    (config.out_dir / "relation_metrics_val.json").write_text(json.dumps(metrics, indent=2)+"\n")
    (config.out_dir / "relation_model_protocol.json").write_text(json.dumps({
        "status": "validation_ablation_not_frozen", "held_out_test_accessed": False,
        "source_sha256": base_protocol["source_sha256"],
        "reference_evidence": str(config.base_evidence),
        "train_copies": {"position_only": 5, "tangent_only": 5, "joint": 5},
        "clean_weight": 0.5, "per_copy_weight": 0.5/15,
        "base_oof_reproduction_max_error": error,
        "pair_identity": "geometry_plus_ct_score", "junction_identity": "geometry_score",
        "tau": 0.85, "consistency": 0.60, "evaluation_perturbations": 15,
    }, indent=2)+"\n")
    print("mixed 5+5+5 relation evidence complete", flush=True)


if __name__ == "__main__":
    main()
