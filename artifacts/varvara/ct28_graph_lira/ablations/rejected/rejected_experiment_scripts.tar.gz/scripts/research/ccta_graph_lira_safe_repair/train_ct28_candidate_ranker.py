#!/usr/bin/env python3
"""One pairwise-linear identity ablation; frozen K10/15 relation probabilities."""
from pathlib import Path
import json
import joblib
import numpy as np
import pandas as pd
from scipy.special import expit
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
import evaluate_ct28_recovery as recovery
import run_ct28_graph_lira as graph
import train_ct28_relation_head as training
from ct28_perturbations import perturb_scene_endpoints

OUT = recovery.OUT / 'pairwise_identity'


def fit_ranker(clean, copies, columns, count):
    clean = clean.copy(); clean['augmentation_index'] = 0
    fit = pd.concat([clean, copies[copies.augmentation_index.le(count)]],ignore_index=True)
    assert set(fit.scan_id.astype(int)) == training.EXPECTED_PATIENT_IDS['train']
    imputer=SimpleImputer(strategy='median').fit(clean[columns])
    scaler=StandardScaler().fit(imputer.transform(clean[columns]))
    x=scaler.transform(imputer.transform(fit[columns]))
    differences=[];weights=[]
    for (_,rep),group in fit.groupby(['scene_id','augmentation_index'],sort=False):
        pos=group.index[group.y.eq(1)];neg=group.index[group.y.eq(0)]
        if len(pos)!=1 or not len(neg):
            continue
        diff=x[pos[0]]-x[neg]
        differences.extend([diff,-diff])
        weight=(.5 if rep==0 else .5/count)/len(neg)/2
        weights.extend([np.full(len(neg),weight),np.full(len(neg),weight)])
    dx=np.concatenate(differences);w=np.concatenate(weights)
    labels=np.concatenate([np.full(len(d),int(i%2==0)) for i,d in enumerate(differences)])
    model=LogisticRegression(C=1.,fit_intercept=False,max_iter=2000,random_state=0)
    # Rescale weights to one mean weight while preserving per-scene balance.
    model.fit(dx,labels,sample_weight=w/w.mean())
    return dict(imputer=imputer,scaler=scaler,model=model,columns=columns,
                train_pairs=len(dx)//2,train_copies=count)


def predict(pack,features):
    x=pack['scaler'].transform(pack['imputer'].transform(features[pack['columns']]))
    return expit(pack['model'].decision_function(x))


def ranking(scores,candidates,column):
    merged=scores.drop(columns=['y'],errors='ignore').merge(candidates[['scene_id','candidate_id','y']],on=['scene_id','candidate_id'],validate='many_to_one')
    result={}
    for kind,group in merged.groupby('candidate_type'):
        valid=[]
        for key,g in group.groupby(['repetition','scene_id']):
            if not g.y.eq(1).any() or not g.y.eq(0).any():continue
            order=g.sort_values([column,'candidate_id'],ascending=[False,True])
            valid.append(int(order.iloc[0].y==1))
        result[kind]=dict(correct=sum(valid),competitive_repeats=len(valid))
    return result


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    plans=pd.read_csv(graph.DEFAULT_SCENE_DIR/'scene_plan_train_val.csv')
    candidates=pd.read_csv(graph.DEFAULT_SCENE_DIR/'scene_candidates_train_val.csv')
    endpoints=pd.read_csv(graph.DEFAULT_SCENE_DIR/'scene_endpoints_train_val.csv')
    features=pd.read_csv(graph.DEFAULT_SCENE_DIR/'scene_candidate_features_train_val.csv',low_memory=False)
    scores=pd.read_csv(recovery.SELECTED/'relation_local_scores_train_val.csv')
    models=joblib.load(recovery.SELECTED/'relation_models.joblib')
    pack={}
    for kind,count,path in [('PAIR',10,recovery.RUNS/'fusion/joint_pair_train_copies.csv'),
                            ('JUNCTION',5,recovery.RUNS/'geometry/junction_position_train_copies.csv')]:
        columns=list(models['local_models'][kind]['geometry_plus_ct' if kind=='PAIR' else 'geometry'].feature_names_in_)
        clean=features[features.split.eq('train')&features.candidate_type.eq(kind)]
        copies=pd.read_csv(path,float_precision='round_trip')
        pack[kind]=fit_ranker(clean,copies,columns,count)
        print(f'{kind} ranker fitted on {pack[kind]["train_pairs"]} positive-negative pairs',flush=True)
    joblib.dump(pack,OUT/'identity_rankers.joblib')
    valplans=plans[plans.split.eq('val')]
    assert set(valplans.scan_id)==graph.EXPECTED_VALIDATION_PATIENTS
    clean=scores[scores.split.eq('val')].copy();clean['rank_score']=np.nan
    for kind in pack:
        mask=clean.candidate_type.eq(kind)
        lookup=features.set_index(['scene_id','candidate_id'])
        keys=pd.MultiIndex.from_frame(clean.loc[mask,['scene_id','candidate_id']])
        clean.loc[mask,'rank_score']=predict(pack[kind],lookup.loc[keys])
    cache=OUT/'noisy_rank_scores_val.csv.gz'
    cache_manifest=OUT/'noisy_rank_scores_sources.json'
    sources=[graph.DEFAULT_SCENE_DIR/name for name in ('scene_plan_train_val.csv','scene_candidates_train_val.csv','scene_endpoints_train_val.csv','scene_candidate_features_train_val.csv')]
    sources += [recovery.RUNS/'fusion/joint_pair_train_copies.csv', recovery.RUNS/'geometry/junction_position_train_copies.csv', recovery.SELECTED/'relation_models.joblib', Path(__file__).resolve()]
    signature={str(path.relative_to(graph.REPO_ROOT)):graph.sha256(path) for path in sources}
    if cache.exists():
        if not cache_manifest.exists() or json.loads(cache_manifest.read_text()) != signature:
            raise ValueError('rank-score cache source hashes differ or are missing')
        noisy_rank=pd.read_csv(cache)
    else:
        expected_geometry=pd.read_csv(graph.ct_features.EXPECTED_GEOMETRY).set_index('scan_id')
        expected_alignment=pd.read_csv(graph.ct_features.EXPECTED_ALIGNMENT).set_index('scan_id')
        rows=[]
        for patient in sorted(graph.EXPECTED_VALIDATION_PATIENTS):
            ct,inverse=graph.load_verified_ct(patient,graph.DEFAULT_ARCHIVE_DIR,expected_geometry,expected_alignment)
            ids=set(valplans.loc[valplans.scan_id.eq(patient),'scene_id'])
            ec=endpoints[endpoints.scene_id.isin(ids)]
            cc=candidates[candidates.scene_id.isin(ids)]
            for rep in range(15):
                pert=pd.concat([perturb_scene_endpoints(group,seed=20260920,repetition=rep,position_noise_mm=.8,tangent_noise_deg=20.)
                                for _,group in ec.groupby('scene_id',sort=False)],ignore_index=True)
                groups=dict(tuple(pert.groupby('scene_id')))
                values=[]
                for c in cc.to_dict('records'):
                    lookup=groups[c['scene_id']].set_index('endpoint_id')
                    if c['candidate_type']=='PAIR':
                        row=graph.perturbed_candidate_features(pd.Series(c),lookup,ct,inverse,[])
                    else:
                        items=[graph.endpoint_item(lookup.loc[e]) for e in c['endpoint_ids'].split('|')]
                        row=dict(scene_id=c['scene_id'],candidate_id=c['candidate_id'],candidate_type='JUNCTION',
                                 **dict(zip(training.JUNCTION_GEOMETRY_FEATURES,graph.scene_builder.oriented_junction_geometry(items))))
                    values.append(row)
                f=pd.DataFrame(values)
                for kind in pack:
                    sub=f[f.candidate_type.eq(kind)].copy();sub['rank_score']=predict(pack[kind],sub)
                    sub['repetition']=rep
                    rows.extend(sub[['scene_id','candidate_id','candidate_type','repetition','rank_score']].to_dict('records'))
            print(f'validation ranker: patient {patient} completed',flush=True)
            del ct
        noisy_rank=pd.DataFrame(rows)
        noisy_rank.to_csv(cache,index=False,compression={'method':'gzip','mtime':0})
        cache_manifest.write_text(json.dumps(signature,indent=2)+'\n')
    assert np.isfinite(noisy_rank.rank_score).all()
    assert noisy_rank[['repetition','scene_id','candidate_id']].duplicated().sum()==0
    noisy=pd.read_csv(recovery.TRACE/'local_scores_val.csv.gz');noisy=noisy[noisy['mode'].eq('joint')]
    noisy=noisy.merge(noisy_rank,on=['scene_id','candidate_id','candidate_type','repetition'],validate='one_to_one')
    assert len(noisy)==len(candidates[candidates.scene_id.isin(valplans.scene_id)])*15
    clean['repetition']=-1
    rank_summary={}
    for label,data in [('clean',clean),('joint',noisy)]:
        baseline=data.copy();baseline['selected_score']=np.where(baseline.candidate_type.eq('PAIR'),baseline.geometry_plus_ct_score,baseline.geometry_score)
        rank_summary[label]=dict(K10_15=ranking(baseline,candidates,'selected_score'),pairwise=ranking(data,candidates,'rank_score'))
    (OUT/'ranking_metrics.json').write_text(json.dumps(rank_summary,indent=2)+'\n')
    relation_rows,cols=graph.relation_feature_rows(plans,candidates,scores,['geometry_score','ct_score'])
    rv=pd.DataFrame(relation_rows);rv=rv[rv.split.eq('val')]
    h=models['relation_heads']['ct_conditioned']
    bp=dict(zip(rv.scene_id,h.predict_proba(rv[cols].to_numpy())))
    nf=pd.read_csv(recovery.TRACE/'relation_features_val.csv.gz');nf=nf[nf['mode'].eq('joint')]
    npred=dict(zip(zip(nf.repetition,nf.scene_id),h.predict_proba(nf[cols].to_numpy())))
    frames=[];metrics={}
    for variant,kinds in [('K10_15',()),('pair_ranker',('PAIR',)),('junction_ranker',('JUNCTION',)),('both_rankers',('PAIR','JUNCTION'))]:
        c=clean.copy();n=noisy.copy()
        for kind in kinds:
            col='geometry_plus_ct_score' if kind=='PAIR' else 'geometry_score'
            for data in (c,n):
                mask=data.candidate_type.eq(kind);data.loc[mask,col]=data.loc[mask,'rank_score']
        frame,_=recovery.evaluate(variant,valplans,candidates,c,n,bp,npred)
        metrics[variant]=recovery.summary(frame);frames.append(frame)
        print(variant,metrics[variant],flush=True)
    result=pd.concat(frames,ignore_index=True);result.to_csv(OUT/'predictions_val.csv',index=False)
    for keys,name in [(['variant','scan_id'],'per_patient'),(['variant','scene_family','pair_count','junction_count'],'count_strata')]:
        rows=[]
        for key,group in result.groupby(keys):rows.append(dict(zip(keys,key))|dict(scenes=len(group))|recovery.summary(group))
        pd.DataFrame(rows).to_csv(OUT/f'{name}_val.csv',index=False)
    (OUT/'metrics.json').write_text(json.dumps(dict(held_out_test_accessed=False,
        baseline='K10/15',change='identity only; four local relation score streams and relation probabilities frozen',
        ranker='pairwise LogisticRegression C=1, no intercept; train-fitted median/scaler; sigmoid utility for identity',
        oof_note='ranker scores are not inputs to relation head; no new ranker train scores used for stacking',
        train_protocol={'PAIR':'45 raw geometry+CT; clean0.5 +10joint copies total0.5', 'JUNCTION':'9 geometry; clean0.5 +5position copies total0.5', 'pair_weight':'each scene/variant total weight divided equally among its true-false pairs'},
        tau=.85,consistency=.60,repeats=15,source_sha256=signature,metrics=metrics,ranking=rank_summary),indent=2)+'\n')


if __name__=='__main__': main()
