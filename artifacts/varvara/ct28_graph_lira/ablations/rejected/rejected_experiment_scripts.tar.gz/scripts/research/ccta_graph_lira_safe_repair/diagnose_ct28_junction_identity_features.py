#!/usr/bin/env python3
"""Validation-only JUNCTION fusion-input interventions under position noise."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import run_ct28_graph_lira as graph
from diagnose_ct28_junction_inputs import paired_noise


ROOT = graph.DEFAULT_SCENE_DIR
GEOMETRY = list(graph.relation_training.JUNCTION_GEOMETRY_FEATURES)
FAMILIES = {"junction_only", "mixed"}


def score_variants(
    perturbed: pd.DataFrame,
    clean: pd.DataFrame,
    model: object,
    individual_geometry: bool = False,
) -> dict[str, np.ndarray]:
    columns = list(model.feature_names_in_)
    ct_columns = [column for column in columns if column not in GEOMETRY]
    if len(columns) != 161 or len(ct_columns) != 152:
        raise ValueError("unexpected JUNCTION geometry+CT feature layout")
    outputs = {}
    variants = [
        ("dynamic", []),
        ("fixed_geometry_inputs", GEOMETRY),
        ("fixed_ct_inputs", ct_columns),
    ]
    if individual_geometry:
        variants.extend((f"fixed_{column}", [column]) for column in GEOMETRY)
    for name, replace in variants:
        values = perturbed[columns].copy()
        if replace:
            values.loc[:, replace] = clean[replace].to_numpy()
        outputs[name] = model.predict_proba(values)[:, 1]
    return outputs


def summarize(rows: pd.DataFrame) -> list[dict[str, object]]:
    result = []
    for (variant, family), part in rows.groupby(["variant", "scene_family"]):
        competitive = part[part["competitive"] == 1]
        result.append(
            {
                "variant": variant,
                "scene_family": family,
                "scene_repeats": int(len(part)),
                "competitive_scene_repeats": int(len(competitive)),
                "top1": int(part["true_top1"].sum()),
                "top1_rate": float(part["true_top1"].mean()),
                "competitive_top1": int(competitive["true_top1"].sum()),
                "competitive_top1_rate": float(competitive["true_top1"].mean()),
                "median_true_score": float(part["true_score"].median()),
                "median_best_false_score": float(competitive["best_false_score"].median()),
                "median_competitive_margin": float(competitive["margin"].median()),
            }
        )
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scene-dir", type=Path, default=ROOT)
    parser.add_argument(
        "--evidence-dir", type=Path,
        default=ROOT / "ablations/junction_position_robustness",
    )
    parser.add_argument(
        "--out-dir", type=Path,
        default=ROOT / "ablations/junction_identity_diagnostics/fusion_inputs",
    )
    parser.add_argument("--individual-geometry", action="store_true")
    args = parser.parse_args()
    plans = pd.read_csv(args.scene_dir / "scene_plan_train_val.csv")
    candidates = pd.read_csv(args.scene_dir / "scene_candidates_train_val.csv")
    graph.relation_training.validate_scene_inputs(plans, candidates)
    plans = plans[plans.split.eq("val") & plans.scene_family.isin(FAMILIES)]
    if len(plans) != 72 or set(plans.scan_id) != graph.EXPECTED_VALIDATION_PATIENTS:
        raise ValueError("unexpected JUNCTION validation scenes")
    candidates = candidates[
        candidates.scene_id.isin(plans.scene_id) & candidates.candidate_type.eq("JUNCTION")
    ]
    endpoints = pd.read_csv(args.scene_dir / "scene_endpoints_train_val.csv")
    endpoints = endpoints[endpoints.scene_id.isin(plans.scene_id)]
    clean_features = pd.read_csv(
        args.scene_dir / "scene_candidate_features_train_val.csv", low_memory=False
    ).set_index(["scene_id", "candidate_id"])
    pack = joblib.load(args.evidence_dir / "relation_models.joblib")
    model = pack["local_models"]["JUNCTION"]["geometry_plus_ct"]
    expected_geometry = pd.read_csv(graph.ct_features.EXPECTED_GEOMETRY).set_index("scan_id")
    expected_alignment = pd.read_csv(graph.ct_features.EXPECTED_ALIGNMENT).set_index("scan_id")
    arm_names = graph.ct_features.arm_feature_names(graph.ct_features.RADII_MM)
    rows = []
    for scan_id in sorted(plans.scan_id.unique()):
        patient_plans = plans[plans.scan_id.eq(scan_id)]
        patient_candidates = candidates[candidates.scene_id.isin(patient_plans.scene_id)]
        patient_endpoints = endpoints[endpoints.scene_id.isin(patient_plans.scene_id)]
        by_scene = {
            scene_id: group for scene_id, group in patient_candidates.groupby("scene_id")
        }
        ct, inverse_affine = graph.load_verified_ct(
            int(scan_id), graph.DEFAULT_ARCHIVE_DIR, expected_geometry, expected_alignment
        )
        for repetition in range(15):
            for scene_id, scene_endpoints in patient_endpoints.groupby("scene_id"):
                scene_candidates = by_scene[scene_id]
                perturbed_endpoints = paired_noise(
                    scene_endpoints, repetition, "position_only"
                ).set_index("endpoint_id")
                features = pd.DataFrame(
                    graph.perturbed_candidate_features(
                        candidate, perturbed_endpoints, ct, inverse_affine, arm_names
                    )
                    for _, candidate in scene_candidates.iterrows()
                ).set_index(["scene_id", "candidate_id"])
                keys = list(features.index)
                clean = clean_features.loc[keys]
                y = scene_candidates.set_index(["scene_id", "candidate_id"]).loc[keys, "y"]
                if int((y == 1).sum()) != 1:
                    raise ValueError(f"missing unique true JUNCTION candidate: {scene_id}")
                family = patient_plans.set_index("scene_id").loc[scene_id, "scene_family"]
                for variant, scores in score_variants(
                    features, clean, model, args.individual_geometry
                ).items():
                    true_score = float(scores[y.to_numpy() == 1][0])
                    false = scores[y.to_numpy() == 0]
                    best_false = float(false.max()) if len(false) else np.nan
                    rows.append(
                        {
                            "scan_id": int(scan_id),
                            "scene_id": scene_id,
                            "scene_family": family,
                            "repetition": repetition,
                            "variant": variant,
                            "competitive": int(len(false) > 0),
                            "true_top1": int(y.iloc[int(np.argmax(scores))] == 1),
                            "true_score": true_score,
                            "best_false_score": best_false,
                            "margin": true_score - best_false,
                        }
                    )
            if repetition in (4, 9, 14):
                print(f"fusion inputs: patient {scan_id}, repeats {repetition+1}/15", flush=True)
        del ct
    frame = pd.DataFrame(rows)
    expected_variants = 3 + (len(GEOMETRY) if args.individual_geometry else 0)
    if len(frame) != 72 * 15 * expected_variants:
        raise ValueError("incomplete fusion-input diagnostic")
    args.out_dir.mkdir(parents=True, exist_ok=True)
    frame.to_csv(args.out_dir / "fusion_input_interventions_val.csv.gz", index=False,
                 compression={"method": "gzip", "mtime": 0})
    summary = summarize(frame)
    (args.out_dir / "summary.json").write_text(json.dumps({
        "held_out_test_accessed": False,
        "training_performed": False,
        "patients": sorted(int(patient) for patient in plans.scan_id.unique()),
        "position_noise_mm_sigma_per_axis": 0.8,
        "tangent_noise_deg_sigma": 0.0,
        "repetitions": 15,
        "individual_geometry_inputs_frozen": args.individual_geometry,
        "model_pack_sha256": graph.sha256(args.evidence_dir / "relation_models.joblib"),
        "scene_candidate_features_sha256": graph.sha256(
            args.scene_dir / "scene_candidate_features_train_val.csv"),
        "interpretation": "Counterfactual input freezing isolates fusion-model geometry and CT feature contributions; hybrids are diagnostic, not deployable candidates.",
        "metrics": summary,
    }, indent=2) + "\n")
    print(pd.DataFrame(summary).to_string(index=False), flush=True)


if __name__ == "__main__":
    main()
