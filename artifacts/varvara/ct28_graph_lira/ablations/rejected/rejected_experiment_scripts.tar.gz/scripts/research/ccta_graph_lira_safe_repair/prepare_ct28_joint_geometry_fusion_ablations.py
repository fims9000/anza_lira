#!/usr/bin/env python3
"""Cross frozen fusion-identity variants with the joint-geometry CT28 evidence pack."""
from __future__ import annotations

import copy
import json
from pathlib import Path
import shutil

import joblib
import numpy as np
import pandas as pd

import train_ct28_relation_head as training


REPO = training.REPO_ROOT
BASE = REPO / "varvara/anza_lira_local_results/ct28_geometry_pair_fusion_comparison/both"
FUSION = REPO / "varvara/anza_lira_local_results/ct28_fusion_identity_augmentation"
OUTPUT = REPO / "varvara/anza_lira_local_results/ct28_joint_geometry_ablations/fusion"
MODES = ("position_only", "tangent_only", "joint")
SCOPES = ("pair_fusion", "junction_fusion", "both_fusion")
TEST_PATIENTS = {954, 958, 972, 973, 980, 984}


def main() -> None:
    base_scores = pd.read_csv(BASE / "relation_local_scores_train_val.csv")
    base_pack = joblib.load(BASE / "relation_models.joblib")
    base_protocol = json.loads((BASE / "relation_model_protocol.json").read_text())
    if set(base_scores.scan_id.astype(int)) & TEST_PATIENTS:
        raise ValueError("held-out test entered base scores")
    if len(base_scores) != 15092 or base_protocol["joint_geometry_selected"] != ["PAIR", "JUNCTION"]:
        raise ValueError("joint-geometry source is not the expected frozen comparison")
    for mode in MODES:
        for scope in SCOPES:
            source = FUSION / mode / scope / "clean_evidence"
            fusion_scores = pd.read_csv(source / "relation_local_scores_train_val.csv")
            fusion_pack = joblib.load(source / "relation_models.joblib")
            protocol = json.loads((source / "relation_model_protocol.json").read_text())
            if protocol["source_sha256"] != base_protocol["source_sha256"]:
                raise ValueError(f"scene source mismatch: {mode}/{scope}")
            if not fusion_scores[["scene_id", "candidate_id"]].equals(base_scores[["scene_id", "candidate_id"]]):
                raise ValueError(f"candidate order mismatch: {mode}/{scope}")
            scores = base_scores.copy()
            scores["geometry_plus_ct_score"] = fusion_scores["geometry_plus_ct_score"]
            if not np.array_equal(scores[["geometry_score", "ct_score"]].to_numpy(),
                                  base_scores[["geometry_score", "ct_score"]].to_numpy()):
                raise ValueError("relation evidence changed")
            pack = copy.deepcopy(base_pack)
            for kind in ("PAIR", "JUNCTION"):
                pack["local_models"][kind]["geometry_plus_ct"] = fusion_pack["local_models"][kind]["geometry_plus_ct"]
            out = OUTPUT / mode / scope
            out.mkdir(parents=True, exist_ok=True)
            scores.to_csv(out / "relation_local_scores_train_val.csv", index=False)
            joblib.dump(pack, out / "relation_models.joblib")
            shutil.copy2(BASE / "relation_predictions_val.csv", out / "relation_predictions_val.csv")
            (out / "relation_model_protocol.json").write_text(json.dumps({
                "status": "validation_ablation_not_frozen",
                "held_out_test_accessed": False,
                "source_sha256": base_protocol["source_sha256"],
                "geometry_source": str(BASE),
                "fusion_source": str(source),
                "fusion_augmentation": mode,
                "fusion_scope": scope,
                "relation_head": "joint_augmentation_half_weight_from_geometry_source",
                "pair_identity": "geometry_plus_ct_score",
                "junction_identity": "geometry_score" if scope == "pair_fusion" else "geometry_plus_ct_score",
                "tau": 0.85,
                "consistency": 0.60,
            }, indent=2) + "\n")
            print(f"prepared {mode}/{scope}", flush=True)


if __name__ == "__main__":
    main()
