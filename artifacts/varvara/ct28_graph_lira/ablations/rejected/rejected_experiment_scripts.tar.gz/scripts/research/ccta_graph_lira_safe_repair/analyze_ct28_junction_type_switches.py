#!/usr/bin/env python3
"""Summarize validation JUNCTION/BOTH relation switches from saved repeats."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

import run_ct28_graph_lira as graph


DEFAULT_INPUT = (graph.DEFAULT_SCENE_DIR /
                 "ablations/junction_identity_diagnostics/position_robust/decision_traces_val.csv.gz")


def transitions(rows: pd.DataFrame) -> pd.DataFrame:
    rows = rows[
        rows.intervention.eq("dynamic")
        & rows["mode"].isin(("joint", "position_only", "tangent_only"))
        & rows.scene_family.isin(("junction_only", "mixed"))
    ].copy()
    expected = rows.scene_family.map({"junction_only": "JUNCTION", "mixed": "BOTH"})
    rows = rows[rows.base_tau_relation.eq(expected)].copy()
    rows["expected_type"] = rows.scene_family.map(
        {"junction_only": "JUNCTION", "mixed": "BOTH"}
    )
    if set(rows.scan_id) != graph.EXPECTED_VALIDATION_PATIENTS:
        raise ValueError("unexpected validation patient IDs")
    if rows.groupby(["scene_id", "mode"]).size().ne(15).any():
        raise ValueError("incomplete perturbation series")
    counts = rows.groupby(
        ["mode", "scene_family", "expected_type", "tau_relation"],
        dropna=False,
    ).agg(repeats=("scene_id", "size"), patients=("scan_id", "nunique"))
    return counts.reset_index()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trace", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_INPUT.parent)
    args = parser.parse_args()
    rows = pd.read_csv(args.trace)
    table = transitions(rows)
    args.out_dir.mkdir(parents=True, exist_ok=True)
    table.to_csv(args.out_dir / "type_switches_val.csv", index=False)
    diagnostic = rows[
        rows.intervention.eq("dynamic")
        & rows["mode"].isin(("joint", "position_only", "tangent_only"))
        & rows.scene_family.isin(("junction_only", "mixed"))
    ].copy()
    expected = diagnostic.scene_family.map({"junction_only": "JUNCTION", "mixed": "BOTH"})
    diagnostic = diagnostic[diagnostic.base_tau_relation.eq(expected)].copy()
    diagnostic["type_correct"] = diagnostic.tau_relation.eq(
        diagnostic.scene_family.map({"junction_only": "JUNCTION", "mixed": "BOTH"})
    )
    summary = []
    for (mode, family), part in diagnostic.groupby(["mode", "scene_family"]):
        correct_type = part[part.type_correct]
        summary.append({
            "mode": mode, "scene_family": family,
            "initially_correct_scenes": int(part.scene_id.nunique()),
            "repeats": int(len(part)),
            "type_correct_repeats": int(part.type_correct.sum()),
            "type_correct_rate": float(part.type_correct.mean()),
            "junction_top1_given_correct_type": float(
                correct_type.true_top1_geometry_plus_ct_score.mean()
            ),
        })
    (args.out_dir / "type_switch_summary.json").write_text(
        json.dumps({"held_out_test_accessed": False,
                    "source_sha256": graph.sha256(args.trace),
                    "metrics": summary}, indent=2) + "\n"
    )
    print(table.to_string(index=False))


if __name__ == "__main__":
    main()
