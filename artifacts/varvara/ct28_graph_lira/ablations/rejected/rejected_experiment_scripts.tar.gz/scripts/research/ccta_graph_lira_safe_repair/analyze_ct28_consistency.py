#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd


REPO_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_ROOT = REPO_ROOT / "artifacts/varvara/ct28_graph_lira"
DEFAULT_OUT = DEFAULT_ROOT / "consistency_diagnostics"
EXPECTED_VALIDATION_PATIENTS = {957, 961, 965, 966, 974}
HELD_OUT_TEST_PATIENTS = {954, 958, 972, 973, 980, 984}
CONSISTENCY_COLUMNS = (
    "raw_type_consistency",
    "tau_type_consistency",
    "selected_type_consistency",
    "pair_identity_consistency",
    "pair_identity_given_pair_present",
    "junction_identity_consistency",
    "junction_identity_given_junction_present",
    "exact_identity_agreement",
    "exact_identity_given_selected_type",
    "combined_consistency",
    "confidence_gate_fraction",
    "both_compatibility_rate",
    "compatibility_state_consistency",
)


class ConsistencyDiagnosticError(RuntimeError):
    pass


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Decompose CT28 perturbation consistency on validation."
    )
    parser.add_argument(
        "--logistic-dir", type=Path, default=DEFAULT_OUT / "clean_logistic"
    )
    parser.add_argument("--hgb-dir", type=Path, default=DEFAULT_OUT / "clean_hgb")
    parser.add_argument(
        "--single-dir",
        type=Path,
        help="Analyze one saved Graph-LIRA run instead of the default pair.",
    )
    parser.add_argument(
        "--single-label",
        default="single_run",
        help="Label used in outputs with --single-dir.",
    )
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    return parser.parse_args()


def clean_id(value: object) -> str:
    return "" if pd.isna(value) else str(value)


def relation_key(pair_id: str, junction_id: str) -> str:
    if pair_id and junction_id:
        return f"BOTH|{pair_id}|{junction_id}"
    if pair_id:
        return f"PAIR|{pair_id}"
    if junction_id:
        return f"JUNCTION|{junction_id}"
    return "NONE"


def agreement(values: pd.Series, target: object) -> float:
    return float(values.eq(target).mean())


def gate_component(values: pd.Series, target: object) -> tuple[float, bool, float]:
    normalized = values.fillna("").astype(str)
    target_value = "" if pd.isna(target) else str(target)
    counts = Counter(normalized.tolist())
    mode_value, _ = counts.most_common(1)[0]
    fraction = float(counts.get(target_value, 0) / len(normalized))
    is_mode = mode_value == target_value
    return fraction, is_mode, fraction if is_mode else 0.0


def optional_identity_agreement(values: pd.Series, target: str) -> float:
    if not target:
        return float("nan")
    return agreement(values.fillna(""), target)


def decompose_run(run_dir: Path, local_family: str) -> pd.DataFrame:
    predictions = pd.read_csv(run_dir / "graph_lira_predictions_val.csv")
    details = pd.read_csv(run_dir / "perturbation_decisions_val.csv")
    predictions = predictions[predictions["model"].eq("ct_conditioned")].copy()
    details = details[details["model"].eq("ct_conditioned")].copy()
    patients = set(predictions["scan_id"].astype(int))
    if patients != EXPECTED_VALIDATION_PATIENTS:
        raise ConsistencyDiagnosticError(
            f"{local_family}: validation patient set changed: {sorted(patients)}"
        )
    if patients & HELD_OUT_TEST_PATIENTS:
        raise ConsistencyDiagnosticError(f"{local_family}: held-out test accessed")
    counts = details.groupby("scene_id")["repetition"].nunique()
    if len(predictions) != 368 or len(counts) != 368 or not counts.eq(15).all():
        raise ConsistencyDiagnosticError(
            f"{local_family}: expected 368 scenes and 15 repeats per scene"
        )

    rows: list[dict[str, object]] = []
    for base in predictions.itertuples(index=False):
        repeats = details[details["scene_id"].eq(base.scene_id)].sort_values(
            "repetition"
        )
        pair_id = clean_id(base.proposed_pair_candidate_id)
        junction_id = clean_id(base.proposed_junction_candidate_id)
        base_key = relation_key(pair_id, junction_id)
        keys = repeats["relation_key"].astype(str).tolist()
        key_counts = Counter(keys)
        mode_key, mode_count = key_counts.most_common(1)[0]
        exact_agreement = float(key_counts.get(base_key, 0) / len(keys))
        combined = exact_agreement if mode_key == base_key else 0.0
        if not np.isclose(combined, float(base.combined_consistency), atol=1e-12):
            raise ConsistencyDiagnosticError(
                f"{local_family}: consistency mismatch for {base.scene_id}"
            )
        repeat_both = repeats["tau_relation"].eq("BOTH")
        both_compatibility = (
            float(repeats.loc[repeat_both, "compatibility_satisfied"].mean())
            if repeat_both.any()
            else float("nan")
        )
        base_compatibility = not (
            base.tau_relation == "BOTH"
            and base.selected_relation_before_consistency != "BOTH"
        )
        confidences = repeats["confidence"].astype(float)
        repeat_pair_ids = repeats["pair_candidate_id"].fillna("").astype(str)
        repeat_junction_ids = (
            repeats["junction_candidate_id"].fillna("").astype(str)
        )
        pair_present = repeat_pair_ids.ne("")
        junction_present = repeat_junction_ids.ne("")
        selected_type_matches = repeats["selected_relation"].eq(
            base.selected_relation_before_consistency
        )
        raw_fraction, raw_is_mode, raw_gate_value = gate_component(
            repeats["raw_relation"], base.raw_relation
        )
        tau_fraction, tau_is_mode, tau_gate_value = gate_component(
            repeats["tau_relation"], base.tau_relation
        )
        selected_fraction, selected_is_mode, selected_gate_value = gate_component(
            repeats["selected_relation"], base.selected_relation_before_consistency
        )
        pair_fraction, pair_is_mode, pair_gate_value = (
            gate_component(repeat_pair_ids, pair_id)
            if pair_id
            else (float("nan"), False, float("nan"))
        )
        junction_fraction, junction_is_mode, junction_gate_value = (
            gate_component(repeat_junction_ids, junction_id)
            if junction_id
            else (float("nan"), False, float("nan"))
        )
        rows.append(
            {
                "local_family": local_family,
                "scene_id": base.scene_id,
                "scan_id": int(base.scan_id),
                "scene_family": base.scene_family,
                "relation_class": base.relation_class,
                "junction_benchmark_group": clean_id(
                    base.junction_benchmark_group
                ),
                "geometry_ambiguous": int(base.geometry_ambiguous),
                "base_raw_relation": base.raw_relation,
                "base_tau_relation": base.tau_relation,
                "base_selected_relation": base.selected_relation_before_consistency,
                "base_pair_candidate_id": pair_id,
                "base_junction_candidate_id": junction_id,
                "base_relation_key": base_key,
                "base_confidence": float(base.confidence),
                "base_compatibility_satisfied": int(base_compatibility),
                "proposed_before_consistency": int(
                    base.selected_relation_before_consistency != "NONE"
                ),
                "accepted": int(base.accepted),
                "pre_consistency_exact": int(base.pre_consistency_exact),
                "pre_consistency_false": int(base.pre_consistency_false),
                "pre_consistency_incomplete": int(base.pre_consistency_incomplete),
                "raw_type_consistency": raw_fraction,
                "raw_type_is_mode": int(raw_is_mode),
                "raw_type_gate_value": raw_gate_value,
                "tau_type_consistency": tau_fraction,
                "tau_type_is_mode": int(tau_is_mode),
                "tau_type_gate_value": tau_gate_value,
                "selected_type_consistency": selected_fraction,
                "selected_type_is_mode": int(selected_is_mode),
                "selected_type_gate_value": selected_gate_value,
                "pair_identity_consistency": pair_fraction,
                "pair_identity_is_mode": int(pair_is_mode) if pair_id else np.nan,
                "pair_identity_gate_value": pair_gate_value,
                "pair_presence_rate": (
                    float(pair_present.mean()) if pair_id else float("nan")
                ),
                "pair_identity_given_pair_present": (
                    agreement(repeat_pair_ids[pair_present], pair_id)
                    if pair_id and pair_present.any()
                    else float("nan")
                ),
                "junction_identity_consistency": junction_fraction,
                "junction_identity_is_mode": (
                    int(junction_is_mode) if junction_id else np.nan
                ),
                "junction_identity_gate_value": junction_gate_value,
                "junction_presence_rate": (
                    float(junction_present.mean())
                    if junction_id
                    else float("nan")
                ),
                "junction_identity_given_junction_present": (
                    agreement(
                        repeat_junction_ids[junction_present], junction_id
                    )
                    if junction_id and junction_present.any()
                    else float("nan")
                ),
                "exact_identity_agreement": exact_agreement,
                "exact_identity_given_selected_type": (
                    agreement(
                        repeats.loc[selected_type_matches, "relation_key"], base_key
                    )
                    if selected_type_matches.any()
                    else float("nan")
                ),
                "exact_identity_is_mode": int(mode_key == base_key),
                "perturbation_mode_key": mode_key,
                "perturbation_mode_fraction": float(mode_count / len(keys)),
                "combined_consistency": combined,
                "consistency_gate": float(base.combined_consistency >= 0.60),
                "confidence_mean": float(confidences.mean()),
                "confidence_std": float(confidences.std(ddof=0)),
                "confidence_min": float(confidences.min()),
                "confidence_q10": float(confidences.quantile(0.10)),
                "confidence_median": float(confidences.median()),
                "confidence_q90": float(confidences.quantile(0.90)),
                "confidence_max": float(confidences.max()),
                "confidence_gate_fraction": float(confidences.ge(0.85).mean()),
                "repeat_both_count": int(repeat_both.sum()),
                "both_compatibility_rate": both_compatibility,
                "compatibility_state_consistency": agreement(
                    repeats["compatibility_satisfied"].astype(bool),
                    base_compatibility,
                ),
            }
        )
    return pd.DataFrame(rows)


def abstention_reason(row: pd.Series) -> str:
    if int(row["accepted"]):
        return "accepted"
    if row["relation_class"] == "NONE" and not int(
        row["proposed_before_consistency"]
    ):
        return "correct_none"
    if not int(row["proposed_before_consistency"]):
        if row["base_raw_relation"] != "NONE" and row["base_confidence"] < 0.85:
            return "confidence_below_tau"
        return "no_repair_proposed"
    if not int(row["base_compatibility_satisfied"]):
        return "compatibility_failure"
    if row["selected_type_gate_value"] < 0.60:
        return "relation_type_unstable"
    selected = row["base_selected_relation"]
    pair_unstable = (
        selected in {"PAIR", "BOTH"} and row["pair_identity_gate_value"] < 0.60
    )
    junction_unstable = (
        selected in {"JUNCTION", "BOTH"}
        and row["junction_identity_gate_value"] < 0.60
    )
    if selected == "PAIR" and pair_unstable:
        return "pair_identity_unstable"
    if selected == "JUNCTION" and junction_unstable:
        return "junction_identity_unstable"
    if selected == "BOTH":
        if pair_unstable and not junction_unstable:
            return "pair_identity_unstable"
        if junction_unstable and not pair_unstable:
            return "junction_identity_unstable"
        if pair_unstable or junction_unstable:
            return "both_combination_unstable"
        if row["combined_consistency"] < 0.60:
            return "both_combination_unstable"
    if row["combined_consistency"] < 0.60:
        return "exact_identity_mode_failure"
    raise ConsistencyDiagnosticError(
        f"unclassified abstention: {row['local_family']} {row['scene_id']}"
    )


def accepted_outcome(row: pd.Series) -> str:
    if not int(row["accepted"]):
        return "not_accepted"
    if int(row["pre_consistency_exact"]):
        return "accepted_exact"
    if int(row["pre_consistency_false"]):
        return "accepted_false"
    return "accepted_incomplete"


def reason_summary(frame: pd.DataFrame, group_columns: list[str]) -> pd.DataFrame:
    counts = (
        frame.groupby(group_columns + ["primary_reason"], dropna=False, sort=False)
        .size()
        .rename("scenes")
        .reset_index()
    )
    totals = counts.groupby(group_columns)["scenes"].transform("sum")
    counts["fraction"] = counts["scenes"] / totals
    return counts


def summarize_group(frame: pd.DataFrame, group: str) -> dict[str, object]:
    output: dict[str, object] = {
        "group": group,
        "scenes": len(frame),
        "proposed_scenes": int(frame["proposed_before_consistency"].sum()),
        "accepted_scenes": int(frame["accepted"].sum()),
        "consistency_gate_scenes": int(frame["consistency_gate"].sum()),
        "exact_identity_mode_scenes": int(frame["exact_identity_is_mode"].sum()),
    }
    for column in CONSISTENCY_COLUMNS:
        finite = frame[column].dropna().astype(float)
        output[f"{column}_mean"] = float(finite.mean()) if len(finite) else np.nan
        output[f"{column}_median"] = (
            float(finite.median()) if len(finite) else np.nan
        )
        output[f"{column}_q10"] = (
            float(finite.quantile(0.10)) if len(finite) else np.nan
        )
    output["base_confidence_mean"] = float(frame["base_confidence"].mean())
    output["perturbed_confidence_mean"] = float(frame["confidence_mean"].mean())
    return output


def summary_rows(frame: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for local_family, family_rows in frame.groupby("local_family", sort=False):
        scopes = {
            "all": family_rows,
            "proposed": family_rows[
                family_rows["proposed_before_consistency"].astype(bool)
            ],
        }
        scopes.update(
            {
                f"base_selected_{relation}": relation_rows
                for relation, relation_rows in family_rows.groupby(
                    "base_selected_relation", sort=False
                )
            }
        )
        for scope, scope_rows in scopes.items():
            rows.append(
                {
                    "local_family": local_family,
                    "scope": scope,
                    **summarize_group(scope_rows, scope),
                }
            )
    return pd.DataFrame(rows)


def grouped_rows(frame: pd.DataFrame, column: str) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for (local_family, value), group in frame.groupby(
        ["local_family", column], sort=False
    ):
        rows.append(
            {
                "local_family": local_family,
                column: value,
                **summarize_group(group, str(value)),
            }
        )
    return pd.DataFrame(rows)


def type_transition_rows(run_dir: Path, local_family: str) -> pd.DataFrame:
    base = pd.read_csv(run_dir / "graph_lira_predictions_val.csv")
    repeats = pd.read_csv(run_dir / "perturbation_decisions_val.csv")
    base = base[base["model"].eq("ct_conditioned")][
        [
            "scene_id",
            "raw_relation",
            "tau_relation",
            "selected_relation_before_consistency",
        ]
    ].rename(
        columns={
            "raw_relation": "base_raw_relation",
            "tau_relation": "base_tau_relation",
            "selected_relation_before_consistency": "base_selected_relation",
        }
    )
    repeats = repeats[repeats["model"].eq("ct_conditioned")].merge(
        base, on="scene_id", validate="many_to_one"
    )
    stages = {
        "raw": ("base_raw_relation", "raw_relation"),
        "tau": ("base_tau_relation", "tau_relation"),
        "selected": ("base_selected_relation", "selected_relation"),
    }
    rows: list[dict[str, object]] = []
    for stage, (base_column, repeat_column) in stages.items():
        counts = (
            repeats.groupby([base_column, repeat_column], sort=False)
            .size()
            .rename("count")
            .reset_index()
        )
        totals = counts.groupby(base_column)["count"].transform("sum")
        for row, total in zip(counts.itertuples(index=False), totals):
            rows.append(
                {
                    "local_family": local_family,
                    "stage": stage,
                    "base_relation": getattr(row, base_column),
                    "perturbed_relation": getattr(row, repeat_column),
                    "count": int(row.count),
                    "fraction_within_base_relation": float(row.count / total),
                }
            )
    return pd.DataFrame(rows)


def json_ready(value: object) -> object:
    if isinstance(value, dict):
        return {key: json_ready(item) for key, item in value.items()}
    if isinstance(value, list):
        return [json_ready(item) for item in value]
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value


def main() -> None:
    args = parse_args()
    runs = (
        [(args.single_label, args.single_dir)]
        if args.single_dir is not None
        else [("logistic", args.logistic_dir), ("hgb", args.hgb_dir)]
    )
    components = pd.concat(
        [decompose_run(run_dir, label) for label, run_dir in runs],
        ignore_index=True,
    )
    components["primary_reason"] = components.apply(abstention_reason, axis=1)
    components["accepted_outcome"] = components.apply(accepted_outcome, axis=1)
    summary = summary_rows(components)
    by_scene = grouped_rows(components, "scene_family")
    by_true_relation = grouped_rows(components, "relation_class")
    transitions = pd.concat(
        [type_transition_rows(run_dir, label) for label, run_dir in runs],
        ignore_index=True,
    )
    reason_overall = reason_summary(components, ["local_family"])
    reason_by_scene = reason_summary(
        components, ["local_family", "scene_family"]
    )
    reason_by_patient = reason_summary(components, ["local_family", "scan_id"])
    junction_components = components[
        components["junction_benchmark_group"].ne("")
    ].copy()
    reason_by_junction_group = reason_summary(
        junction_components, ["local_family", "junction_benchmark_group"]
    )
    args.out_dir.mkdir(parents=True, exist_ok=True)
    components.to_csv(args.out_dir / "consistency_components_val.csv", index=False)
    summary.to_csv(args.out_dir / "consistency_summary_val.csv", index=False)
    by_scene.to_csv(args.out_dir / "consistency_by_scene_type_val.csv", index=False)
    by_true_relation.to_csv(
        args.out_dir / "consistency_by_true_relation_val.csv", index=False
    )
    transitions.to_csv(
        args.out_dir / "consistency_type_transitions_val.csv", index=False
    )
    reason_columns = [
        "local_family",
        "scene_id",
        "scan_id",
        "scene_family",
        "relation_class",
        "junction_benchmark_group",
        "geometry_ambiguous",
        "base_raw_relation",
        "base_tau_relation",
        "base_selected_relation",
        "base_pair_candidate_id",
        "base_junction_candidate_id",
        "base_confidence",
        "base_compatibility_satisfied",
        "proposed_before_consistency",
        "raw_type_gate_value",
        "selected_type_gate_value",
        "pair_identity_gate_value",
        "junction_identity_gate_value",
        "exact_identity_agreement",
        "exact_identity_is_mode",
        "perturbation_mode_key",
        "combined_consistency",
        "accepted",
        "accepted_outcome",
        "primary_reason",
    ]
    components[reason_columns].to_csv(
        args.out_dir / "abstention_reasons_val.csv", index=False
    )
    reason_overall.to_csv(
        args.out_dir / "abstention_reason_summary_val.csv", index=False
    )
    reason_by_scene.to_csv(
        args.out_dir / "abstention_reasons_by_scene_type_val.csv", index=False
    )
    reason_by_patient.to_csv(
        args.out_dir / "abstention_reasons_per_patient_val.csv", index=False
    )
    reason_by_junction_group.to_csv(
        args.out_dir / "abstention_reasons_by_junction_group_val.csv", index=False
    )
    payload = {
        "status": "development_train_val_only",
        "held_out_test_accessed": False,
        "models": {label: str(run_dir) for label, run_dir in runs},
        "tau": 0.85,
        "consistency_gate": 0.60,
        "perturbations": {
            "repetitions": 15,
            "position_noise_mm": 0.8,
            "tangent_noise_deg": 20.0,
        },
        "definitions": {
            "raw_type_consistency": "fraction of repeats matching the base argmax relation type before tau",
            "tau_type_consistency": "fraction matching the base relation after tau=0.85",
            "selected_type_consistency": "fraction matching the base relation after compatibility selection",
            "pair_identity_consistency": "fraction retaining the base PAIR candidate ID when the base decision contains PAIR",
            "pair_identity_given_pair_present": "fraction retaining the base PAIR ID among repeats that still select a PAIR",
            "junction_identity_consistency": "fraction retaining the base JUNCTION candidate ID when the base decision contains JUNCTION",
            "junction_identity_given_junction_present": "fraction retaining the base JUNCTION ID among repeats that still select a JUNCTION",
            "exact_identity_agreement": "fraction matching the complete base relation key and candidate IDs",
            "exact_identity_given_selected_type": "exact candidate-set agreement among repeats that preserve the base selected relation type",
            "combined_consistency": "exact agreement if the base key is also the perturbation mode, otherwise zero",
        },
        "abstention_reason_definitions": {
            "accepted": "a non-NONE repair passed exact candidate-set consistency >= 0.60",
            "correct_none": "the base decision selected NONE for a true NONE scene",
            "confidence_below_tau": "the raw relation was non-NONE but base confidence was below tau=0.85",
            "no_repair_proposed": "the raw base relation was NONE in a repair-needed scene",
            "compatibility_failure": "a raw BOTH decision could not retain a compatible PAIR+JUNCTION combination",
            "relation_type_unstable": "the base selected relation type was not the perturbation mode or appeared in <60% of repeats",
            "pair_identity_unstable": "PAIR type was stable enough but its base candidate ID was not",
            "junction_identity_unstable": "JUNCTION type was stable enough but its base candidate ID was not",
            "both_combination_unstable": "PAIR and JUNCTION components were individually plausible but the exact joint BOTH identity was not stable",
            "exact_identity_mode_failure": "the exact base identity failed the final mode/0.60 rule after earlier diagnostics passed",
        },
        "summary": json_ready(summary.to_dict(orient="records")),
        "abstention_reason_priority": [
            "accepted",
            "correct_none",
            "confidence_below_tau",
            "no_repair_proposed",
            "compatibility_failure",
            "relation_type_unstable",
            "pair_identity_unstable",
            "junction_identity_unstable",
            "both_combination_unstable",
            "exact_identity_mode_failure",
        ],
        "abstention_reason_summary": json_ready(
            reason_overall.to_dict(orient="records")
        ),
    }
    (args.out_dir / "consistency_diagnostics.json").write_text(
        json.dumps(payload, indent=2, allow_nan=False) + "\n"
    )
    print(summary.to_string(index=False), flush=True)


if __name__ == "__main__":
    main()
