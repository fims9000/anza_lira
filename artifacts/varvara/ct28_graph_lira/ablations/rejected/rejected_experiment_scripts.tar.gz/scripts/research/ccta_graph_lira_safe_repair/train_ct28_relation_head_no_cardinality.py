#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import joblib
import pandas as pd

import build_ct28_relation_features as relation_features
import train_ct28_relation_head as training


REPO_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_SCENE_DIR = (
    REPO_ROOT / "artifacts/varvara/ct28_graph_lira/ablations/stress30_jitter1"
)
DEFAULT_EVIDENCE_DIR = DEFAULT_SCENE_DIR / "local_hgb"
DEFAULT_OUT_DIR = DEFAULT_EVIDENCE_DIR / "no_cardinality"
COUNT_SUFFIXES = (
    "_pair_candidate_count",
    "_junction_candidate_count",
    "_pair_count_repeat",
    "_junction_count_repeat",
)


class NoCardinalityError(RuntimeError):
    pass


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Retrain the frozen Stress30 relation heads without direct candidate "
            "cardinality features; local HGB scores and models remain unchanged."
        )
    )
    parser.add_argument("--scene-dir", type=Path, default=DEFAULT_SCENE_DIR)
    parser.add_argument("--evidence-dir", type=Path, default=DEFAULT_EVIDENCE_DIR)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT_DIR)
    parser.add_argument("--tau", type=float, default=0.85)
    return parser.parse_args()


def without_cardinality(columns: list[str]) -> tuple[list[str], list[str]]:
    removed = [
        column for column in columns if any(column.endswith(suffix) for suffix in COUNT_SUFFIXES)
    ]
    retained = [column for column in columns if column not in set(removed)]
    return retained, removed


def main() -> None:
    args = parse_args()
    if args.tau != 0.85:
        raise NoCardinalityError("frozen relation tau must remain 0.85")
    scene_plan_path = args.scene_dir / "scene_plan_train_val.csv"
    scene_candidates_path = args.scene_dir / "scene_candidates_train_val.csv"
    scene_features_path = args.scene_dir / "scene_candidate_features_train_val.csv"
    local_scores_path = args.evidence_dir / "relation_local_scores_train_val.csv"
    source_models_path = args.evidence_dir / "relation_models.joblib"
    source_protocol_path = args.evidence_dir / "relation_model_protocol.json"
    required = (
        scene_plan_path,
        scene_candidates_path,
        scene_features_path,
        local_scores_path,
        source_models_path,
        source_protocol_path,
    )
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise NoCardinalityError(f"missing frozen inputs: {missing}")

    plans = pd.read_csv(scene_plan_path)
    candidates = pd.read_csv(scene_candidates_path)
    training.validate_scene_inputs(plans, candidates)
    if set(plans["split"]) != {"train", "val"}:
        raise NoCardinalityError("held-out data must not enter this ablation")

    score_rows_frame = pd.read_csv(local_scores_path)
    training.validate_scene_inputs(plans, score_rows_frame)
    source_models = joblib.load(source_models_path)
    if source_models.get("local_model_family") != "hgb":
        raise NoCardinalityError("this ablation requires the frozen local HGB baseline")

    plan_rows = relation_features.read_csv(scene_plan_path)
    candidate_rows = relation_features.read_csv(scene_candidates_path)
    score_rows = relation_features.read_csv(local_scores_path)
    specifications = {
        "geometry_only": (["geometry_score"], 42, 38),
        "geometry_plus_ct": (["geometry_plus_ct_score"], 42, 38),
        "ct_conditioned": (["geometry_score", "ct_score"], 84, 76),
    }
    relation_heads = {}
    feature_lists = {}
    metrics = {}
    predictions = []
    removed_by_model = {}
    for model_name, (score_columns, original_count, expected_count) in specifications.items():
        rows, all_columns = training.build_relation_feature_rows(
            plan_rows, candidate_rows, score_rows, score_columns
        )
        if len(all_columns) != original_count:
            raise NoCardinalityError(
                f"unexpected {model_name} source feature count: {len(all_columns)}"
            )
        columns, removed = without_cardinality(all_columns)
        if len(columns) != expected_count or len(removed) != original_count - expected_count:
            raise NoCardinalityError(
                f"unexpected {model_name} no-cardinality feature split"
            )
        result, model_predictions, head = training.fit_relation_head(
            rows, columns, args.tau, model_name
        )
        relation_heads[model_name] = head
        feature_lists[model_name] = columns
        metrics[model_name] = {
            "representation": "historical_score_landscape_without_direct_cardinality",
            "feature_count": len(columns),
            **result,
        }
        predictions.extend(model_predictions)
        removed_by_model[model_name] = removed

    expected_removed = {
        "geometry_only": 4,
        "geometry_plus_ct": 4,
        "ct_conditioned": 8,
    }
    if {key: len(value) for key, value in removed_by_model.items()} != expected_removed:
        raise NoCardinalityError("direct cardinality columns were not removed exactly")

    args.out_dir.mkdir(parents=True, exist_ok=True)
    output_scores_path = args.out_dir / "relation_local_scores_train_val.csv"
    shutil.copyfile(local_scores_path, output_scores_path)
    predictions_path = args.out_dir / "relation_predictions_val.csv"
    pd.DataFrame(predictions).to_csv(predictions_path, index=False)
    metrics_path = args.out_dir / "relation_metrics_val.json"
    metrics_payload = {
        "status": "development_train_val_only",
        "held_out_test_accessed": False,
        "ablation": "remove_direct_candidate_cardinality_only",
        "validation_scenes": int((plans["split"] == "val").sum()),
        "tau": args.tau,
        "models": metrics,
    }
    metrics_path.write_text(json.dumps(metrics_payload, indent=2) + "\n")

    models_path = args.out_dir / "relation_models.joblib"
    joblib.dump(
        {
            "local_models": source_models["local_models"],
            "relation_heads": relation_heads,
            "local_model_family": "hgb",
            "local_model_params": source_models["local_model_params"],
            "relation_model_params": training.RELATION_MODEL_PARAMS,
            "relation_classes": training.RELATION_CLASSES,
            "geometry_relation_features": feature_lists["geometry_only"],
            "geometry_plus_ct_relation_features": feature_lists["geometry_plus_ct"],
            "ct_conditioned_relation_features": feature_lists["ct_conditioned"],
        },
        models_path,
    )

    source_protocol = json.loads(source_protocol_path.read_text())
    protocol_path = args.out_dir / "relation_model_protocol.json"
    outputs = (output_scores_path, predictions_path, metrics_path, models_path)
    protocol = {
        "protocol_version": "ct28_stress30_local_hgb_no_cardinality_ablation_v1",
        "held_out_test_accessed": False,
        "purpose": (
            "Measure the scene-generator cardinality shortcut while holding local "
            "scores, scene inputs, relation model family and downstream policy fixed."
        ),
        "source_files": source_protocol["source_files"],
        "source_sha256": source_protocol["source_sha256"],
        "local_evidence": {
            "reused_without_refit": True,
            "source": training.provenance_path(local_scores_path),
            "source_sha256": training.sha256(local_scores_path),
            "model_family": "hgb",
        },
        "relation_model": {
            "model": "HistGradientBoostingClassifier",
            "params": training.RELATION_MODEL_PARAMS,
            "class_order": list(training.RELATION_CLASSES),
            "tau": args.tau,
        },
        "relation_features": {
            model_name: {
                "feature_count": len(feature_lists[model_name]),
                "model_feature_columns": feature_lists[model_name],
                "removed_direct_cardinality_columns": removed_by_model[model_name],
            }
            for model_name in specifications
        },
        "preserved_non_cardinality_aggregates": (
            "top scores, score gaps, sum, mean, standard deviation, quantiles, "
            "minimum and top-over-sum"
        ),
        "outputs_sha256": {path.name: training.sha256(path) for path in outputs},
    }
    protocol_path.write_text(json.dumps(protocol, indent=2) + "\n")
    print(json.dumps(metrics_payload, indent=2))


if __name__ == "__main__":
    main()
