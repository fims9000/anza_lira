#!/usr/bin/env python3
"""One fixed randomized-feature relation ensemble on selected CT28 K10/15 inputs."""
from pathlib import Path
import json

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import log_loss

import evaluate_ct28_recovery as recovery
import run_ct28_graph_lira as graph
import train_ct28_relation_head as training

OUT = graph.REPO_ROOT / 'varvara/anza_lira_local_results/ct28_confidence_ensemble_v1'
SEEDS = (0, 1, 2, 3, 4)
MAX_FEATURES = 0.8


def validate_probabilities(probabilities):
    if not np.isfinite(probabilities).all() or (probabilities < 0).any():
        raise ValueError('invalid relation probabilities')
    if not np.allclose(probabilities.sum(axis=1), 1.0, atol=1e-12, rtol=0):
        raise ValueError('relation probabilities do not sum to one')


def confidence_diagnostics(name, clean, noisy, clean_probability, noisy_probability, baseline):
    clean_lookup = dict(zip(clean.scene_id, clean_probability))
    baseline = baseline.set_index('scene_id')
    records = []
    for row, probability in zip(noisy.itertuples(index=False), noisy_probability):
        truth = graph.RELATION_CLASSES.index(row.relation_class)
        base = clean_lookup[row.scene_id]
        raw = int(np.argmax(probability))
        base_raw = int(np.argmax(base))
        records.append(dict(
            variant=name, scene_id=row.scene_id, scan_id=int(row.scan_id),
            scene_family=row.scene_family, repetition=int(row.repetition),
            base_raw_correct=base_raw == truth,
            base_tau_correct=base_raw == truth and float(base.max()) >= .85,
            raw_correct=raw == truth, tau_correct=raw == truth and probability.max() >= .85,
            confidence_below_tau_same_correct_raw=raw == truth and probability.max() < .85,
            baseline_blocked_exact=bool(baseline.loc[row.scene_id,'pre_consistency_exact']
                                        and not baseline.loc[row.scene_id,'accepted']
                                        and row.relation_class != 'NONE'),
            true_probability=float(probability[truth]), confidence=float(probability.max()),
            clean_true_probability=float(base[truth]),
            **{f'p_{label.lower()}':float(probability[index])
               for index,label in enumerate(graph.RELATION_CLASSES)}))
    return pd.DataFrame(records)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    plans_path = graph.DEFAULT_SCENE_DIR / 'scene_plan_train_val.csv'
    candidates_path = graph.DEFAULT_SCENE_DIR / 'scene_candidates_train_val.csv'
    scores_path = recovery.SELECTED / 'relation_local_scores_train_val.csv'
    models_path = recovery.SELECTED / 'relation_models.joblib'
    copies_path = recovery.RUNS / 'relation/joint_train_relation_copies.csv'
    noisy_feature_path = recovery.TRACE / 'relation_features_val.csv.gz'
    noisy_score_path = recovery.TRACE / 'local_scores_val.csv.gz'
    baseline_path = recovery.SELECTED / 'clean_eval/graph_lira_predictions_val.csv'
    plans = pd.read_csv(plans_path)
    candidates = pd.read_csv(candidates_path)
    training.validate_scene_inputs(plans, candidates)
    scores = pd.read_csv(scores_path)
    pack = joblib.load(models_path)
    baseline = pd.read_csv(baseline_path).query("model == 'ct_conditioned'").copy()
    rows, columns = graph.relation_feature_rows(plans, candidates, scores, ['geometry_score','ct_score'])
    if columns != pack['ct_conditioned_relation_features']:
        raise ValueError('feature order differs from selected model')
    clean = pd.DataFrame(rows)
    train = clean[clean.split.eq('train')].copy()
    val = clean[clean.split.eq('val')].copy()
    copies = pd.read_csv(copies_path, float_precision='round_trip')
    if set(copies.scan_id.astype(int)) != training.EXPECTED_PATIENT_IDS['train'] or set(copies.split) != {'train'}:
        raise ValueError('train-only augmentation cohort changed')
    if len(train) != 1036 or not copies.groupby('scene_id').size().eq(15).all():
        raise ValueError('train scene/copy coverage changed')
    train['weight'] = .5
    copies['weight'] = .5 / 15
    fit = pd.concat([train, copies], ignore_index=True)
    if not fit.groupby('scene_id').relation_class.nunique().eq(1).all():
        raise ValueError('augmentation changed scene ground-truth class')
    if not fit.groupby('scene_id').weight.sum().sub(1).abs().le(1e-12).all():
        raise ValueError('scene augmentation weights changed')
    x = fit[columns].to_numpy()
    y = fit.relation_class.map({label:index for index,label in enumerate(graph.RELATION_CLASSES)}).to_numpy()
    weights = fit.weight.to_numpy()
    xv = val[columns].to_numpy()
    replay = training.relation_model().fit(x,y,sample_weight=weights)
    head = pack['relation_heads']['ct_conditioned']
    replay_error = float(np.max(np.abs(replay.predict_proba(xv)-head.predict_proba(xv))))
    if replay_error > 1e-10:
        raise ValueError(f'baseline training replay failed: {replay_error}')
    print(f'baseline probability replay error {replay_error:.3g}',flush=True)
    models = []
    for seed in SEEDS:
        model = training.relation_model().set_params(max_features=MAX_FEATURES,random_state=seed)
        model.fit(x,y,sample_weight=weights)
        models.append(model)
        print(f'ensemble member seed={seed} fitted',flush=True)
    joblib.dump(dict(models=models,features=columns,seeds=SEEDS,max_features=MAX_FEATURES),OUT/'relation_ensemble.joblib')
    noisy = pd.read_csv(noisy_feature_path)
    noisy = noisy[noisy['mode'].eq('joint')].copy()
    noisy_scores = pd.read_csv(noisy_score_path)
    noisy_scores = noisy_scores[noisy_scores['mode'].eq('joint')].copy()
    if len(noisy)!=5520 or set(noisy.scan_id.astype(int))!=graph.EXPECTED_VALIDATION_PATIENTS:
        raise ValueError('validation repeat cohort changed')
    xn = noisy[columns].to_numpy()
    members_clean = np.stack([model.predict_proba(xv) for model in models])
    members_noisy = np.stack([model.predict_proba(xn) for model in models])
    variants = {
        'K10_15':(head.predict_proba(xv),head.predict_proba(xn)),
        'feature_ensemble_5':(members_clean.mean(axis=0),members_noisy.mean(axis=0))}
    if float(members_clean.std(axis=0).max()) < 1e-10:
        raise ValueError('ensemble members lack actual prediction diversity')
    all_scenes, all_repeats, all_confidence = [], [], []
    metrics = {}
    truth = val.relation_class.map({label:index for index,label in enumerate(graph.RELATION_CLASSES)}).to_numpy()
    for name,(probability,perturbed) in variants.items():
        validate_probabilities(probability);validate_probabilities(perturbed)
        base_prob = dict(zip(val.scene_id, probability))
        noisy_prob = dict(zip(zip(noisy.repetition,noisy.scene_id),perturbed))
        frame,repeats = recovery.evaluate(name,plans[plans.split.eq('val')],candidates,
                                         scores[scores.split.eq('val')],noisy_scores,base_prob,noisy_prob)
        if name=='K10_15':
            observed = frame.set_index('scene_id')
            expected = baseline.set_index('scene_id').loc[observed.index]
            for actual,saved in [('accepted','accepted'),('pre_exact','pre_consistency_exact'),
                                 ('pre_false','pre_consistency_false'),('consistency','combined_consistency')]:
                if not np.allclose(observed[actual],expected[saved],rtol=0,atol=1e-12):
                    raise ValueError(f'baseline structural replay failed: {actual}')
        probability_lookup = pd.DataFrame(probability,columns=[f'p_{label.lower()}' for label in graph.RELATION_CLASSES])
        probability_lookup['scene_id'] = val.scene_id.to_numpy()
        frame = frame.merge(probability_lookup,on='scene_id',validate='one_to_one')
        confidence = confidence_diagnostics(name,val,noisy,probability,perturbed,baseline)
        metrics[name] = recovery.summary(frame)
        metrics[name]['raw_accuracy'] = float(np.mean(probability.argmax(axis=1)==truth))
        metrics[name]['validation_log_loss'] = float(log_loss(truth,probability,labels=range(4)))
        all_scenes.append(frame);all_repeats.append(repeats);all_confidence.append(confidence)
        print(name,metrics[name],flush=True)
    scenes = pd.concat(all_scenes,ignore_index=True)
    scenes.to_csv(OUT/'predictions_val.csv',index=False)
    pd.concat(all_repeats,ignore_index=True).to_csv(OUT/'perturbation_decisions_val.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    confidence = pd.concat(all_confidence,ignore_index=True)
    confidence.to_csv(OUT/'confidence_repeats_val.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    confidence.groupby(['variant','scene_family']).agg(
        repeats=('scene_id','size'),raw_correct_fraction=('raw_correct','mean'),
        tau_correct_fraction=('tau_correct','mean'),
        same_correct_raw_below_tau_fraction=('confidence_below_tau_same_correct_raw','mean'),
        true_probability_mean=('true_probability','mean'),confidence_mean=('confidence','mean')
    ).to_csv(OUT/'confidence_by_scene_type_val.csv')
    confidence[confidence.baseline_blocked_exact].groupby(['variant','scene_family']).agg(
        repeats=('scene_id','size'), raw_correct_fraction=('raw_correct','mean'),
        tau_correct_fraction=('tau_correct','mean'),
        same_correct_raw_below_tau_fraction=('confidence_below_tau_same_correct_raw','mean'),
        true_probability_mean=('true_probability','mean')
    ).to_csv(OUT/'confidence_on_blocked103_val.csv')
    for keys,name in [(['variant','scan_id'],'per_patient'),
                      (['variant','scene_family','pair_count','junction_count'],'count_strata')]:
        groups=[]
        for key,group in scenes.groupby(keys):
            groups.append(dict(zip(keys,key))|dict(scenes=len(group))|recovery.summary(group))
        pd.DataFrame(groups).to_csv(OUT/f'{name}_val.csv',index=False)
    base = scenes[scenes.variant.eq('K10_15')].set_index('scene_id')
    experiment = scenes[scenes.variant.eq('feature_ensemble_5')].set_index('scene_id').loc[base.index]
    old_exact = base.accepted.eq(1)&base.exact.eq(1)
    new_exact = experiment.accepted.eq(1)&experiment.exact.eq(1)
    transitions = dict(new_exact_scenes=int((new_exact&~old_exact).sum()),
                       lost_old_exact_scenes=int((old_exact&~new_exact).sum()),
                       recovered_baseline_blocked_exact=int((new_exact&base.pre_exact.eq(1)&~old_exact).sum()))
    candidate = metrics['feature_ensemble_5']
    promoted = (candidate['post_exact']>52 and candidate['post_false']==0
                and candidate['exact_junction_only']>=2 and candidate['exact_mixed']>=2)
    sources = [plans_path,candidates_path,scores_path,models_path,copies_path,
               noisy_feature_path,noisy_score_path,baseline_path,Path(__file__).resolve()]
    result = dict(status='validation_ablation_not_test_frozen',held_out_test_accessed=False,
        baseline='K10/15',experiment='mean probabilities of five HGB with randomized feature splits',
        seeds=SEEDS,max_features=MAX_FEATURES,member_params=models[0].get_params(),
        train_scenes=len(train),train_patients=sorted(train.scan_id.astype(int).unique().tolist()),
        train_rows=len(fit),clean_weight=.5,copy_weight=.5/15,
        local_scores='frozen patient-level OOF train scores; frozen final train models for validation',
        tau=.85,consistency=.60,validation_perturbations=15,
        baseline_probability_replay_max_error=replay_error,
        member_probability_std_mean=float(members_noisy.std(axis=0).mean()),
        metrics=metrics,transitions=transitions,
        passes_predeclared_safety_criterion=promoted,
        decision='candidate for further review' if promoted else 'retain K10/15; ensemble rejected',
        source_sha256={str(path.relative_to(graph.REPO_ROOT)):graph.sha256(path) for path in sources})
    (OUT/'metrics.json').write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':
    main()
