#!/usr/bin/env python3
"""Selected K10/15 rejection audit and one train-only factorized relation ablation."""
from pathlib import Path
import json
import joblib
import numpy as np
import pandas as pd
import run_ct28_graph_lira as graph
import train_ct28_relation_head as training

ROOT = graph.REPO_ROOT
RUNS = ROOT / 'varvara/anza_lira_local_results/ct28_copy_count_ablations'
SELECTED = RUNS / 'joint_check/fusion_10_relation_15'
TRACE = RUNS / 'selected_type_diagnostics'
OUT = ROOT / 'varvara/anza_lira_local_results/ct28_recovery_v1'
IDENTITY = {'PAIR': 'geometry_plus_ct_score', 'JUNCTION': 'geometry_score'}


def decision(plan, candidates, scores, probability):
    raw = graph.RELATION_CLASSES[int(np.argmax(probability))]
    confidence = float(np.max(probability))
    relation = raw if confidence >= .85 else 'NONE'
    pair, junction = graph.choose_compatible_candidates(candidates, scores, relation, IDENTITY)
    return dict(raw_relation=raw, tau_relation=relation, confidence=confidence,
                pair=pair, junction=junction, key=graph.relation_key(pair, junction))


def evaluate(name, plans, candidates, clean_scores, noisy_scores, base_prob, noisy_prob):
    rows, repeats = [], []
    by_candidates = dict(tuple(candidates.groupby('scene_id')))
    by_clean = dict(tuple(clean_scores.groupby('scene_id')))
    by_noisy = dict(tuple(noisy_scores.groupby(['repetition', 'scene_id'])))
    for plan in plans.itertuples(index=False):
        sid = plan.scene_id
        c = by_candidates[sid]
        base = decision(plan, c, by_clean[sid], base_prob[sid])
        keys = []
        for rep in range(15):
            item = decision(plan, c, by_noisy[(rep, sid)], noisy_prob[(rep, sid)])
            keys.append(item['key'])
            repeats.append(dict(variant=name, scene_id=sid, scan_id=plan.scan_id,
                                scene_family=plan.scene_family, repetition=rep, **item))
        consistency = graph.consistency_value(base['key'], keys)
        accepted = base['key'] != 'NONE' and consistency >= .60
        before = graph.evaluate_structure(pd.Series(plan._asdict()), c, base['pair'], base['junction'])
        after = graph.evaluate_structure(pd.Series(plan._asdict()), c,
                                        base['pair'] if accepted else None,
                                        base['junction'] if accepted else None)
        rows.append(dict(variant=name, scene_id=sid, scan_id=plan.scan_id,
                         scene_family=plan.scene_family, relation_class=plan.relation_class,
                         pair_count=int(c.candidate_type.eq('PAIR').sum()),
                         junction_count=int(c.candidate_type.eq('JUNCTION').sum()),
                         pre_exact=before[0], pre_false=before[1], accepted=int(accepted),
                         exact=after[0], false=after[1], incomplete=after[2],
                         consistency=consistency, **base))
    return pd.DataFrame(rows), pd.DataFrame(repeats)


def summary(frame):
    repair = frame.relation_class.ne('NONE')
    accepted = frame.accepted.eq(1)
    return dict(pre_exact=int(frame.loc[repair, 'pre_exact'].sum()),
                pre_false=int(frame.pre_false.sum()),
                post_exact=int(frame.loc[repair, 'exact'].sum()),
                post_false=int(frame.false.sum()), accepted=int(accepted.sum()),
                accepted_incomplete=int(frame.loc[accepted, 'incomplete'].sum()),
                **{f'exact_{family}': int(frame.loc[accepted & frame.scene_family.eq(family), 'exact'].sum())
                   for family in ('pair_only', 'junction_only', 'mixed')})


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    plans = pd.read_csv(graph.DEFAULT_SCENE_DIR / 'scene_plan_train_val.csv')
    candidates = pd.read_csv(graph.DEFAULT_SCENE_DIR / 'scene_candidates_train_val.csv')
    scores = pd.read_csv(SELECTED / 'relation_local_scores_train_val.csv')
    models = joblib.load(SELECTED / 'relation_models.joblib')
    columns = models['ct_conditioned_relation_features']
    clean_rows, actual_columns = graph.relation_feature_rows(plans, candidates, scores,
                                                            ['geometry_score', 'ct_score'])
    assert actual_columns == columns
    clean = pd.DataFrame(clean_rows)
    train = clean[clean.split.eq('train')].copy()
    val = clean[clean.split.eq('val')].copy()
    assert set(train.scan_id.astype(int)) == training.EXPECTED_PATIENT_IDS['train']
    assert set(val.scan_id.astype(int)) == graph.EXPECTED_VALIDATION_PATIENTS
    copies_path = RUNS / 'relation/joint_train_relation_copies.csv'
    copies = pd.read_csv(copies_path, float_precision="round_trip")
    assert set(copies.scan_id.astype(int)) == set(train.scan_id.astype(int))
    assert set(copies.split) == {'train'}
    assert copies.groupby('scene_id').size().eq(15).all()
    train['weight'] = .5
    copies['weight'] = .5 / 15
    fit = pd.concat([train, copies], ignore_index=True)
    assert fit.groupby('scene_id').weight.sum().sub(1).abs().max() < 1e-12
    x = fit[columns].to_numpy(); weights = fit.weight.to_numpy()
    y = fit.relation_class.map({v:i for i,v in enumerate(graph.RELATION_CLASSES)}).to_numpy()
    replay = training.relation_model().fit(x, y, sample_weight=weights)
    xv = val[columns].to_numpy()
    error = float(np.max(np.abs(replay.predict_proba(xv) - models['relation_heads']['ct_conditioned'].predict_proba(xv))))
    if error > 1e-10:
        raise ValueError(f'selected relation replay mismatch {error}')
    print(f'selected model replay error {error:.3g}', flush=True)

    trace = pd.read_csv(TRACE / 'decision_traces_val.csv.gz')
    dynamic = trace[trace['mode'].eq('joint') & trace.intervention.eq('dynamic')].copy()
    base = pd.read_csv(SELECTED / 'clean_eval/graph_lira_predictions_val.csv')
    base = base[base.model.eq('ct_conditioned')]
    blocked = base[base.relation_class.ne('NONE') & base.pre_consistency_exact.eq(1) & base.accepted.eq(0)]
    assert len(blocked) == 103 and len(dynamic) == 5520
    counts = pd.crosstab(dynamic.scene_id, dynamic.failure_layer).reindex(blocked.scene_id).fillna(0).astype(int)
    details = blocked[['scene_id','scan_id','scene_family','confidence','combined_consistency']].merge(
        counts, on='scene_id', validate='one_to_one')
    failure_columns = ['raw_type_flip', 'confidence_fell_below_tau', 'candidate_identity_flip']
    details['dominant_failure'] = details[failure_columns].idxmax(axis=1)
    details.to_csv(OUT / 'blocked_103_scenes.csv', index=False)
    details.groupby(['scan_id','scene_family']).agg(
        scenes=('scene_id','size'), mean_clean_confidence=('confidence','mean'),
        mean_consistency=('combined_consistency','mean'),
        raw_type_flips=('raw_type_flip','sum'), confidence_failures=('confidence_fell_below_tau','sum'),
        identity_flips=('candidate_identity_flip','sum'), stable_repeats=('stable','sum')
    ).to_csv(OUT / 'blocked_by_patient_type.csv')
    mass_rows = []
    for family in ('junction_only', 'mixed'):
        rows = dynamic[dynamic.scene_id.isin(blocked.loc[blocked.scene_family.eq(family),'scene_id'])]
        low = rows[rows.failure_layer.eq('confidence_fell_below_tau')]
        mass = low.p_junction + low.p_both
        mass_rows.append(dict(scene_family=family, same_raw_below_tau=len(low),
                              junction_presence_at_least_tau=int(mass.ge(.85).sum()),
                              marginal_mean=float(mass.mean())))
    # One predeclared factorized head: binary presence probabilities, product joint distribution.
    # No calibration/threshold selection on validation and no second-level pseudo OOF.
    heads = {}
    for label, positive in [('pair', ('PAIR','BOTH')), ('junction', ('JUNCTION','BOTH'))]:
        heads[label] = training.relation_model().fit(
            x, fit.relation_class.isin(positive).astype(int), sample_weight=weights)
    joblib.dump(dict(heads=heads, features=columns), OUT / 'factorized_relation_heads.joblib')
    noisy_features = pd.read_csv(TRACE / 'relation_features_val.csv.gz')
    noisy_features = noisy_features[noisy_features['mode'].eq('joint')]
    noisy_scores = pd.read_csv(TRACE / 'local_scores_val.csv.gz')
    noisy_scores = noisy_scores[noisy_scores['mode'].eq('joint')]
    assert len(noisy_features) == 5520
    def predict(values, variant):
        if variant == 'K10_15':
            return models['relation_heads']['ct_conditioned'].predict_proba(values)
        p = heads['pair'].predict_proba(values)[:,1]
        j = heads['junction'].predict_proba(values)[:,1]
        return np.stack([(1-p)*(1-j),p*(1-j),(1-p)*j,p*j],axis=1)
    all_frames, all_repeats, metrics = [], [], {}
    for variant in ('K10_15','factorized_presence'):
        base_probs = dict(zip(val.scene_id, predict(xv,variant)))
        noisy_probs = dict(zip(zip(noisy_features.repetition,noisy_features.scene_id),
                               predict(noisy_features[columns].to_numpy(),variant)))
        frame, repeat = evaluate(variant, plans[plans.split.eq('val')], candidates,
                                 scores[scores.split.eq('val')],noisy_scores,base_probs,noisy_probs)
        if variant == 'K10_15':
            observed=frame.set_index('scene_id')
            expected=base.set_index('scene_id').loc[observed.index]
            for actual, saved in [('accepted','accepted'),('pre_exact','pre_consistency_exact'),
                                  ('pre_false','pre_consistency_false'),('consistency','combined_consistency')]:
                if not np.allclose(observed[actual],expected[saved],rtol=0,atol=1e-12):
                    raise ValueError(f'baseline decision replay failed: {actual}')
        metrics[variant]=summary(frame);all_frames.append(frame);all_repeats.append(repeat)
        print(variant,metrics[variant],flush=True)
    assert metrics['K10_15']['post_exact']==52 and metrics['K10_15']['post_false']==0
    frame=pd.concat(all_frames,ignore_index=True)
    frame.to_csv(OUT/'predictions_val.csv',index=False)
    pd.concat(all_repeats,ignore_index=True).to_csv(OUT/'perturbation_decisions_val.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    for keys,name in [(['variant','scan_id'],'per_patient'),(['variant','scene_family','pair_count','junction_count'],'count_strata')]:
        rows=[]
        for key,group in frame.groupby(keys):
            rows.append(dict(zip(keys,key)) | dict(scenes=len(group)) | summary(group))
        pd.DataFrame(rows).to_csv(OUT/f'{name}_val.csv',index=False)
    result=dict(status='train_validation_ablation_not_test_frozen',held_out_test_accessed=False,
                baseline='K10/15',tau=.85,consistency=.60,validation_repeats=15,
                relation_probability_replay_max_error=error,train_scenes=len(train),train_rows=len(fit),
                junction_marginal_diagnostic=mass_rows,metrics=metrics,
                selection='retain K10/15 unless alternative improves safe accepted exact and JUNCTION/mixed coverage',
                source_sha256={str(p.relative_to(ROOT)):graph.sha256(p) for p in [copies_path,SELECTED/'relation_models.joblib', SELECTED/'relation_local_scores_train_val.csv',
                    TRACE/'decision_traces_val.csv.gz', TRACE/'relation_features_val.csv.gz',
                    TRACE/'local_scores_val.csv.gz', graph.DEFAULT_SCENE_DIR/'scene_plan_train_val.csv',
                    graph.DEFAULT_SCENE_DIR/'scene_candidates_train_val.csv']})
    (OUT/'metrics.json').write_text(json.dumps(result,indent=2)+'\n')


if __name__ == '__main__':
    main()
