#!/usr/bin/env python3
"""Compare relation-head noise modes with joint geometry and fixed PAIR fusion identity."""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import combine_ct28_geometry_pair_fusion as combined
import run_ct28_graph_lira as graph
import train_ct28_geometry_augmentation_matrix as matrix
import train_ct28_perturbation_augmented_relation_head as augmentation
import train_ct28_relation_head as training
import train_ct28_selected_relation_augmentation as selected
from ct28_perturbations import perturb_scene_endpoints


ROOT = training.REPO_ROOT
BASE = ROOT / "varvara/anza_lira_local_results/ct28_geometry_pair_fusion_comparison/both"
OUTPUT = ROOT / "varvara/anza_lira_local_results/ct28_joint_geometry_ablations/relation"
NOISE = {"position_only": (0.8, 0.0), "tangent_only": (0.0, 20.0)}
COPIES = 15
SEED = 20260920


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-evidence", type=Path, default=BASE)
    parser.add_argument("--scene-dir", type=Path, default=graph.DEFAULT_SCENE_DIR)
    parser.add_argument("--robust-evidence", type=Path, default=combined.ROBUST)
    parser.add_argument("--archive-dir", type=Path, default=graph.DEFAULT_ARCHIVE_DIR)
    parser.add_argument("--out-dir", type=Path, default=OUTPUT)
    return parser.parse_args()


def save_head(
    name: str,
    base_dir: Path,
    base_scores: pd.DataFrame,
    base_pack: dict,
    source_hashes: dict[str, str],
    clean_rows: list[dict],
    columns: list[str],
    noisy_rows: list[dict],
    out_root: Path,
) -> None:
    clean_train = [dict(row, augmentation_index=0, sample_weight=1.0 if name == "clean" else 0.5)
                   for row in clean_rows if row["split"] == "train"]
    clean_val = [row for row in clean_rows if row["split"] == "val"]
    if name == "clean":
        metrics, prediction, head = training.fit_relation_head(clean_rows, columns, 0.85, "ct_conditioned")
    else:
        training_rows = clean_train + noisy_rows
        augmentation.validate_augmentation_weights(training_rows, COPIES)
        head, metrics, prediction = augmentation.fit_augmented_head(training_rows, clean_val, columns, 0.85)
    out = out_root / name
    out.mkdir(parents=True, exist_ok=True)
    pack = copy.deepcopy(base_pack)
    pack["relation_heads"]["ct_conditioned"] = head
    joblib.dump(pack, out / "relation_models.joblib")
    base_scores.to_csv(out / "relation_local_scores_train_val.csv", index=False)
    geometry_predictions = pd.read_csv(base_dir / "relation_predictions_val.csv")
    geometry_predictions = geometry_predictions[geometry_predictions["model"] == "geometry_only"]
    pd.concat([geometry_predictions, pd.DataFrame(prediction)], ignore_index=True).to_csv(
        out / "relation_predictions_val.csv", index=False)
    (out / "relation_metrics_val.json").write_text(json.dumps(metrics, indent=2) + "\n")
    (out / "relation_model_protocol.json").write_text(json.dumps({
        "status": "validation_ablation_not_frozen",
        "held_out_test_accessed": False,
        "source_sha256": source_hashes,
        "geometry_source": str(base_dir),
        "relation_noise_mode": name,
        "relation_copies": 0 if name == "clean" else COPIES,
        "relation_clean_weight": 1.0 if name == "clean" else 0.5,
        "noise_position_sigma_mm": NOISE.get(name, (0.0, 0.0))[0],
        "noise_tangent_sigma_deg": NOISE.get(name, (0.0, 0.0))[1],
        "pair_identity": "geometry_plus_ct_score",
        "junction_identity": "geometry_score",
        "tau": 0.85,
        "consistency": 0.60,
    }, indent=2) + "\n")
    print(f"saved relation mode {name}", flush=True)


def main() -> None:
    args = arguments()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    loaded = augmentation.load_inputs(argparse.Namespace(
        scene_dir=args.scene_dir, clean_evidence_dir=args.robust_evidence))
    plans, candidates, endpoints, features = (loaded[key] for key in ("plans", "candidates", "endpoints", "features"))
    if set(plans.scan_id.astype(int)) & combined.TEST_PATIENTS:
        raise ValueError("held-out test entered scene pack")
    base_scores = pd.read_csv(args.base_evidence / "relation_local_scores_train_val.csv")
    base_pack = joblib.load(args.base_evidence / "relation_models.joblib")
    base_protocol = json.loads((args.base_evidence / "relation_model_protocol.json").read_text())
    source_hashes = matrix.source_hashes(args.scene_dir)
    if source_hashes != base_protocol["source_sha256"] or source_hashes != loaded["protocol"]["source_sha256"]:
        raise ValueError("scene source changed")
    if not base_scores[["scene_id", "candidate_id"]].equals(loaded["scores"][["scene_id", "candidate_id"]]):
        raise ValueError("candidate order changed")
    base_fold_models, reproduction_error = selected.fold_models_for_patients(loaded)
    fold_maps = {
        kind: {int(patient): int(fold) for patient, fold in loaded["protocol"][f"patient_oof_folds_{kind.lower()}_geometry"].items()}
        for kind in ("PAIR", "JUNCTION")
    }
    joint_models, joint_scores = combined.train_joint_geometry(features, candidates, endpoints, fold_maps)
    indexed = base_scores.set_index(["scene_id", "candidate_id"])
    for kind in ("PAIR", "JUNCTION"):
        subset = indexed[indexed.candidate_type.eq(kind)]
        error = np.max(np.abs(subset.geometry_score.to_numpy() - joint_scores[kind].loc[subset.index].to_numpy()))
        if error > 1e-12:
            raise ValueError(f"joint {kind} OOF/final scores not reproduced: {error}")
    if reproduction_error > 1e-10:
        raise ValueError("source OOF model reproduction failed")

    clean_rows, columns = graph.relation_feature_rows(plans, candidates, base_scores, ("geometry_score", "ct_score"))
    if len(columns) != 84:
        raise ValueError("relation feature dimension changed")
    save_head("clean", args.base_evidence, base_scores, base_pack, source_hashes, clean_rows, columns, [], args.out_dir)

    train_plans = plans[plans.split.eq("train")]
    train_scene_ids = set(train_plans.scene_id)
    train_candidates = candidates[candidates.scene_id.isin(train_scene_ids)]
    train_endpoints = endpoints[endpoints.scene_id.isin(train_scene_ids)]
    expected_geometry = pd.read_csv(graph.ct_features.EXPECTED_GEOMETRY).set_index("scan_id")
    expected_alignment = pd.read_csv(graph.ct_features.EXPECTED_ALIGNMENT).set_index("scan_id")
    arm_names = graph.ct_features.arm_feature_names(graph.ct_features.RADII_MM)
    output_rows = {mode: [] for mode in NOISE}
    for patient in sorted(training.EXPECTED_PATIENT_IDS["train"]):
        patient_plans = train_plans[train_plans.scan_id.eq(patient)]
        patient_ids = set(patient_plans.scene_id)
        patient_candidates = train_candidates[train_candidates.scene_id.isin(patient_ids)]
        patient_endpoints = train_endpoints[train_endpoints.scene_id.isin(patient_ids)]
        by_scene = dict(tuple(patient_candidates.groupby("scene_id", sort=False)))
        ct, inverse_affine = graph.load_verified_ct(patient, args.archive_dir, expected_geometry, expected_alignment)
        for mode, (position_sigma, tangent_sigma) in NOISE.items():
            for repetition in range(COPIES):
                feature_rows = []
                for scene_id, scene_endpoints in patient_endpoints.groupby("scene_id", sort=False):
                    perturbed = perturb_scene_endpoints(
                        scene_endpoints, seed=SEED, repetition=repetition,
                        position_noise_mm=position_sigma, tangent_noise_deg=tangent_sigma,
                    ).set_index("endpoint_id")
                    for candidate in by_scene[scene_id].itertuples(index=False):
                        feature_rows.append(graph.perturbed_candidate_features(
                            pd.Series(candidate._asdict()), perturbed, ct, inverse_affine, arm_names))
                frame = pd.DataFrame(feature_rows)
                scores = matrix.score_geometry_ct(frame, base_fold_models[patient])
                for kind in ("PAIR", "JUNCTION"):
                    mask = frame.candidate_type.eq(kind)
                    model = joint_models[kind]["fold"][patient]
                    model_columns = list(model.feature_names_in_)
                    scores.loc[mask, "geometry_score"] = model.predict_proba(frame.loc[mask, model_columns])[:, 1]
                relation_rows, relation_columns = graph.relation_feature_rows(
                    patient_plans, patient_candidates, scores, ("geometry_score", "ct_score"))
                if relation_columns != columns:
                    raise ValueError("relation feature order changed")
                for row in relation_rows:
                    row["augmentation_index"] = repetition + 1
                    row["sample_weight"] = 0.5 / COPIES
                output_rows[mode].extend(relation_rows)
        print(f"relation position/tangent: patient {patient} complete", flush=True)
        del ct

    for mode, rows in output_rows.items():
        out = args.out_dir / mode
        out.mkdir(exist_ok=True)
        pd.DataFrame(rows).to_csv(out / "augmented_relation_rows_train.csv", index=False)
        save_head(mode, args.base_evidence, base_scores, base_pack, source_hashes, clean_rows, columns, rows, args.out_dir)


if __name__ == "__main__":
    main()
