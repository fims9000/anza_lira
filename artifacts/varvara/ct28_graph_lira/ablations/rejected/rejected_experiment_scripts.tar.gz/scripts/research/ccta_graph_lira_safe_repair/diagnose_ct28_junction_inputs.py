#!/usr/bin/env python3
"""Validation-only input interventions; no fitting or protocol selection."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import run_ct28_graph_lira as graph
from ct28_perturbations import perturb_scene_endpoints
from extract_junction_ct_features import estimate_junction_center

ROOT = graph.DEFAULT_SCENE_DIR
FAMILIES = ('junction_only', 'mixed', 'none_incomplete_junction')
XYZ = ['x_lps', 'y_lps', 'z_lps']
TANGENT = ['tangent_x', 'tangent_y', 'tangent_z']
SCORES = ['geometry_score', 'ct_score', 'geometry_plus_ct_score']
MODES = ('joint', 'position_only', 'tangent_only')
INTERVENTIONS = ('dynamic', 'freeze_ct', 'freeze_geometry', 'freeze_identity')


def paired_noise(endpoints, repetition, mode):
    out = perturb_scene_endpoints(endpoints, seed=20260920, repetition=repetition,
                                  position_noise_mm=0.8, tangent_noise_deg=20)
    if mode == 'position_only':
        out.loc[:, TANGENT] = endpoints[TANGENT].to_numpy()
    elif mode == 'tangent_only':
        out.loc[:, XYZ] = endpoints[XYZ].to_numpy()
    elif mode != 'joint':
        raise ValueError(mode)
    return out


def intervene(scores, baseline, intervention):
    out = scores.copy()
    column = {'freeze_ct': 'ct_score', 'freeze_geometry': 'geometry_score',
              'freeze_identity': 'geometry_plus_ct_score'}.get(intervention)
    if column:
        keys = pd.MultiIndex.from_frame(out[['scene_id', 'candidate_id']])
        frozen = baseline.set_index(['scene_id', 'candidate_id'])[column]
        out[column] = frozen.reindex(keys).to_numpy()
        if not np.isfinite(out[column]).all():
            raise ValueError('missing frozen candidate score')
    if intervention in ('freeze_pair_geometry', 'freeze_junction_geometry'):
        kind = 'PAIR' if intervention == 'freeze_pair_geometry' else 'JUNCTION'
        mask = out.candidate_type.eq(kind)
        keys = pd.MultiIndex.from_frame(out.loc[mask, ['scene_id','candidate_id']])
        frozen = baseline.set_index(['scene_id','candidate_id'])['geometry_score']
        out.loc[mask, 'geometry_score'] = frozen.reindex(keys).to_numpy()
        if not np.isfinite(out.geometry_score).all():
            raise ValueError('missing frozen geometry candidate score')
    return out


def centers(candidates, endpoints):
    lookup = endpoints.set_index('endpoint_id')
    return {row.candidate_id: estimate_junction_center(
        lookup.loc[row.endpoint_ids.split('|'), XYZ].to_numpy(),
        lookup.loc[row.endpoint_ids.split('|'), TANGENT].to_numpy())
        for row in candidates[candidates.candidate_type.eq('JUNCTION')].itertuples()}


def run(label, scene_dir, evidence, reference, out_dir, split_geometry=False):
    plans = pd.read_csv(scene_dir / 'scene_plan_train_val.csv')
    candidates = pd.read_csv(scene_dir / 'scene_candidates_train_val.csv')
    graph.relation_training.validate_scene_inputs(plans, candidates)
    protocol = json.loads((evidence / 'relation_model_protocol.json').read_text())
    for key, filename in [('scene_plan', 'scene_plan_train_val.csv'),
                          ('scene_candidates', 'scene_candidates_train_val.csv'),
                          ('scene_candidate_features', 'scene_candidate_features_train_val.csv')]:
        assert graph.sha256(scene_dir / filename) == protocol['source_sha256'][key]
    plans = plans[plans.split.eq('val') & plans.scene_family.isin(FAMILIES)].copy()
    assert len(plans) == 100 and set(plans.scan_id) == graph.EXPECTED_VALIDATION_PATIENTS
    candidates = candidates[candidates.scene_id.isin(plans.scene_id)].copy()
    endpoints = pd.read_csv(scene_dir / 'scene_endpoints_train_val.csv')
    endpoints = endpoints[endpoints.scene_id.isin(plans.scene_id)]
    baseline = pd.read_csv(evidence / 'relation_local_scores_train_val.csv')
    baseline = baseline[baseline.scene_id.isin(plans.scene_id)].copy()
    models = joblib.load(evidence / 'relation_models.joblib')
    assert models['local_model_family'] == 'hgb'
    ref = pd.read_csv(reference / 'perturbation_decisions_val.csv').fillna('')
    ref = ref[ref.model.eq('ct_conditioned')].set_index(['scene_id', 'repetition'])
    base_predictions = graph.predict_relations(plans, candidates, baseline, models, .85)
    id_columns = {'geometry_only': 'geometry_score', 'ct_conditioned': 'geometry_plus_ct_score'}
    base_decisions = graph.select_scene_decisions(
        plans, candidates, baseline, base_predictions, id_columns)['ct_conditioned']
    expected_geo = pd.read_csv(graph.ct_features.EXPECTED_GEOMETRY).set_index('scan_id')
    expected_alignment = pd.read_csv(graph.ct_features.EXPECTED_ALIGNMENT).set_index('scan_id')
    arm_names = graph.ct_features.arm_feature_names(graph.ct_features.RADII_MM)
    frozen_features = pd.read_csv(scene_dir / 'scene_candidate_features_train_val.csv',
                                  low_memory=False).set_index(['scene_id','candidate_id'])
    decision_rows, candidate_rows, zero_checks = [], [], []
    zero_error, reference_error = 0., 0.
    for patient in sorted(plans.scan_id.unique()):
        pp = plans[plans.scan_id.eq(patient)]
        cc = candidates[candidates.scene_id.isin(pp.scene_id)]
        ee = endpoints[endpoints.scene_id.isin(pp.scene_id)]
        bs = baseline[baseline.scene_id.isin(pp.scene_id)]
        ct, inv = graph.load_verified_ct(int(patient), graph.DEFAULT_ARCHIVE_DIR,
                                        expected_geo, expected_alignment)
        base_centers = {sid: centers(cc[cc.scene_id.eq(sid)], ep)
                        for sid, ep in ee.groupby('scene_id', sort=False)}
        for repetition in range(-1, 15):
            for mode in (('zero',) if repetition == -1 else (('joint',) if split_geometry else MODES)):
                features, pert_centers = [], {}
                for sid, ep in ee.groupby('scene_id', sort=False):
                    pert = ep if mode == 'zero' else paired_noise(ep, repetition, mode)
                    sc = cc[cc.scene_id.eq(sid)]
                    pert_centers[sid] = centers(sc, pert)
                    for _, candidate in sc.iterrows():
                        features.append(graph.perturbed_candidate_features(
                            candidate, pert.set_index('endpoint_id'), ct, inv, arm_names))
                frame = pd.DataFrame(features)
                dynamic = graph.score_feature_frame(frame, models['local_models'])
                if mode == 'zero':
                    a = dynamic.set_index(['scene_id', 'candidate_id'])[SCORES].sort_index()
                    b = bs.set_index(['scene_id', 'candidate_id'])[SCORES].sort_index()
                    err = float(np.abs(a-b).to_numpy().max())
                    zero_error = max(zero_error, err)
                    computed = frame.set_index(['scene_id','candidate_id'])
                    for candidate_type in ('PAIR','JUNCTION'):
                        part = computed[computed.candidate_type.eq(candidate_type)]
                        for stream in SCORES:
                            model = models['local_models'][candidate_type][stream.replace('_score','')]
                            columns = list(model.feature_names_in_)
                            saved = frozen_features.loc[part.index,columns]
                            current = part[columns]
                            assert np.allclose(saved,current,atol=1e-7,rtol=1e-9,equal_nan=True)
                            saved_scores = model.predict_proba(saved)[:,1]
                            assert np.allclose(saved_scores,b.loc[part.index,stream],atol=1e-12,rtol=0)
                            score_error = np.abs(a.loc[part.index,stream]-b.loc[part.index,stream])
                            zero_checks.append(dict(scan_id=int(patient),candidate_type=candidate_type,
                                stream=stream,max_score_error=float(score_error.max()),
                                changed_over_1e_6=int((score_error>1e-6).sum()),
                                max_feature_abs_error=float(np.nanmax(np.abs(current.to_numpy()-saved.to_numpy())))))
                merged = cc[['scene_id', 'candidate_id', 'candidate_type', 'y']].merge(
                    dynamic, on=['scene_id', 'candidate_id', 'candidate_type'], validate='one_to_one')
                before = bs.set_index(['scene_id', 'candidate_id'])
                for sid, group in merged[merged.candidate_type.eq('JUNCTION')].groupby('scene_id'):
                    false = group[group.y.eq(0)]
                    best_false = (None if false.empty else
                                  false.loc[false.geometry_plus_ct_score.idxmax(), 'candidate_id'])
                    for row in group.itertuples():
                        old = before.loc[(sid, row.candidate_id)]
                        center = pert_centers[sid][row.candidate_id]
                        base_center = base_centers[sid][row.candidate_id]
                        record = dict(run=label, scan_id=int(patient), scene_id=sid,
                                      mode=mode, repetition=repetition, candidate_id=row.candidate_id,
                                      y=int(row.y), best_false_fusion=int(row.candidate_id==best_false),
                                      center_shift_mm=float(np.linalg.norm(center-base_center)))
                        for axis, value, old_value in zip('xyz', center, base_center):
                            record[f'center_{axis}'] = float(value)
                            record[f'base_center_{axis}'] = float(old_value)
                        for column in SCORES:
                            record[column] = float(getattr(row, column))
                            record['base_'+column] = float(old[column])
                            record['delta_'+column] = record[column]-record['base_'+column]
                        candidate_rows.append(record)
                for intervention in (('dynamic','freeze_pair_geometry','freeze_junction_geometry') if split_geometry else INTERVENTIONS):
                    scores = intervene(dynamic, bs, intervention)
                    predictions = graph.predict_relations(pp, cc, scores, models, .85)
                    decisions = graph.select_scene_decisions(
                        pp, cc, scores, predictions, id_columns)['ct_conditioned']
                    for plan in pp.itertuples():
                        sid = plan.scene_id
                        d, base = decisions[sid], base_decisions[sid]
                        sc = cc[cc.scene_id.eq(sid)]
                        exact, false, incomplete = graph.evaluate_structure(
                            pd.Series(plan._asdict()), sc, d['pair_candidate_id'], d['junction_candidate_id'])
                        junction_scores = merged[merged.scene_id.eq(sid) & merged.candidate_type.eq('JUNCTION')]
                        true = junction_scores[junction_scores.y.eq(1)]
                        false_scores = junction_scores[junction_scores.y.eq(0)]
                        record = dict(run=label, scan_id=int(patient), scene_id=sid,
                                      scene_family=plan.scene_family, truth=plan.relation_class,
                                      mode=mode, intervention=intervention, repetition=repetition,
                                      raw_relation=d['raw_relation'], tau_relation=d['relation'],
                                      selected_relation=d['selected_relation'], confidence=d['confidence'],
                                      p_junction=d['probabilities'][2], p_both=d['probabilities'][3],
                                      base_p_junction=base['probabilities'][2],
                                      base_raw_relation=base['raw_relation'],
                                      base_tau_relation=base['relation'],
                                      base_key=base['relation_key'], key=d['relation_key'],
                                      base_has_repair=int(base['selected_relation']!='NONE'),
                                      base_exact=graph.evaluate_structure(pd.Series(plan._asdict()),sc,
                                          base['pair_candidate_id'],base['junction_candidate_id'])[0],
                                      exact=exact, false=false, incomplete=incomplete,
                                      compatibility=int(d['compatibility_satisfied']))
                        if len(true):
                            for col in SCORES:
                                best = float(false_scores[col].max()) if len(false_scores) else np.nan
                                record['true_'+col] = float(true.iloc[0][col])
                                record['best_false_'+col] = best
                                record['true_top1_'+col] = int(
                                    junction_scores.loc[junction_scores[col].idxmax(), 'y']==1)
                                record['margin_'+col] = record['true_'+col]-best
                        decision_rows.append(record)
                        if mode=='joint' and intervention=='dynamic':
                            old = ref.loc[(sid, repetition)]
                            assert d['relation_key'] == old.relation_key
                            assert d['raw_relation'] == old.raw_relation
                            reference_error = max(reference_error, abs(d['confidence']-old.confidence))
                            assert reference_error < 1e-10
            if repetition in (4, 9, 14):
                print(f'{label}: patient {patient}, repeats {repetition+1}/15', flush=True)
        del ct
    out_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(candidate_rows).to_csv(out_dir / 'candidate_traces_val.csv.gz', index=False,
                                       compression={'method':'gzip','mtime':0})
    details = pd.DataFrame(decision_rows)
    details.to_csv(out_dir / 'decision_traces_val.csv.gz', index=False,
                   compression={'method':'gzip','mtime':0})
    pd.DataFrame(zero_checks).to_csv(out_dir/'zero_noise_audit.csv',index=False)
    scene_rows=[]
    for (mode, intervention, sid), part in details.groupby(['mode','intervention','scene_id']):
        first=part.iloc[0]
        consistency=graph.consistency_value(first.base_key, part.key.tolist())
        accepted=bool(first.base_has_repair and consistency>=.60)
        if mode=='zero':
            accepted=False  # one replay is not a 15-repeat consistency evaluation
        scene_rows.append(dict(run=label, mode=mode, intervention=intervention, scene_id=sid,
            scene_family=first.scene_family, scan_id=int(first.scan_id),
            base_exact=int(first.base_exact), base_has_repair=int(first.base_has_repair),
            type_agreement=float(part.raw_relation.eq(first.base_raw_relation).mean()),
            tau_agreement=float(part.tau_relation.eq(first.base_tau_relation).mean()),
            exact_repeat=float(part.exact.mean()), false_repeat=float(part['false'].mean()),
            key_agreement=float(part.key.eq(first.base_key).mean()), consistency=consistency,
            accepted=int(accepted), accepted_exact=int(accepted and first.base_exact),
            p_junction=float(part.p_junction.mean()), base_p_junction=first.base_p_junction,
            true_fusion_top1=float(part.get('true_top1_geometry_plus_ct_score', pd.Series(dtype=float)).mean())))
    scenes=pd.DataFrame(scene_rows)
    scenes.to_csv(out_dir / 'scene_diagnostics_val.csv', index=False)
    summary=scenes.groupby(['run','mode','intervention','scene_family']).agg(
        scenes=('scene_id','size'), base_exact=('base_exact','sum'), accepted=('accepted','sum'),
        accepted_exact=('accepted_exact','sum'), raw_type_agreement=('type_agreement','mean'),
        tau_type_agreement=('tau_agreement','mean'), exact_repeat=('exact_repeat','mean'),
        false_repeat=('false_repeat','mean'), consistency=('consistency','mean'),
        p_junction=('p_junction','mean'), true_fusion_top1=('true_fusion_top1','mean')).reset_index()
    summary.to_csv(out_dir / 'summary_val.csv',index=False)
    sources={str(p.relative_to(graph.REPO_ROOT)):graph.sha256(p) for p in (
        scene_dir/'scene_plan_train_val.csv', scene_dir/'scene_candidates_train_val.csv',
        scene_dir/'scene_endpoints_train_val.csv', evidence/'relation_models.joblib',
        evidence/'relation_local_scores_train_val.csv', reference/'perturbation_decisions_val.csv')}
    (out_dir/'protocol.json').write_text(json.dumps(dict(run=label, held_out_test_accessed=False,
        training_performed=False, families=FAMILIES, scenes=100, repetitions=15,
        position_sigma_mm_per_axis=.8, tangent_sigma_degrees=20,
        seed=20260920, modes=(('joint',) if split_geometry else MODES),
        interventions=(('dynamic','freeze_pair_geometry','freeze_junction_geometry') if split_geometry else INTERVENTIONS),
        freeze_semantics='Freeze all PAIR and JUNCTION scores of the named stream to baseline. Fusion identity stays dynamic except freeze_identity. Diagnostic hybrids, not deployable models.',
        paired_noise='Draw joint noise once; restore tangents or positions for isolated modes.',
        zero_noise_max_score_error=zero_error, joint_reference_max_confidence_error=reference_error,
        source_sha256=sources),indent=2)+'\n')
    print(f'{label}: completed',flush=True)


def summarize():
    out = ROOT / 'ablations/junction_input_diagnostics'
    geometry_rows, geometry_stats, metrics = [], [], []
    for label, scene_dir in [('clean', ROOT), ('stress', ROOT/'ablations/stress30_jitter1')]:
        result = out/label
        traces = pd.read_csv(result/'decision_traces_val.csv.gz')
        assert len(traces) == 18400
        assert set(traces.scan_id) == graph.EXPECTED_VALIDATION_PATIENTS
        assert traces.groupby(['mode','intervention','scene_id']).size().to_dict() == {
            key: (1 if key[0]=='zero' else 15)
            for key in traces.groupby(['mode','intervention','scene_id']).size().index}
        for (mode, intervention, family), part in traces.groupby(['mode','intervention','scene_family']):
            metrics.append(dict(run=label,mode=mode,intervention=intervention,scene_family=family,
                raw_accuracy=float(part.raw_relation.eq(part.truth).mean()),
                tau_accuracy=float(part.tau_relation.eq(part.truth).mean()),
                exact_repeat=float(part.exact.mean()),false_repeat=float(part['false'].mean()),
                p_junction=float(part.p_junction.mean())))
        features=pd.read_csv(scene_dir/'scene_candidate_features_train_val.csv',low_memory=False)
        candidates=pd.read_csv(scene_dir/'scene_candidates_train_val.csv')
        endpoints=pd.read_csv(scene_dir/'scene_endpoints_train_val.csv')
        candidates=candidates[candidates.scene_id.str.contains(':val:junction_only:') &
                              candidates.candidate_type.eq('JUNCTION') & candidates.y.eq(1)]
        columns=list(graph.relation_training.JUNCTION_GEOMETRY_FEATURES)
        train=features[features.split.eq('train') & features.candidate_type.eq('JUNCTION') & features.y.eq(1)]
        rows=[]
        for candidate in candidates.itertuples():
            ep=endpoints[endpoints.scene_id.eq(candidate.scene_id)]
            for repetition in range(15):
                for mode in MODES:
                    pert=paired_noise(ep,repetition,mode).set_index('endpoint_id').loc[candidate.endpoint_ids.split('|')]
                    values=graph.scene_builder.oriented_junction_geometry(
                        [graph.endpoint_item(row) for _,row in pert.iterrows()])
                    rows.append(dict(run=label,scene_id=candidate.scene_id,mode=mode,
                                     repetition=repetition,**dict(zip(columns,values))))
        geometry_rows.extend(rows)
        frame=pd.DataFrame(rows)
        base=features[features.scene_id.isin(candidates.scene_id)&features.candidate_type.eq('JUNCTION')&features.y.eq(1)]
        for column in columns:
            lo,hi=map(float,train[column].quantile([.05,.95]))
            for mode,group in frame.groupby('mode'):
                geometry_stats.append(dict(run=label,feature=column,mode=mode,
                    base_median=float(base[column].median()),perturbed_median=float(group[column].median()),
                    train_positive_q05=lo,train_positive_q95=hi,
                    outside_train_positive_90pct=float(((group[column]<lo)|(group[column]>hi)).mean())))
    pd.DataFrame(geometry_rows).to_csv(out/'true_junction_geometry_traces_val.csv.gz',index=False,
                                      compression={'method':'gzip','mtime':0})
    pd.DataFrame(geometry_stats).to_csv(out/'geometry_shift_summary.csv',index=False)
    (out/'metrics.json').write_text(json.dumps(dict(held_out_test_accessed=False,
        training_performed=False,metric_unit='scene perturbation repeat; not independent patients',
        repeat_metrics=metrics),indent=2)+'\n')
    stress=ROOT/'ablations/stress30_jitter1'
    pack=joblib.load(stress/'local_hgb/relation_models.joblib')
    frame=pd.read_csv(stress/'scene_candidate_features_train_val.csv',low_memory=False)
    scene='CT28S:val:junction_only:957:left:542'
    candidate='JUNCTION:E00+E03+E04'
    row=frame[frame.scene_id.eq(scene)&frame.candidate_id.eq(candidate)]
    model=pack['local_models']['JUNCTION']['ct']
    values=model[0].transform(row[list(model.feature_names_in_)])
    tree=model[1]
    score=float(tree.predict_proba(values)[0,1])
    adjacent=np.nextafter(values,np.inf)
    changes=[]
    for index,column in enumerate(model.feature_names_in_):
        changed=values.copy()
        changed[0,index]=adjacent[0,index]
        new_score=float(tree.predict_proba(changed)[0,1])
        if abs(new_score-score)>1e-12:
            changes.append(dict(feature=column,before=float(values[0,index]),
                after=float(changed[0,index]),score=new_score,delta=new_score-score))
    (out/'numeric_boundary_example.json').write_text(json.dumps(dict(
        diagnostic='float64 nextafter toward positive infinity on saved imputed CT features; no physical noise, no fitting',
        scene_id=scene,candidate_id=candidate,base_score=score,
        all_features_nextafter_score=float(tree.predict_proba(adjacent)[0,1]),
        single_feature_changes=changes,held_out_test_accessed=False),indent=2)+'\n')



def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',choices=['clean','stress'])
    parser.add_argument('--summarize',action='store_true')
    parser.add_argument('--split-geometry',action='store_true')
    args=parser.parse_args()
    if args.summarize:
        summarize()
        return
    if args.run is None:
        parser.error('--run or --summarize is required')
    if args.run=='clean':
        scene=ROOT; evidence=ROOT/'ablations/local_hgb'
        reference=ROOT/'consistency_diagnostics/clean_hgb'
    else:
        scene=ROOT/'ablations/stress30_jitter1'; evidence=scene/'local_hgb'
        reference=evidence/'graph_lira_ct_identity_corrected'
    out_name=args.run+'_split_geometry' if args.split_geometry else args.run
    run(args.run,scene,evidence,reference,ROOT/'ablations/junction_input_diagnostics'/out_name,
        split_geometry=args.split_geometry)


if __name__=='__main__':
    main()
