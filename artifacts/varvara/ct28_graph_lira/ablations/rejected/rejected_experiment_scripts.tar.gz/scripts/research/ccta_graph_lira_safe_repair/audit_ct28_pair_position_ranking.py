#!/usr/bin/env python3
"""Compare PAIR geometry ranking under the frozen validation position noise."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import pandas as pd

import train_ct28_relation_head as training
from train_ct28_position_robust_pair_geometry import pair_geometry_rows, GEOMETRY


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scene-dir', type=Path, default=training.DEFAULT_SCENE_DIR)
    parser.add_argument('--reference-dir', type=Path,
                        default=training.DEFAULT_SCENE_DIR/'ablations/junction_position_robustness')
    parser.add_argument('--new-dir', type=Path,
                        default=training.DEFAULT_SCENE_DIR/'ablations/pair_junction_geometry_robust')
    args = parser.parse_args()
    plans = pd.read_csv(args.scene_dir/'scene_plan_train_val.csv')
    candidates = pd.read_csv(args.scene_dir/'scene_candidates_train_val.csv')
    training.validate_scene_inputs(plans, candidates)
    val_scenes = set(plans.loc[plans.split.eq('val'), 'scene_id'])
    pairs = candidates[candidates.candidate_type.eq('PAIR') &
                       candidates.scene_id.isin(val_scenes)].copy()
    endpoints = pd.read_csv(args.scene_dir/'scene_endpoints_train_val.csv')
    endpoints = endpoints[endpoints.scene_id.isin(val_scenes)]
    old = joblib.load(args.reference_dir/'relation_models.joblib')['local_models']['PAIR']['geometry']
    new = joblib.load(args.new_dir/'relation_models.joblib')['local_models']['PAIR']['geometry']
    totals = {name: {} for name in ('reference', 'position_robust')}
    clean_features = pd.read_csv(args.scene_dir/'scene_candidate_features_train_val.csv',
                                 usecols=['scene_id', 'candidate_id', *GEOMETRY])
    for repetition in range(-1, 15):
        if repetition == -1:
            frame = pairs[['scene_id', 'candidate_id', 'y']].merge(
                clean_features, on=['scene_id', 'candidate_id'], validate='one_to_one')
        else:
            frame = pair_geometry_rows(pairs, endpoints, repetition=repetition,
                                       seed=20260920, position_noise_mm=0.8).merge(
                pairs[['scene_id', 'candidate_id', 'y']],
                on=['scene_id', 'candidate_id'], validate='one_to_one')
        for name, model in [('reference', old), ('position_robust', new)]:
            scored = frame[['scene_id', 'candidate_id', 'y']].copy()
            scored['score'] = model.predict_proba(frame[GEOMETRY])[:, 1]
            for _, group in scored.groupby('scene_id'):
                if not group.y.eq(1).any():
                    continue
                key = 'clean' if repetition == -1 else 'noisy'
                competitive = bool(group.y.eq(0).any())
                correct = int(group.loc[group.score.idxmax(), 'y'] == 1)
                metric = totals[name].setdefault(key, {
                    'correct_top1': 0, 'scenes': 0,
                    'competitive_correct_top1': 0, 'competitive_scenes': 0,
                })
                metric['correct_top1'] += correct
                metric['scenes'] += 1
                if competitive:
                    metric['competitive_correct_top1'] += correct
                    metric['competitive_scenes'] += 1
    out = {'held_out_test_accessed': False, 'noise': '15 position-only repeats, sigma=0.8 mm',
           'patient_ids': sorted(plans.loc[plans.split.eq('val'), 'scan_id'].astype(int).unique().tolist()),
           'models': totals}
    (args.new_dir/'pair_position_ranking_val.json').write_text(json.dumps(out, indent=2)+'\n')
    print(json.dumps(out, indent=2))


if __name__ == '__main__':
    main()
