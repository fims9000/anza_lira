#!/usr/bin/env python3
"""One fixed PAIR-only JS-strength ablation against the saved 54/0 relation MLP."""
from pathlib import Path
import json

import joblib
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from threadpoolctl import threadpool_limits

import train_ct28_probability_consistency as mlp
import evaluate_ct28_recovery as recovery
import run_ct28_graph_lira as graph
import train_ct28_relation_head as training
from train_ct28_confidence_ensemble import confidence_diagnostics, validate_probabilities

OUT = graph.REPO_ROOT / 'varvara/anza_lira_local_results/ct28_probability_consistency_pair3_v1'
MULTIPLIERS = np.array([1.,3.,1.,1.])  # NONE, PAIR, JUNCTION, BOTH


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    gradient_error=mlp.gradient_check()
    print(f'class-specific JS gradient check {gradient_error:.3g}',flush=True)
    scene=graph.DEFAULT_SCENE_DIR
    paths=dict(plans=scene/'scene_plan_train_val.csv',candidates=scene/'scene_candidates_train_val.csv',
               scores=recovery.SELECTED/'relation_local_scores_train_val.csv',
               copies=recovery.RUNS/'relation/joint_train_relation_copies.csv',
               reference_model=mlp.OUT/'relation_models.joblib',reference_predictions=mlp.OUT/'predictions_val.csv',
               noisy_features=recovery.TRACE/'relation_features_val.csv.gz',
               noisy_scores=recovery.TRACE/'local_scores_val.csv.gz')
    plans=pd.read_csv(paths['plans']);candidates=pd.read_csv(paths['candidates'])
    training.validate_scene_inputs(plans,candidates)
    scores=pd.read_csv(paths['scores']);reference=joblib.load(paths['reference_model'])
    columns=reference['features']
    rows,actual=graph.relation_feature_rows(plans,candidates,scores,['geometry_score','ct_score'])
    if columns!=actual:raise ValueError('reference feature order changed')
    clean=pd.DataFrame(rows);train=clean[clean.split.eq('train')];val=clean[clean.split.eq('val')]
    copies=pd.read_csv(paths['copies'],float_precision='round_trip')
    if set(train.scan_id.astype(int))!=training.EXPECTED_PATIENT_IDS['train'] or set(copies.scan_id.astype(int))!=set(train.scan_id.astype(int)) or set(copies.split)!={'train'}:
        raise ValueError('train patient split changed')
    if len(train)!=1036 or len(copies)!=15*len(train):raise ValueError('train view coverage changed')
    indexed=copies.set_index(['augmentation_index','scene_id'])
    arrays=[train[columns].to_numpy()]
    for rep in range(1,16):
        part=indexed.loc[rep].loc[train.scene_id]
        if not np.array_equal(part.relation_class.to_numpy(),train.relation_class.to_numpy()):
            raise ValueError('augmentation changed relation class')
        arrays.append(part[columns].to_numpy())
    scaler=reference['scaler'];views=np.stack([scaler.transform(a) for a in arrays],axis=1)
    if not np.isfinite(views).all():raise ValueError('non-finite training input')
    if not np.allclose(scaler.mean_,arrays[0].mean(axis=0),atol=1e-12,rtol=0):
        raise ValueError('saved train normalization no longer matches train scenes')
    labels=train.relation_class.map({v:i for i,v in enumerate(graph.RELATION_CLASSES)}).to_numpy()
    class_weights=len(labels)/(4*np.bincount(labels,minlength=4))
    initial=mlp.initialize(len(columns),mlp.HIDDEN,seed=0)
    iteration=[0]
    args=(views,labels,class_weights,1.,mlp.HIDDEN,mlp.L2,MULTIPLIERS)
    def callback(theta):
        iteration[0]+=1
        if iteration[0]%50==0:
            print(f'PAIR_JS3 iteration {iteration[0]} train loss {mlp.objective(theta,*args)[0]:.6f}',flush=True)
    fit=minimize(mlp.objective,initial,args=args,method='L-BFGS-B',jac=True,callback=callback,
                 options=dict(maxiter=mlp.ITERATIONS,ftol=1e-9,gtol=1e-5,maxls=30))
    if not np.isfinite(fit.fun) or not np.isfinite(fit.x).all():raise ValueError('non-finite training result')
    print('optimizer',fit.message,'iterations',fit.nit,flush=True)
    joblib.dump(dict(parameters=fit.x,scaler=scaler,features=columns,hidden=mlp.HIDDEN,
                     js_class_multipliers=MULTIPLIERS),OUT/'relation_model.joblib')
    noisy=pd.read_csv(paths['noisy_features']);noisy=noisy[noisy['mode'].eq('joint')]
    noisy_scores=pd.read_csv(paths['noisy_scores']);noisy_scores=noisy_scores[noisy_scores['mode'].eq('joint')]
    if len(noisy)!=5520 or set(noisy.scan_id.astype(int))!=graph.EXPECTED_VALIDATION_PATIENTS:
        raise ValueError('validation cohort or repetitions changed')
    xv=scaler.transform(val[columns].to_numpy());xn=scaler.transform(noisy[columns].to_numpy())
    reference_predictions=pd.read_csv(paths['reference_predictions'])
    reference_predictions=reference_predictions[reference_predictions.variant.eq('MLP_CE_JS')]
    audit_reference=reference_predictions.rename(columns={'pre_exact':'pre_consistency_exact'})
    blocked=audit_reference[audit_reference.relation_class.ne('NONE')&audit_reference.pre_consistency_exact.eq(1)&audit_reference.accepted.eq(0)]
    if len(blocked)!=87:raise ValueError('54/0 reference blocked exact cohort changed')
    blocked.to_csv(OUT/'blocked_reference_scenes.csv',index=False)
    models={'MLP_JS1':reference['parameters']['MLP_CE_JS'],'MLP_PAIR_JS3':fit.x}
    frames=[];confidence_rows=[];metrics={}
    for name,theta in models.items():
        bp=mlp.predict(theta,xv);npred=mlp.predict(theta,xn)
        validate_probabilities(bp);validate_probabilities(npred)
        frame,_=recovery.evaluate(name,plans[plans.split.eq('val')],candidates,scores[scores.split.eq('val')],
            noisy_scores,dict(zip(val.scene_id,bp)),dict(zip(zip(noisy.repetition,noisy.scene_id),npred)))
        if name=='MLP_JS1':
            observed=frame.set_index('scene_id');expected=reference_predictions.set_index('scene_id').loc[observed.index]
            for column in ['accepted','pre_exact','pre_false','confidence','consistency']:
                if not np.allclose(observed[column],expected[column],atol=1e-12,rtol=0):
                    raise ValueError(f'54/0 reference replay failed: {column}')
        probs=pd.DataFrame(bp,columns=[f'p_{label.lower()}' for label in graph.RELATION_CLASSES]);probs['scene_id']=val.scene_id.to_numpy()
        frame=frame.merge(probs,on='scene_id',validate='one_to_one');frames.append(frame)
        diagnostic=confidence_diagnostics(name,val,noisy,bp,npred,audit_reference)
        base_lookup=dict(zip(val.scene_id,bp))
        q=np.stack([base_lookup[sid] for sid in noisy.scene_id]);mix=.5*(q+npred)
        diagnostic['probability_js_from_clean']=.5*np.sum(q*(np.log(np.maximum(q,1e-300))-np.log(np.maximum(mix,1e-300)))+npred*(np.log(np.maximum(npred,1e-300))-np.log(np.maximum(mix,1e-300))),axis=1)
        confidence_rows.append(diagnostic);metrics[name]=recovery.summary(frame)
        print(name,metrics[name],flush=True)
    frame=pd.concat(frames,ignore_index=True);frame.to_csv(OUT/'predictions_val.csv',index=False)
    confidence=pd.concat(confidence_rows,ignore_index=True)
    confidence.to_csv(OUT/'confidence_repeats_val.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    for blocked_only,name in [(False,'confidence_all_val'),(True,'confidence_blocked_reference_val')]:
        selected=confidence[confidence.baseline_blocked_exact] if blocked_only else confidence
        selected.groupby(['variant','scene_family']).agg(repeats=('scene_id','size'),raw_correct_fraction=('raw_correct','mean'),
            tau_correct_fraction=('tau_correct','mean'),same_correct_raw_below_tau_fraction=('confidence_below_tau_same_correct_raw','mean'),
            true_probability_mean=('true_probability','mean'),probability_js_mean=('probability_js_from_clean','mean')).to_csv(OUT/f'{name}.csv')
    for keys,name in [(['variant','scan_id'],'per_patient'),(['variant','scene_family','pair_count','junction_count'],'count_strata')]:
        summary=[]
        for key,group in frame.groupby(keys):summary.append(dict(zip(keys,key))|dict(scenes=len(group))|recovery.summary(group))
        pd.DataFrame(summary).to_csv(OUT/f'{name}_val.csv',index=False)
    baseline=frame[frame.variant.eq('MLP_JS1')].set_index('scene_id');new=frame[frame.variant.eq('MLP_PAIR_JS3')].set_index('scene_id').loc[baseline.index]
    old_exact=baseline.accepted.eq(1)&baseline.exact.eq(1);new_exact=new.accepted.eq(1)&new.exact.eq(1)
    diagnostics={}
    for name,theta in models.items():
        ce=mlp.objective(theta,views,labels,class_weights,0.)[0]
        js=mlp.objective(theta,views,labels,class_weights,1.)[0]-ce
        diagnostics[name]=dict(ce_plus_l2=ce,uniform_class_weighted_js=js)
    result=dict(status='bounded_train_validation_ablation_not_test_frozen',held_out_test_accessed=False,
        reference='saved MLP CE+JS54/0',change='JS coefficient only: true PAIR train scenes3, other classes1',
        architecture='84-64tanh-4',seed=0,initialization='same seed0 from scratch; no warm start',
        train_patients=sorted(train.scan_id.astype(int).unique().tolist()),train_scenes=len(train),views_per_scene=16,
        js_multiplier_by_class=dict(zip(graph.RELATION_CLASSES,MULTIPLIERS.tolist())),
        ce_weights='clean0.5, all15copies0.5, class balanced unchanged',
        local_models_and_identity='frozen as original54/0',tau=.85,consistency=.60,validation_repeats=15,
        optimizer=dict(method='L-BFGS-B',maxiter=mlp.ITERATIONS,iterations=int(fit.nit),success=bool(fit.success),
                       message=str(fit.message),train_loss=float(fit.fun),gradient_max=float(np.max(np.abs(fit.jac)))),
        l2=mlp.L2,gradient_check_max_error=gradient_error,reference_blocked_exact_scenes=87,
        metrics=metrics,train_diagnostics=diagnostics,
        transitions=dict(new_exact_scenes=int((new_exact&~old_exact).sum()),lost_old_exact_scenes=int((old_exact&~new_exact).sum())),
        no_validation_fit_or_checkpoint_selection=True,
        decision='keep PAIR_JS3 as separate exploratory PAIR candidate55/0; preserve uniformJS54/0 JUNCTION control; primaryHGB unchanged',
        source_sha256={key:graph.sha256(path) for key,path in paths.items()},
        implementation_sha256={'runner':graph.sha256(Path(__file__)),'loss':graph.sha256(Path(mlp.__file__))})
    (OUT/'metrics.json').write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':
    with threadpool_limits(limits=1):main()
