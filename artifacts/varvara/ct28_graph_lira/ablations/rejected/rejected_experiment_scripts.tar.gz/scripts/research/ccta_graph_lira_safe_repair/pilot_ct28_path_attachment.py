#!/usr/bin/env python3
"""One train-only CT attachment ablation on the exact frozen path-evidence pilot."""
from pathlib import Path
import argparse
import hashlib
import inspect
from itertools import product
import json
import shutil
import time

import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment

import pilot_ct28_path_evidence as pilot

BASE=pilot.OUT
OUT=pilot.ROOT/'varvara/anza_lira_local_results/ct28_path_attachment_pilot_v1'
RADIUS=1.0
SIGMA=1.0
QUANTILE=90


def attach_endpoints(ct,affine,positions,vessel_hu,background_hu,config,radius=RADIUS):
    inverse=np.linalg.inv(affine)
    if radius==0:
        return positions.copy(),np.zeros(len(positions)),[float(vessel_hu)]*len(positions),[float(vessel_hu)]*len(positions)
    bounds=np.ceil(radius*np.linalg.norm(inverse[:3,:3],axis=1)).astype(int)
    offsets=np.array(list(product(*(range(-int(b),int(b)+1) for b in bounds))),dtype=int)
    delta=(offsets @ affine[:3,:3].T)*np.array([-1.,-1.,1.])
    distances=np.linalg.norm(delta,axis=1)
    keep=distances<=radius+1e-10;offsets=offsets[keep];delta=delta[keep];distances=distances[keep]
    by_endpoint=[];all_voxels=set();references=[];quantiles=[]
    for position in positions:
        continuous=pilot.path.lps_to_voxel(position[None,:],inverse)[0]
        trial=continuous[None,:]+offsets
        inside=((trial>=0)&(trial<=np.asarray(ct.shape)-1)).all(axis=1)
        points=position[None,:]+delta[inside]
        if not len(points):raise ValueError('no endpoint attachment inside CT')
        hu=np.asarray(pilot.path.sample_world(ct,inverse,points),dtype=np.float32)
        q=float(np.percentile(hu,QUANTILE));reference=max(float(vessel_hu),q)
        support=pilot.path.voxel_support(hu,reference,background_hu,config)
        utility=support*np.exp(-.5*(distances[inside]/SIGMA)**2)
        voxels=np.rint(trial[inside]).astype(int)
        options={}
        for voxel,point,distance,score in zip(voxels,points,distances[inside],utility):
            key=tuple(int(v) for v in voxel)
            previous=options.get(key)
            if previous is None or score>previous[2] or (score==previous[2] and distance<previous[1]):
                options[key]=(point,float(distance),float(score))
            all_voxels.add(key)
        by_endpoint.append(options);references.append(reference);quantiles.append(q)
    ordered=sorted(all_voxels);index={voxel:i for i,voxel in enumerate(ordered)}
    costs=np.full((len(positions),len(ordered)),1e9)
    for arm,options in enumerate(by_endpoint):
        for voxel,(_,distance,score) in options.items():
            costs[arm,index[voxel]]=-np.log(max(score,1e-12))+1e-9*distance**2
    arms,chosen=linear_sum_assignment(costs)
    if len(arms)!=len(positions) or np.any(costs[arms,chosen]>=1e9):
        raise ValueError('no distinct endpoint attachment')
    attached=np.empty_like(positions);shifts=np.empty(len(positions))
    for arm,column in zip(arms,chosen):
        point,distance,_=by_endpoint[arm][ordered[column]]
        attached[arm]=point;shifts[arm]=distance
    if shifts.max()>radius+1e-10:raise ValueError('attachment exceeded frozen radius')
    actual=np.rint(pilot.path.lps_to_voxel(attached,inverse)).astype(int)
    if len({tuple(v) for v in actual})!=len(positions):raise ValueError('attachment collapsed endpoints')
    return attached,shifts,references,quantiles


def attachment_evidence(ct,affine,positions,tangents,config,observed_reference,radius=RADIUS):
    vessel_hu,background_hu=observed_reference
    attached,shifts,references,quantiles=attach_endpoints(ct,affine,positions,vessel_hu,background_hu,config,radius)
    raw=pilot.path_evidence(ct,affine,attached,tangents,config)
    penalty=float(np.exp(-.5*np.sum((shifts/SIGMA)**2)))
    result=dict(raw)
    for feature in (pilot.PRIMARY,pilot.SECONDARY,'worst_arm_mean_support'):
        result['raw_'+feature]=float(raw[feature]);result[feature]=float(raw[feature])*penalty
    result.update(attachment_penalty=penalty,attachment_max_shift_mm=float(shifts.max()),
        attachment_total_shift_mm=float(shifts.sum()),attachment_shifts_mm=json.dumps(shifts.tolist()),
        attached_positions_lps=json.dumps(attached.tolist()),
        attachment_vessel_references_hu=json.dumps(references),attachment_local_q90_hu=json.dumps(quantiles),
        attached_span_mm=float(np.max(np.linalg.norm(attached[:,None]-attached[None,:],axis=-1))))
    return result


def check_synthetic(config):
    if pilot.path.reconstruct({(1,):(2,),(2,):(1,)},(0,),(1,))!=():
        raise ValueError('cyclic predecessor chain was not rejected')
    if pilot.path.reconstruct({(2,):(1,),(1,):(0,)},(0,),(2,))!=((0,),(1,),(2,)):
        raise ValueError('acyclic predecessor chain changed')
    ct=np.zeros((25,25,25),dtype=np.float32);yy,zz=np.indices((25,25))
    ct[:,(yy-12)**2+(zz-12)**2<=2.25]=350.
    affine=np.diag([.5,.5,.5,1.]);positions=pilot.path.voxel_to_lps(np.array([[5,12,12],[19,12,12]]),affine)
    positions[0,1]-=1.
    tangents=np.array([[-1.,0.,0.],[1.,0.,0.]])
    baseline=pilot.path_evidence(ct,affine,positions,tangents,config)
    reference=(baseline['vessel_hu'],baseline['background_hu'])
    zero=attachment_evidence(ct,affine,positions,tangents,config,reference,0.)
    attached=attachment_evidence(ct,affine,positions,tangents,config,reference)
    if not np.isclose(zero[pilot.PRIMARY],baseline[pilot.PRIMARY],atol=1e-12) or zero['attachment_penalty']!=1:
        raise ValueError('zero-radius path did not reproduce baseline')
    if attached[pilot.PRIMARY]<=baseline[pilot.PRIMARY]:raise ValueError('synthetic off-axis attachment did not improve support')
    duplicate=np.repeat(positions[:1],2,axis=0)
    distinct,shifts,_,_=attach_endpoints(ct,affine,duplicate,*reference,config)
    if len({tuple(v) for v in np.rint(pilot.path.lps_to_voxel(distinct,np.linalg.inv(affine))).astype(int)})!=2:
        raise ValueError('distinct endpoint assignment test failed')
    if np.any(shifts>RADIUS+1e-10):raise ValueError('synthetic radius exceeded')
    return dict(exact_endpoint_bottleneck=baseline[pilot.PRIMARY],attached_penalized_bottleneck=attached[pilot.PRIMARY],
                attachment_shifts_mm=json.loads(attached['attachment_shifts_mm']))


def summarize(out):
    pilot.summarize(out)
    result=json.loads((out/'metrics.json').read_text())
    original=pd.read_csv(BASE/'path_features_train.csv',float_precision='round_trip')
    new=pd.read_csv(out/'path_features_train.csv',float_precision='round_trip')
    keys=['scene_id','candidate_id','repetition']
    if set(map(tuple,original[keys].to_numpy()))!=set(map(tuple,new[keys].to_numpy())):
        raise ValueError('attachment ablation changed candidate/view keys')
    reference=original.set_index(keys).loc[pd.MultiIndex.from_frame(new[keys])]
    for column in ('scan_id','split','candidate_type','y','exceeds_historical_span'):
        if not np.array_equal(reference[column].to_numpy(),new[column].to_numpy()):
            raise ValueError('attachment changed frozen metadata: '+column)
    if not np.allclose(reference.observed_span_mm,new.observed_span_mm,atol=1e-9):
        raise ValueError('attachment changed original observed endpoints')
    for row in new.itertuples():
        shifts=np.asarray(json.loads(row.attachment_shifts_mm))
        penalty=float(np.exp(-.5*np.sum((shifts/SIGMA)**2)))
        if not np.isfinite(shifts).all() or shifts.min()<0 or shifts.max()>RADIUS+1e-10:
            raise ValueError('invalid attachment movement')
        if not np.isclose(penalty,row.attachment_penalty,atol=1e-12):
            raise ValueError('attachment penalty differs from stored movement')
    for feature in (pilot.PRIMARY,pilot.SECONDARY,'worst_arm_mean_support'):
        if not np.isfinite(new[feature]).all() or not new[feature].between(0,1).all():
            raise ValueError('invalid penalized evidence: '+feature)
        if not np.allclose(new[feature],new['raw_'+feature]*new.attachment_penalty,atol=1e-12):
            raise ValueError('evidence penalty not applied: '+feature)
    if pilot.graph.sha256(BASE/'pilot_plan_train.csv')!=pilot.graph.sha256(out/'pilot_plan_train.csv'):
        raise ValueError('pilot plan changed')
    baseline_metrics=json.loads((BASE/'metrics.json').read_text())
    b=pd.read_csv(BASE/'paired_comparisons_train.csv').set_index(['scene_id','repetition'])
    n=pd.read_csv(out/'paired_comparisons_train.csv').set_index(['scene_id','repetition']).loc[b.index]
    comparison=[]
    for kind in ('PAIR','JUNCTION'):
        for mode in ('clean','position_only'):
            mask=b.candidate_type.eq(kind)&b['mode'].eq(mode)
            delta=(n.loc[mask,pilot.PRIMARY+'_win']-b.loc[mask,pilot.PRIMARY+'_win'])
            patient=delta.groupby(b.loc[mask,'scan_id']).mean().to_numpy()
            rng=np.random.default_rng(20260920);bootstrap=rng.choice(patient,size=(1000,len(patient)),replace=True).mean(axis=1)
            old=baseline_metrics['statistics'][kind][mode];current=result['statistics'][kind][mode]
            group=new[new.candidate_type.eq(kind)&(new.repetition.eq(-1) if mode=='clean' else new.repetition.ge(0))]
            comparison.append(dict(candidate_type=kind,mode=mode,matched_pairs=old['matched_pairs'],
                old_auroc=old['bottleneck_auroc'],attached_auroc=current['bottleneck_auroc'],
                raw_attached_auroc_diagnostic=float(pilot.roc_auc_score(group.y,group['raw_'+pilot.PRIMARY])),
                old_strict_wins=old['bottleneck_strict_wins'],attached_strict_wins=current['bottleneck_strict_wins'],
                old_paired_win=old['bottleneck_paired_win'],attached_paired_win=current['bottleneck_paired_win'],
                paired_win_delta=float(patient.mean()),paired_win_delta_ci_low=float(np.quantile(bootstrap,.025)),
                paired_win_delta_ci_high=float(np.quantile(bootstrap,.975))))
    pd.DataFrame(comparison).to_csv(out/'comparison_train.csv',index=False)
    movement=[]
    for (kind,y,mode),group in new.assign(mode=np.where(new.repetition.eq(-1),'clean','position_only')).groupby(['candidate_type','y','mode']):
        movement.append(dict(candidate_type=kind,y=int(y),mode=mode,mean_max_shift_mm=float(group.attachment_max_shift_mm.mean()),
                             median_penalty=float(group.attachment_penalty.median())))
    result.update(name='ct28_endpoint_attachment_train_pilot_v1',comparison=comparison,attachment_movement=movement,
                  reference_metrics_sha256=pilot.graph.sha256(BASE/'metrics.json'),
                  attachment_script_sha256=pilot.graph.sha256(Path(__file__)),
                  checks=dict(identical_plan_and_408_candidate_views=True,original_metadata_and_jitter_equal=True,
                              radius0_routes_reproduced=408,maximum_displacement_mm=RADIUS,
                              distinct_attachment_voxels_enforced=True,penalty_recomputed=True))
    (out/'metrics.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(comparison,indent=2),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive-dir',type=Path,default=pilot.graph.DEFAULT_ARCHIVE_DIR)
    parser.add_argument('--out-dir',type=Path,default=OUT)
    parser.add_argument('--check-only',action='store_true')
    parser.add_argument('--summarize-only',action='store_true')
    args=parser.parse_args()
    base_protocol=json.loads((BASE/'protocol.json').read_text());config=pilot.path.PathConfig(**base_protocol['path_config'])
    if args.summarize_only:summarize(args.out_dir);return
    synthetic=check_synthetic(config);print('synthetic attachment check',synthetic,flush=True)
    if args.check_only:return
    args.out_dir.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(BASE/'pilot_plan_train.csv',args.out_dir/'pilot_plan_train.csv')
    plan=pd.read_csv(BASE/'pilot_plan_train.csv');original=pd.read_csv(BASE/'path_features_train.csv',float_precision='round_trip')
    lookup_base=original.set_index(['scene_id','candidate_id','repetition'])
    if set(plan.scan_id.astype(int))!=pilot.TRAIN_IDS or len(original)!=408:raise ValueError('reference train pilot changed')
    protocol=dict(base_protocol)
    solver_sha=pilot.graph.sha256(Path(pilot.path.__file__))
    protocol['source_sha256']=dict(base_protocol['source_sha256'],path_solver=solver_sha)
    protocol.update(name='ct28_endpoint_attachment_train_pilot_v1',baseline_protocol_sha256=pilot.graph.sha256(BASE/'protocol.json'),
        baseline_features_sha256=pilot.graph.sha256(BASE/'path_features_train.csv'),
        baseline_path_solver_sha256=base_protocol['source_sha256']['path_solver'],
        attachment=dict(radius_mm=RADIUS,gaussian_sigma_mm=SIGMA,local_vessel_percentile=QUANTILE,
            position_grid='physical CT-grid offsets added to observed continuous endpoint; fractional offset preserved',
            support_reference='max(original observed vessel reference, local endpoint HU q90); original observed background',
            assignment='distinct CT voxels; minimize negative log of support times Gaussian distance penalty',
            route_reference='same solver recomputes HU references and center at attached endpoints',
            final_penalty='exp(-sum(endpoint displacement squared)/(2*sigma squared))',
            primary='raw_path_bottleneck times final_penalty',secondary='raw_worst_arm_edge_q10 times final_penalty'),
        synthetic_check=synthetic,path_solver_sha256=solver_sha,
        extractor_sha256=hashlib.sha256((inspect.getsource(attach_endpoints)+inspect.getsource(attachment_evidence)+inspect.getsource(pilot.path_evidence)).encode()).hexdigest())
    file=args.out_dir/'protocol.json'
    if file.exists() and json.loads(file.read_text())!=protocol:raise ValueError('attachment inputs/protocol changed; refusing resume')
    file.write_text(json.dumps(protocol,indent=2)+'\n')
    output=args.out_dir/'path_features_train.csv';done=set()
    if output.exists():
        old=pd.read_csv(output);done=set(zip(old.scene_id,old.candidate_id,old.repetition))
    endpoints=pd.read_csv(pilot.graph.DEFAULT_SCENE_DIR/'scene_endpoints_train_val.csv')
    geometry=pd.read_csv(pilot.graph.ct_features.EXPECTED_GEOMETRY).set_index('scan_id')
    alignment=pd.read_csv(pilot.graph.ct_features.EXPECTED_ALIGNMENT).set_index('scan_id')
    for patient in sorted(pilot.TRAIN_IDS):
        patient_plan=plan[plan.scan_id.eq(patient)]
        expected={(r.scene_id,r.candidate_id,rep) for r in patient_plan.itertuples() for rep in range(-1,5)}
        if expected<=done:continue
        ct,inverse=pilot.graph.load_verified_ct(patient,args.archive_dir,geometry,alignment);affine=np.linalg.inv(inverse)
        for scene_id,group in patient_plan.groupby('scene_id',sort=True):
            clean=endpoints[endpoints.scene_id.eq(scene_id)]
            for rep in range(-1,5):
                observed=clean.copy()
                if rep>=0:
                    observed=pilot.perturb_scene_endpoints(clean,seed=20260920,repetition=rep,position_noise_mm=.8,tangent_noise_deg=0.)
                    observed.loc[:,pilot.TANGENT]=clean[pilot.TANGENT].to_numpy()
                lookup=observed.set_index('endpoint_id')
                for candidate in group.itertuples():
                    key=(scene_id,candidate.candidate_id,rep)
                    if key in done:continue
                    source=lookup_base.loc[key];rows=lookup.loc[candidate.endpoint_ids.split('|')]
                    positions=rows[pilot.XYZ].to_numpy(dtype=float);tangents=rows[pilot.TANGENT].to_numpy(dtype=float)
                    span=float(np.max(np.linalg.norm(positions[:,None]-positions[None,:],axis=-1)))
                    if not np.isclose(span,source.observed_span_mm,atol=1e-9):raise ValueError('pilot endpoint jitter changed')
                    reference=(source.vessel_hu,source.background_hu)
                    unchanged,shifts,_,_=attach_endpoints(ct,affine,positions,*reference,config,0.)
                    if not np.array_equal(unchanged,positions) or np.any(shifts):raise ValueError('radius0 changes observed endpoints')
                    control=attachment_evidence(ct,affine,positions,tangents,config,reference,0.)
                    for feature in ('path_valid',pilot.PRIMARY,pilot.SECONDARY):
                        if not np.isclose(control[feature],source[feature],atol=1e-10):raise ValueError('radius0 baseline replay failed')
                    if control['status']!=source.status:raise ValueError('radius0 status differs')
                    started=time.monotonic()
                    result=attachment_evidence(ct,affine,positions,tangents,config,reference)
                    record=dict(scan_id=patient,split='train',scene_id=scene_id,candidate_id=candidate.candidate_id,
                        candidate_type=candidate.candidate_type,y=int(candidate.y),repetition=rep,observed_span_mm=span,
                        exceeds_historical_span=int(source.exceeds_historical_span),ct_alignment_verified=1,
                        seconds=time.monotonic()-started,**result)
                    pd.DataFrame([record]).to_csv(output,mode='a',header=not output.exists(),index=False);done.add(key)
            print(f'attachment patient {patient} {group.iloc[0].candidate_type}: {len(done)}/408',flush=True)
        del ct
    summarize(args.out_dir)


if __name__=='__main__':main()
