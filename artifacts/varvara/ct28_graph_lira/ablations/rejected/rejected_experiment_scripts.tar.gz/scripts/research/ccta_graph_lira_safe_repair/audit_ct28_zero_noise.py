#!/usr/bin/env python3
"""Check whether CT28 clean scores and decisions reproduce after CT re-extraction."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import run_ct28_graph_lira as graph


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scene-dir', type=Path, default=graph.DEFAULT_SCENE_DIR)
    parser.add_argument('--evidence-dir', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--archive-dir', type=Path, default=graph.DEFAULT_ARCHIVE_DIR)
    args = parser.parse_args()
    plans = pd.read_csv(args.scene_dir/'scene_plan_train_val.csv')
    candidates = pd.read_csv(args.scene_dir/'scene_candidates_train_val.csv')
    graph.relation_training.validate_scene_inputs(plans, candidates)
    endpoints = pd.read_csv(args.scene_dir/'scene_endpoints_train_val.csv')
    scores = pd.read_csv(args.evidence_dir/'relation_local_scores_train_val.csv')
    models = joblib.load(args.evidence_dir/'relation_models.joblib')
    protocol = json.loads((args.evidence_dir/'relation_model_protocol.json').read_text())
    for key, filename in [('scene_plan','scene_plan_train_val.csv'),
                          ('scene_candidates','scene_candidates_train_val.csv'),
                          ('scene_candidate_features','scene_candidate_features_train_val.csv')]:
        if graph.sha256(args.scene_dir/filename) != protocol['source_sha256'][key]:
            raise ValueError(f'frozen source changed: {filename}')
    plans = plans[plans.split.eq('val')]
    if set(plans.scan_id.astype(int)) != graph.EXPECTED_VALIDATION_PATIENTS:
        raise ValueError('unexpected validation patient IDs')
    identity = {'geometry_only':'geometry_score',
                'ct_conditioned':{'PAIR':'geometry_plus_ct_score',
                                  'JUNCTION':'geometry_score'}}
    expected_geometry = pd.read_csv(graph.ct_features.EXPECTED_GEOMETRY).set_index('scan_id')
    expected_alignment = pd.read_csv(graph.ct_features.EXPECTED_ALIGNMENT).set_index('scan_id')
    arm_names = graph.ct_features.arm_feature_names(graph.ct_features.RADII_MM)
    report = {'held_out_test_accessed':False,
              'validation_patients':sorted(map(int,plans.scan_id.unique())),
              'candidate_count':0,
              'max_score_delta':{name:0.0 for name in ('geometry_score','ct_score','geometry_plus_ct_score')},
              'changed_scores_above_1e_12':{name:0 for name in ('geometry_score','ct_score','geometry_plus_ct_score')},
              'relation_type_changes':{name:0 for name in identity},
              'candidate_key_changes':{name:0 for name in identity}}
    for scan_id in sorted(graph.EXPECTED_VALIDATION_PATIENTS):
        patient_plans = plans[plans.scan_id.eq(scan_id)]
        scene_ids = set(patient_plans.scene_id)
        patient_candidates = candidates[candidates.scene_id.isin(scene_ids)]
        patient_endpoints = endpoints[endpoints.scene_id.isin(scene_ids)]
        baseline = scores[scores.scene_id.isin(scene_ids)]
        ct, inverse_affine = graph.load_verified_ct(
            scan_id, args.archive_dir, expected_geometry, expected_alignment)
        rows = []
        for scene_id, scene_endpoints in patient_endpoints.groupby('scene_id',sort=False):
            lookup = scene_endpoints.set_index('endpoint_id')
            for _, candidate in patient_candidates[patient_candidates.scene_id.eq(scene_id)].iterrows():
                rows.append(graph.perturbed_candidate_features(
                    candidate, lookup, ct, inverse_affine, arm_names))
        replay = graph.score_feature_frame(pd.DataFrame(rows),models['local_models'])
        paired = baseline.merge(replay,on=['scene_id','candidate_id','candidate_type'],
                                suffixes=('_base','_replay'),validate='one_to_one')
        if len(paired) != len(baseline):
            raise ValueError('zero-noise candidate mismatch')
        report['candidate_count'] += len(paired)
        for name in report['max_score_delta']:
            delta=np.abs(paired[name+'_base']-paired[name+'_replay'])
            report['max_score_delta'][name]=max(report['max_score_delta'][name],float(delta.max()))
            report['changed_scores_above_1e_12'][name]+=int((delta>1e-12).sum())
        baseline_rel=graph.predict_relations(patient_plans,patient_candidates,baseline,models,.85)
        replay_rel=graph.predict_relations(patient_plans,patient_candidates,replay,models,.85)
        baseline_dec=graph.select_scene_decisions(patient_plans,patient_candidates,baseline,baseline_rel,identity)
        replay_dec=graph.select_scene_decisions(patient_plans,patient_candidates,replay,replay_rel,identity)
        for name in identity:
            for scene_id in scene_ids:
                report['relation_type_changes'][name]+=int(
                    baseline_dec[name][scene_id]['relation']!=replay_dec[name][scene_id]['relation'])
                report['candidate_key_changes'][name]+=int(
                    baseline_dec[name][scene_id]['relation_key']!=replay_dec[name][scene_id]['relation_key'])
        print(f'zero-noise audit: patient {scan_id}',flush=True)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
