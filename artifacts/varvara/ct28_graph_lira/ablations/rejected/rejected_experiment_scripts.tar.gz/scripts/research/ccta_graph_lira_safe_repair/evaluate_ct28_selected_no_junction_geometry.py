#!/usr/bin/env python3
"""Validation ablation: refit selected relation head without JUNCTION geometry stream."""
from __future__ import annotations

import copy
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import run_ct28_graph_lira as graph
import train_ct28_perturbation_augmented_relation_head as augmentation
import train_ct28_relation_head as training


ROOT = training.REPO_ROOT
SCENES = graph.DEFAULT_SCENE_DIR
SWEEP = ROOT / "varvara/anza_lira_local_results/ct28_copy_count_ablations"
SELECTED = SWEEP / "joint_check/fusion_10_relation_15"
COPIES = SWEEP / "relation/joint_train_relation_copies.csv"
OUTPUT = SWEEP / "no_junction_geometry_selected"
TEST_IDS = {954, 958, 972, 973, 980, 984}


def without_junction_geometry(columns: list[str]) -> tuple[list[str], list[str]]:
    junction_prefix = "geometry_score_junction_"
    cross_features = {
        "geometry_score_top_difference", "geometry_score_top_sum",
        "geometry_score_junction_gap12_repeat",
        "geometry_score_junction_count_repeat",
    }
    removed = [column for column in columns
               if column.startswith(junction_prefix) or column in cross_features]
    removed_set = set(removed)
    selected = [column for column in columns if column not in removed_set]
    return selected, removed


def main() -> None:
    plans = pd.read_csv(SCENES / "scene_plan_train_val.csv")
    candidates = pd.read_csv(SCENES / "scene_candidates_train_val.csv")
    scores = pd.read_csv(SELECTED / "relation_local_scores_train_val.csv")
    source_predictions = pd.read_csv(SELECTED / "relation_predictions_val.csv")
    source_pack = joblib.load(SELECTED / "relation_models.joblib")
    source_protocol = json.loads((SELECTED / "relation_model_protocol.json").read_text())
    copies = pd.read_csv(COPIES, float_precision="round_trip")

    training.validate_scene_inputs(plans, candidates)
    training.validate_scene_inputs(plans, scores)
    if (set(plans.scan_id.astype(int)) | set(copies.scan_id.astype(int))) & TEST_IDS:
        raise ValueError("held-out test patient entered evidence ablation")
    if set(plans.split) != {"train", "val"} or set(copies.split) != {"train"}:
        raise ValueError("unexpected train/validation split")
    if source_protocol["pair_fusion_train_copy_count"] != 10 or source_protocol["relation_train_copy_count"] != 15:
        raise ValueError("source is not the selected K10/K15 configuration")
    expected_hashes = source_protocol["source_sha256"]
    for key, filename in (
        ("scene_plan", "scene_plan_train_val.csv"),
        ("scene_candidates", "scene_candidates_train_val.csv"),
        ("scene_candidate_features", "scene_candidate_features_train_val.csv"),
    ):
        if training.sha256(SCENES / filename) != expected_hashes[key]:
            raise ValueError(f"frozen scene input changed: {key}")

    clean_rows, full_columns = graph.relation_feature_rows(
        plans, candidates, scores, ("geometry_score", "ct_score")
    )
    columns, removed = without_junction_geometry(full_columns)
    if len(full_columns) != 84 or len(columns) != 62 or len(removed) != 22:
        raise ValueError("expected 84-to-62 JUNCTION geometry evidence reduction")
    train_clean = [dict(row, augmentation_index=0, sample_weight=0.5)
                   for row in clean_rows if row["split"] == "train"]
    validation = [row for row in clean_rows if row["split"] == "val"]
    if len(train_clean) != 1036 or len(validation) != 368:
        raise ValueError("scene counts changed")
    if len(copies) != 15 * len(train_clean) or set(copies.augmentation_index.astype(int)) != set(range(1, 16)):
        raise ValueError("train perturbation copies are incomplete")
    clean_ids = {(row["scene_id"], int(row["scan_id"]), row["relation_class"]) for row in train_clean}
    if set(zip(copies.scene_id, copies.scan_id.astype(int), copies.relation_class)) != clean_ids:
        raise ValueError("train copies do not match clean scenes and labels")
    noisy = copies.to_dict("records")
    for row in noisy:
        row["sample_weight"] = 0.5 / 15
    train = train_clean + noisy
    augmentation.validate_augmentation_weights(train, 15)

    # Detect saved-copy precision and ordering drift before the intervention.
    _, _, reproduced = augmentation.fit_augmented_head(train, validation, full_columns, 0.85)
    reference = source_predictions[source_predictions.model.eq("ct_conditioned")].reset_index(drop=True)
    observed = pd.DataFrame(reproduced)
    if observed.scene_id.tolist() != reference.scene_id.tolist():
        raise ValueError("validation scene order changed")
    probability_columns = [f"probability_{label.lower()}" for label in training.RELATION_CLASSES]
    maximum_error = float(np.max(np.abs(observed[probability_columns].to_numpy() - reference[probability_columns].to_numpy())))
    if maximum_error > 1e-10:
        raise ValueError(f"full 84-feature head did not reproduce selected source: {maximum_error}")

    head, metrics, predictions = augmentation.fit_augmented_head(train, validation, columns, 0.85)
    pack = copy.deepcopy(source_pack)
    pack["relation_heads"]["ct_conditioned"] = head
    pack["ct_conditioned_relation_features"] = columns
    OUTPUT.mkdir(parents=True, exist_ok=True)
    joblib.dump(pack, OUTPUT / "relation_models.joblib")
    scores.to_csv(OUTPUT / "relation_local_scores_train_val.csv", index=False)
    pd.concat([
        source_predictions[source_predictions.model.eq("geometry_only")],
        pd.DataFrame(predictions),
    ], ignore_index=True).to_csv(OUTPUT / "relation_predictions_val.csv", index=False)
    (OUTPUT / "relation_metrics_val.json").write_text(json.dumps(metrics, indent=2) + "\n")
    (OUTPUT / "relation_model_protocol.json").write_text(json.dumps({
        "status": "validation_ablation_not_frozen",
        "held_out_test_accessed": False,
        "source_evidence": str(SELECTED),
        "source_sha256": expected_hashes,
        "train_copies_sha256": training.sha256(COPIES),
        "full_head_reproduction_max_probability_error": maximum_error,
        "feature_count": len(columns),
        "retained_features": columns,
        "removed_junction_geometry_features": removed,
        "intervention": "Remove JUNCTION geometry stream and geometry cross terms from the CT-conditioned relation head only. Local models and candidate identity remain frozen.",
        "train_copy_count": 15,
        "clean_weight": 0.5,
        "copy_weight": 0.5 / 15,
        "pair_identity": "geometry_plus_ct_score",
        "junction_identity": "geometry_score",
        "tau": 0.85,
        "consistency": 0.60,
        "evaluation_perturbations": 15,
    }, indent=2) + "\n")
    print(json.dumps({
        "full_head_reproduction_max_probability_error": maximum_error,
        "feature_count": len(columns),
        "removed": removed,
        "raw_validation_accuracy": metrics["raw"]["accuracy"],
    }, indent=2))


if __name__ == "__main__":
    main()
