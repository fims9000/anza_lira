#!/usr/bin/env python3
"""One nonlinear PAIR preference ranker with frozen CT28 relation heads and gates."""
from pathlib import Path
import json

import joblib
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

import evaluate_ct28_recovery as recovery
import run_ct28_graph_lira as graph
import train_ct28_relation_head as training
import train_ct28_probability_consistency as mlp
from train_ct28_candidate_ranker import ranking
from ct28_perturbations import perturb_scene_endpoints

OUT = graph.REPO_ROOT / 'varvara/anza_lira_local_results/ct28_pair_preference_v1'
COPIES = recovery.RUNS / 'fusion/joint_pair_train_copies.csv'


def pair_inputs(first,second):
    return np.concatenate([first-second,.5*(first+second)],axis=-1)


def group_scores(model,values):
    count=len(values)
    if count==1:
        return np.array([.5])
    first,second=np.where(~np.eye(count,dtype=bool))
    probabilities=np.full((count,count),.5)
    probabilities[first,second]=model.predict_proba(pair_inputs(values[first],values[second]))[:,1]
    wins=.5*(probabilities+1-probabilities.T)
    if not np.allclose(wins+wins.T,1.,atol=1e-12):
        raise ValueError('pair preference is not antisymmetric')
    return (wins.sum(axis=1)-.5)/(count-1)


def fit_ranker(clean,copies,columns):
    clean=clean.copy();clean['augmentation_index']=0
    fit=pd.concat([clean,copies[copies.augmentation_index.le(10)]],ignore_index=True)
    if set(fit.scan_id.astype(int))!=training.EXPECTED_PATIENT_IDS['train']:
        raise ValueError('PAIR preference training cohort changed')
    imputer=SimpleImputer(strategy='median').fit(clean[columns])
    scaler=StandardScaler().fit(imputer.transform(clean[columns]))
    values=scaler.transform(imputer.transform(fit[columns]))
    examples=[];labels=[];weights=[]
    for (_,rep),group in fit.groupby(['scene_id','augmentation_index'],sort=False):
        positive=group.index[group.y.eq(1)];negative=group.index[group.y.eq(0)]
        if not len(positive) or not len(negative):
            continue
        if len(positive)!=1:
            raise ValueError('multiple true PAIR candidates in one scene')
        first=np.repeat(values[positive],len(negative),axis=0);second=values[negative]
        examples.extend([pair_inputs(first,second),pair_inputs(second,first)])
        labels.extend([np.ones(len(negative)),np.zeros(len(negative))])
        weight=(.5 if rep==0 else .5/10)/len(negative)/2
        weights.extend([np.full(len(negative),weight),np.full(len(negative),weight)])
    x=np.concatenate(examples);y=np.concatenate(labels);w=np.concatenate(weights)
    model=training.relation_model().fit(x,y,sample_weight=w/w.mean())
    return dict(model=model,imputer=imputer,scaler=scaler,columns=columns,
                train_preference_rows=len(y),params=model.get_params())


def score_features(pack,frame):
    result=frame[['scene_id','candidate_id']].copy();result['preference_score']=np.nan
    values=pack['scaler'].transform(pack['imputer'].transform(frame[pack['columns']]))
    # Positional indexing avoids dependence on the caller's DataFrame index.
    groups=frame.reset_index(drop=True).groupby('scene_id',sort=False).indices
    for _,indices in groups.items():
        result.iloc[indices,result.columns.get_loc('preference_score')]=group_scores(pack['model'],values[indices])
    if not np.isfinite(result.preference_score).all():
        raise ValueError('missing preference scores')
    return result


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    root=graph.DEFAULT_SCENE_DIR
    plans=pd.read_csv(root/'scene_plan_train_val.csv');candidates=pd.read_csv(root/'scene_candidates_train_val.csv')
    training.validate_scene_inputs(plans,candidates)
    endpoints=pd.read_csv(root/'scene_endpoints_train_val.csv')
    features=pd.read_csv(root/'scene_candidate_features_train_val.csv',low_memory=False)
    scores=pd.read_csv(recovery.SELECTED/'relation_local_scores_train_val.csv')
    model_pack=joblib.load(recovery.SELECTED/'relation_models.joblib')
    columns=list(model_pack['local_models']['PAIR']['geometry_plus_ct'].feature_names_in_)
    copies=pd.read_csv(COPIES,float_precision='round_trip')
    clean=features[features.split.eq('train')&features.candidate_type.eq('PAIR')]
    pack=fit_ranker(clean,copies,columns)
    joblib.dump(pack,OUT/'pair_preference_model.joblib')
    print(f'PAIR HGB fitted: {pack["train_preference_rows"]} preference rows',flush=True)
    # Check equivariance: reordering candidates must only reorder their scores.
    values=pack['scaler'].transform(pack['imputer'].transform(clean.iloc[:6][columns]))
    forward=group_scores(pack['model'],values);reverse=group_scores(pack['model'],values[::-1])[::-1]
    if not np.allclose(forward,reverse,atol=1e-12):
        raise ValueError('PAIR ranking depends on candidate order')
    valplans=plans[plans.split.eq('val')]
    if set(valplans.scan_id.astype(int))!=graph.EXPECTED_VALIDATION_PATIENTS:
        raise ValueError('validation patients changed')
    valfeatures=features[features.split.eq('val')&features.candidate_type.eq('PAIR')]
    clean_preference=score_features(pack,valfeatures)
    sources=[root/name for name in ('scene_plan_train_val.csv','scene_candidates_train_val.csv',
                                    'scene_endpoints_train_val.csv','scene_candidate_features_train_val.csv')]
    sources += [COPIES,recovery.SELECTED/'relation_models.joblib',Path(__file__).resolve()]
    signature={str(path.relative_to(graph.REPO_ROOT)):graph.sha256(path) for path in sources}
    raw_cache=OUT/'pair_features_joint_val.csv.gz';manifest=OUT/'pair_features_sources.json'
    if raw_cache.exists():
        if not manifest.exists() or json.loads(manifest.read_text())!=signature:
            raise ValueError('raw PAIR feature cache source SHA changed')
        raw_noisy=pd.read_csv(raw_cache,float_precision='round_trip')
    else:
        geometry=pd.read_csv(graph.ct_features.EXPECTED_GEOMETRY).set_index('scan_id')
        alignment=pd.read_csv(graph.ct_features.EXPECTED_ALIGNMENT).set_index('scan_id')
        records=[]
        for patient in sorted(graph.EXPECTED_VALIDATION_PATIENTS):
            ct,inverse=graph.load_verified_ct(patient,graph.DEFAULT_ARCHIVE_DIR,geometry,alignment)
            ids=set(valplans.loc[valplans.scan_id.eq(patient),'scene_id'])
            cc=candidates[candidates.scene_id.isin(ids)&candidates.candidate_type.eq('PAIR')]
            ec=endpoints[endpoints.scene_id.isin(ids)]
            for rep in range(15):
                groups={sid:perturb_scene_endpoints(group,seed=20260920,repetition=rep,
                            position_noise_mm=.8,tangent_noise_deg=20.).set_index('endpoint_id')
                        for sid,group in ec.groupby('scene_id',sort=False)}
                for candidate in cc.to_dict('records'):
                    row=graph.perturbed_candidate_features(pd.Series(candidate),groups[candidate['scene_id']],ct,inverse,[])
                    records.append(dict(repetition=rep,**row))
            print(f'PAIR features: validation patient {patient} completed',flush=True)
            del ct
        raw_noisy=pd.DataFrame(records)
        raw_noisy.to_csv(raw_cache,index=False,compression={'method':'gzip','mtime':0})
        manifest.write_text(json.dumps(signature,indent=2)+'\n')
    noisy_preference=[]
    for rep,group in raw_noisy.groupby('repetition',sort=True):
        part=score_features(pack,group);part['repetition']=rep;noisy_preference.append(part)
    noisy_preference=pd.concat(noisy_preference,ignore_index=True)
    noisy_scores=pd.read_csv(recovery.TRACE/'local_scores_val.csv.gz')
    noisy_scores=noisy_scores[noisy_scores['mode'].eq('joint')].copy()
    clean_scores=scores[scores.split.eq('val')].copy()
    alternative_clean=clean_scores.merge(clean_preference,on=['scene_id','candidate_id'],how='left',validate='one_to_one')
    alternative_noisy=noisy_scores.merge(noisy_preference,on=['repetition','scene_id','candidate_id'],how='left',validate='one_to_one')
    for frame in (alternative_clean,alternative_noisy):
        mask=frame.candidate_type.eq('PAIR')
        if not np.isfinite(frame.loc[mask,'preference_score']).all():
            raise ValueError('PAIR preference coverage is incomplete')
        frame.loc[mask,'geometry_plus_ct_score']=frame.loc[mask,'preference_score']
    clean_scores['repetition']=-1;alternative_clean['repetition']=-1
    ranking_metrics={label:{variant:ranking(frame[frame.candidate_type.eq('PAIR')],candidates,'geometry_plus_ct_score')
                            for variant,frame in [('pointwise',base),('preference',alternative)]}
                     for label,base,alternative in [('clean',clean_scores,alternative_clean),('joint',noisy_scores,alternative_noisy)]}
    rows,relation_columns=graph.relation_feature_rows(plans,candidates,scores,['geometry_score','ct_score'])
    rv=pd.DataFrame(rows);rv=rv[rv.split.eq('val')]
    nf=pd.read_csv(recovery.TRACE/'relation_features_val.csv.gz');nf=nf[nf['mode'].eq('joint')]
    mlp_pack=joblib.load(mlp.OUT/'relation_models.joblib')
    fixed_probabilities={
        'HGB':(model_pack['relation_heads']['ct_conditioned'].predict_proba(rv[relation_columns].to_numpy()),
               model_pack['relation_heads']['ct_conditioned'].predict_proba(nf[relation_columns].to_numpy())),
        'MLP_JS':(mlp.predict(mlp_pack['parameters']['MLP_CE_JS'],mlp_pack['scaler'].transform(rv[relation_columns].to_numpy())),
                  mlp.predict(mlp_pack['parameters']['MLP_CE_JS'],mlp_pack['scaler'].transform(nf[relation_columns].to_numpy())))}
    frames=[];metrics={}
    for head,(base_probability,noisy_probability) in fixed_probabilities.items():
        base_map=dict(zip(rv.scene_id,base_probability));noisy_map=dict(zip(zip(nf.repetition,nf.scene_id),noisy_probability))
        for identity,cs,ns in [('pointwise',clean_scores,noisy_scores),('preference',alternative_clean,alternative_noisy)]:
            name=f'{head}_{identity}'
            frame,_=recovery.evaluate(name,valplans,candidates,cs,ns,base_map,noisy_map)
            metrics[name]=recovery.summary(frame);frames.append(frame)
            print(name,metrics[name],flush=True)
    if metrics['HGB_pointwise']['post_exact']!=52 or metrics['MLP_JS_pointwise']['post_exact']!=54:
        raise ValueError('reference structural results did not replay')
    frame=pd.concat(frames,ignore_index=True);frame.to_csv(OUT/'predictions_val.csv',index=False)
    for keys,name in [(['variant','scan_id'],'per_patient'),(['variant','scene_family','pair_count','junction_count'],'count_strata')]:
        summaries=[]
        for key,group in frame.groupby(keys):
            summaries.append(dict(zip(keys,key))|dict(scenes=len(group))|recovery.summary(group))
        pd.DataFrame(summaries).to_csv(OUT/f'{name}_val.csv',index=False)
    (OUT/'metrics.json').write_text(json.dumps(dict(status='validation_ablation_not_test_frozen',held_out_test_accessed=False,
        change='PAIR identity only; all relation probabilities and JUNCTION identity frozen',
        preference_features='standardized difference and midpoint of45 raw PAIR geometry+CT features',
        inference='antisymmetric mean pairwise win probability; identity utility, not calibrated P(real PAIR)',
        relation_head_sha256={'HGB':graph.sha256(recovery.SELECTED/'relation_models.joblib'),
                             'MLP_CE_JS':graph.sha256(mlp.OUT/'relation_models.joblib')},
        decision='reject preference ranker; retain pointwise identities for both relation heads',
        model_params=pack['params'],train_preference_rows=pack['train_preference_rows'],train_patients=sorted(clean.scan_id.astype(int).unique().tolist()),
        train_copies=10,noise='joint0.8mm20deg',scene_weight='clean0.5/all copies0.5; equal weight among negatives/directions then mean rescaling',
        oof_note='preference train scores are not fed into relation head',
        tau=.85,consistency=.60,repeats=15,ranking=ranking_metrics,metrics=metrics,source_sha256=signature),indent=2)+'\n')


if __name__=='__main__':
    with threadpool_limits(limits=1):
        main()
