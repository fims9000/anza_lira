#!/usr/bin/env python3
"""Compare a smooth JUNCTION local model with selected HGB ranking on CT28 validation."""
from __future__ import annotations

import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import train_ct28_geometry_augmentation_matrix as geometry
import train_ct28_relation_head as training


ROOT = training.REPO_ROOT
SCENES = training.DEFAULT_SCENE_DIR
SAVED = ROOT / "varvara/anza_lira_local_results/ct28_copy_count_ablations"
SELECTED = SAVED / "joint_check/fusion_10_relation_15"
OUT = ROOT / "varvara/anza_lira_local_results/ct28_junction_local_logistic_diagnostic"
FEATURES = list(training.JUNCTION_GEOMETRY_FEATURES)
TEST_IDS = {954, 958, 972, 973, 980, 984}


def score_scenes(frame: pd.DataFrame, model: object, label: str, repetition: int) -> list[dict]:
    values = frame.copy()
    columns = list(model.feature_names_in_)
    values["score"] = model.predict_proba(values[columns])[:, 1]
    result = []
    for scene_id, group in values.groupby("scene_id", sort=False):
        if int(group.y.eq(1).sum()) != 1:
            raise ValueError(f"expected one true JUNCTION candidate in {scene_id}")
        true = group[group.y.eq(1)].iloc[0]
        negatives = group[group.y.eq(0)]
        best_false = float(negatives.score.max()) if len(negatives) else np.nan
        winner = group.loc[group.score.idxmax()]
        result.append({
            "scene_id": scene_id, "scan_id": int(group.scan_id.iloc[0]),
            "scene_family": group.scene_family.iloc[0],
            "repetition": repetition, "model": label,
            "competitive": int(len(negatives) > 0),
            "true_top1": int(winner.y == 1),
            "true_score": float(true.score), "best_false_score": best_false,
            "margin": float(true.score - best_false) if len(negatives) else np.nan,
        })
    return result


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    plans = pd.read_csv(SCENES / "scene_plan_train_val.csv")
    candidates = pd.read_csv(SCENES / "scene_candidates_train_val.csv")
    endpoints = pd.read_csv(SCENES / "scene_endpoints_train_val.csv")
    features = pd.read_csv(SCENES / "scene_candidate_features_train_val.csv", low_memory=False)
    training.validate_scene_inputs(plans, candidates)
    if set(plans.scan_id.astype(int)) & TEST_IDS or set(plans.split) != {"train", "val"}:
        raise ValueError("held-out test or unexpected split in scene pack")
    selected_protocol = json.loads((SELECTED / "relation_model_protocol.json").read_text())
    for key, name in (("scene_plan", "scene_plan_train_val.csv"),
                      ("scene_candidates", "scene_candidates_train_val.csv"),
                      ("scene_candidate_features", "scene_candidate_features_train_val.csv")):
        if training.sha256(SCENES / name) != selected_protocol["source_sha256"][key]:
            raise ValueError(f"frozen scene SHA changed: {name}")
    selected = joblib.load(SELECTED / "relation_models.joblib")
    hgb = selected["local_models"]["JUNCTION"]["geometry"]
    if list(hgb.feature_names_in_) != FEATURES:
        raise ValueError("selected JUNCTION geometry feature order changed")
    junction = candidates[candidates.candidate_type.eq("JUNCTION")].merge(
        plans[["scene_id", "scan_id", "split", "scene_family"]],
        on="scene_id", validate="many_to_one")
    clean = junction[["scene_id", "candidate_id", "scan_id", "split", "scene_family", "y"]].merge(
        features[["scene_id", "candidate_id", *FEATURES]],
        on=["scene_id", "candidate_id"], validate="one_to_one")
    train = clean[clean.split.eq("train")].copy()
    validation = clean[clean.split.eq("val") & clean.scene_family.isin(("junction_only", "mixed"))].copy()
    if set(train.scan_id.astype(int)) != training.EXPECTED_PATIENT_IDS["train"] or len(validation.scene_id.unique()) != 72:
        raise ValueError("unexpected train patients or validation JUNCTION scenes")
    noisy = pd.read_csv(SAVED / "geometry/junction_position_train_copies.csv", float_precision="round_trip")
    if len(noisy) != 15 * len(train) or set(noisy.scan_id.astype(int)) != training.EXPECTED_PATIENT_IDS["train"]:
        raise ValueError("saved JUNCTION train copies incomplete")
    if not noisy.groupby(["scene_id", "candidate_id"]).size().eq(15).all():
        raise ValueError("JUNCTION train copy count changed")
    fit_clean = train.copy()
    fit_clean["weight"] = 0.5
    fit_noisy = noisy[noisy.augmentation_index.le(5)].copy()
    fit_noisy["weight"] = 0.1
    fit = pd.concat([fit_clean, fit_noisy], ignore_index=True)
    if not np.allclose(fit.groupby(["scene_id", "candidate_id"]).weight.sum(), 1.0):
        raise ValueError("JUNCTION training weights changed")
    logistic = training.local_model("logistic").fit(
        fit[FEATURES], fit.y, lr__sample_weight=fit.weight)
    rows = []
    for name, model in (("selected_hgb", hgb), ("junction_logistic", logistic)):
        rows.extend(score_scenes(validation, model, name, -1))
    val_candidates = junction[junction.scene_id.isin(validation.scene_id)]
    val_endpoints = endpoints[endpoints.scene_id.isin(validation.scene_id)]
    labels = validation[["scene_id", "candidate_id", "scan_id", "scene_family", "y"]]
    for repetition in range(15):
        noisy_val = geometry.geometry_rows(
            val_candidates, val_endpoints, "JUNCTION", "position_only", repetition)
        noisy_val = noisy_val.merge(labels, on=["scene_id", "candidate_id"], validate="one_to_one")
        if len(noisy_val) != len(validation):
            raise ValueError(f"incomplete validation geometry repetition {repetition}")
        for name, model in (("selected_hgb", hgb), ("junction_logistic", logistic)):
            rows.extend(score_scenes(noisy_val, model, name, repetition))
        print(f"JUNCTION validation position repetition {repetition+1}/15", flush=True)
    result = pd.DataFrame(rows)
    result.to_csv(OUT / "ranking_val.csv", index=False)
    summaries = []
    for (name, family, phase), group in result.assign(
        phase=np.where(result.repetition.eq(-1), "clean", "position_noise")
    ).groupby(["model", "scene_family", "phase"]):
        summaries.append({"model": name, "scene_family": family, "phase": phase,
                          "top1": int(group.true_top1.sum()), "observations": len(group),
                          "competitive_top1": int(group.loc[group.competitive.eq(1), "true_top1"].sum()),
                          "competitive_observations": int(group.competitive.sum())})
    (OUT / "summary.json").write_text(json.dumps({
        "status": "candidate_ranking_diagnostic_only", "held_out_test_accessed": False,
        "train_patients": sorted(int(patient) for patient in train.scan_id.unique()),
        "validation_patients": sorted(int(patient) for patient in validation.scan_id.unique()),
        "train_copies": 5, "noise": "position_only_0.8mm", "clean_weight": 0.5,
        "copy_weight_each": 0.1, "validation_repetitions": 15,
        "features": FEATURES, "source_sha256": selected_protocol["source_sha256"],
        "selected_model_sha256": training.sha256(SELECTED / "relation_models.joblib"),
        "summary": summaries,
    }, indent=2) + "\n")
    print(pd.DataFrame(summaries).to_string(index=False), flush=True)


if __name__ == "__main__":
    main()
